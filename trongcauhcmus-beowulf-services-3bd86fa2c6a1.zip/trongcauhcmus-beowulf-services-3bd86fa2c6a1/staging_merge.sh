#!/bin/bash

git checkout dev
git pull origin dev --no-edit
git push origin dev

git checkout staging
git pull origin dev --no-edit
git push origin staging

git checkout dev