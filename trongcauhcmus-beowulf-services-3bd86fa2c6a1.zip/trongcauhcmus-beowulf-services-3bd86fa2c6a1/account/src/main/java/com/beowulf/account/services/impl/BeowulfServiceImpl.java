package com.beowulf.account.services.impl;

import com.beowulf.account.config.AccountServiceConfig;
import com.beowulf.account.documents.AirdropHistory;
import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.documents.ApiKeyLevel;
import com.beowulf.account.repository.AirdropHistoryRepository;
import com.beowulf.account.repository.ApiKeyLevelRepository;
import com.beowulf.account.repository.ApiKeyRepository;
import com.beowulf.account.services.BeowulfService;
import com.beowulf.model.request.BeowulfAccountAirdropRequest;
import com.beowulf.model.request.BeowulfCreateAccountRequest;
import com.beowulf.model.request.BeowulfCreateMultisigAccountRequest;
import com.beowulf.model.response.BeowulfAccountAirdropResponse;
import com.beowulf.model.response.BeowulfCreateAccountResponse;
import com.beowulf.model.response.BeowulfCreateMultisigAccountResponse;
import com.beowulf.utilities.AESEncryptor;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.chain.NetworkProperties;
import com.beowulfchain.beowulfj.configuration.BeowulfJConfig;
import com.beowulfchain.beowulfj.enums.PrivateKeyType;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.*;
import com.beowulfchain.beowulfj.protocol.operations.AccountCreateOperation;
import com.beowulfchain.beowulfj.protocol.operations.TransferOperation;
import com.mongodb.MongoClient;
import com.mongodb.client.ClientSession;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;


@Service
@EnableScheduling
public class BeowulfServiceImpl implements BeowulfService {

    private static BeowulfJ beowulfJ;
    private static NetworkProperties network;
    private static String jsonMetadataTemplate = "{}";

    static {
        try {
            initNetwork();
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            e.printStackTrace();
        }
    }

    @Autowired
    ApiKeyRepository apiKeyRepository;

    @Autowired
    ApiKeyLevelRepository apiKeyLevelRepository;

    @Autowired
    AirdropHistoryRepository airdropHistoryRepository;

    @Autowired
    MongoTransactionManager transactionManager;

    @Autowired
    MongoClient mongoClient;

    @Override
    public BeowulfCreateAccountResponse createAccount(BeowulfCreateAccountRequest request) throws Exception {
        try {
            AccountName newAccount = new AccountName(request.getAccount_name());
            PublicKey publicKey = new PublicKey(request.getPublic_key());
            Authority owner = new Authority();
            Map<PublicKey, Integer> keyAuths = new HashMap<>();
            keyAuths.put(publicKey, 1);
            owner.setKeyAuths(keyAuths);
            owner.setWeightThreshold(1);

            AccountCreateOperation operation = beowulfJ.createAccount(AccountServiceConfig.getInstance().getCredential_account_beowulf_default(), network.getAccountCreationFee(), newAccount, owner, jsonMetadataTemplate);
            TransactionId transactionId = beowulfJ.signAndBroadcast(Collections.singletonList(operation));
            BeowulfCreateAccountResponse response = new BeowulfCreateAccountResponse(transactionId);
            LoggerUtil.w(this, String.format("create account [%s] with pubkey [%s] in txid [%s]", request.getAccount_name(), request.getPublic_key(), transactionId.toString()));
            return response;
        } catch (BeowulfResponseException e) {
            e.printStackTrace();
            LoggerUtil.e("create account", e.getMessage());
            if (e.getData().get("code").asInt() == 13) {
                throw ServiceExceptionUtils.accountExisted();
            }
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public BeowulfCreateMultisigAccountResponse createMultisigAccount(BeowulfCreateMultisigAccountRequest request) throws Exception {
        try {
            AccountName newAccount = new AccountName(request.getAccount_name());
            if (request.getKeyAuths().size() < 1 && request.getAccountAuths().size() < 1) {
                throw ServiceExceptionUtils.invalidRequestParam("must input at least 1 public key or account");
            }

            if (request.getMin_weight() < 1) {
                throw ServiceExceptionUtils.invalidRequestParam("min_weight must not lower than 1");
            }

            int total_weight = 0;
            for (AccountName s :
                    request.getAccountAuths().keySet()) {
                total_weight = total_weight + request.getAccountAuths().get(s);
            }

            for (String s :
                    request.getKeyAuths().keySet()) {
                total_weight = total_weight + request.getKeyAuths().get(s);
            }

            if (request.getMin_weight() > total_weight) {
                throw ServiceExceptionUtils.invalidRequestParam("min weight must not greater than total weight");
            }
            Authority owner = new Authority();
            Map<PublicKey, Integer> keyAuths = new HashMap<>();

            for (String pubKeyString : request.getKeyAuths().keySet()) {
                int weight = request.getKeyAuths().get(pubKeyString);
                PublicKey publicKey = new PublicKey(pubKeyString);
                keyAuths.put(publicKey, weight);
            }
            owner.setKeyAuths(keyAuths);
            owner.setAccountAuths(request.getAccountAuths());
            owner.setWeightThreshold(request.getMin_weight());

            AccountCreateOperation operation = initNetwork().createAccount(AccountServiceConfig.getInstance().getCredential_account_beowulf_default(), network.getAccountCreationFee(), newAccount, owner, jsonMetadataTemplate);
            TransactionId transactionId = initNetwork().signAndBroadcast(Collections.singletonList(operation));

            return new BeowulfCreateMultisigAccountResponse(transactionId.toString());
        } catch (BeowulfResponseException e) {
            LoggerUtil.e("create account", e.getMessage());
            if (e.getData().get("code").asInt() == 13) {
                throw ServiceExceptionUtils.accountExisted();
            }
            throw ServiceExceptionUtils.errorRequestToBeowulfNetwork(e.getMessage());
        }
    }

    @Override
    public BeowulfCreateAccountResponse createAccountByApikey(ApiKey apiKey, BeowulfCreateAccountRequest request) throws Exception {
        ClientSession session = mongoClient.startSession();
        try {
            session.startTransaction();
            ApiKeyLevel level = apiKeyLevelRepository.findApiKeyLevelByApiKeyLevel(apiKey.getApi_key_level());
            if (level == null) {
                throw ServiceExceptionUtils.internalServerError();
            }

            // reset api key every day
            if (System.currentTimeMillis() - apiKey.getUpdated_at() > 86400000) {
                apiKey.setCreate_wallet_counting_per_day(0);
                apiKey.setUpdated_at(System.currentTimeMillis());
//                apiKeyRepository.save(apiKey);
            }

            // check api exceed limit perday
            if (apiKey.getCreate_wallet_counting_per_day() > level.getMax_number_wallet()) {
                throw ServiceExceptionUtils.apikeyExceedLimit();
            }

            apiKey.setCreate_wallet_counting_per_day(apiKey.getCreate_wallet_counting_per_day() + 1L);
//            apiKeyRepository.increaseCounting(session, apiKey);
            apiKeyRepository.saveOrOverWrite(session, apiKey);
            BeowulfCreateAccountResponse response = createAccount(request);
            session.commitTransaction();
            return response;
        } catch (Exception e) {
            session.abortTransaction();
            throw e;
        } finally {
            session.close();
        }
    }

    @Override
    public BeowulfAccountAirdropResponse accountAirdrop(BeowulfAccountAirdropRequest request) throws Exception {
        String bwfamount = "1.00000";
        String wamount = "1.00000";
        try {
            AirdropHistory history = new AirdropHistory(request.getAccount_name(), new Date());
            airdropHistoryRepository.save(history);
            AccountName from = new AccountName(AccountServiceConfig.getInstance().getCredential_account_beowulf_default().getName());
            AccountName to = new AccountName(request.getAccount_name());
            Asset amountBWF = Asset.createAsset(new BigDecimal(bwfamount), "BWF");
            Asset amountW = Asset.createAsset(new BigDecimal(wamount), "W");
            TransferOperation transferBwf = initNetwork().transfer(from, to, amountBWF, network.getTransactionFee(), String.format("Hello @%s - I've sent you %s.", request.getAccount_name(), amountBWF.toString()));
            TransactionId transferBWF_txid = initNetwork().signAndBroadcast(Collections.singletonList(transferBwf));
            System.out.println("Transaction id: " + transferBWF_txid);

            TransferOperation transferW = initNetwork().transfer(from, to, amountW, network.getTransactionFee(), String.format("Hello @%s - I've sent you %s.", request.getAccount_name(), amountW.toString()));
            TransactionId transferW_txid = initNetwork().signAndBroadcast(Collections.singletonList(transferW));
            System.out.println("Transaction id: " + transferW_txid);
            System.out.println("Successfully airdrop for account: " + request.getAccount_name());
            return new BeowulfAccountAirdropResponse(true, transferBWF_txid.toString(), transferW_txid.toString());
        } catch (BeowulfResponseException e) {
            if (e.getMessage().equals("unknown key:unknown key: "))
                throw ServiceExceptionUtils.accountNotExisted();
            System.out.println("Error transfer request to network");
            System.out.println("errorcode: " + e.getCode());
            System.out.println("error message: " + e.getData());
            throw ServiceExceptionUtils.internalServerError();
        } catch (DuplicateKeyException e) {
            throw ServiceExceptionUtils.tooManyRequestAirdrop();
        }
    }

    private static BeowulfJ initNetwork() throws BeowulfCommunicationException, BeowulfResponseException {
        beowulfJ = BeowulfCommunicate.init(AccountServiceConfig.getInstance().getBeowulf_node());
        network = BeowulfJConfig.getInstance().getNetwork();
        BeowulfJConfig myConfig = BeowulfJConfig.getInstance();
        myConfig.setResponseTimeout(100000);
        myConfig.setDefaultAccount(AccountServiceConfig.getInstance().getCredential_account_beowulf_default());
        List<ImmutablePair<PrivateKeyType, String>> privateKeys = new ArrayList<>();
        privateKeys.add(new ImmutablePair<>(PrivateKeyType.OWNER,
                AESEncryptor.decrypt(AccountServiceConfig.getInstance().getCrypto_aes_secretkey(),
                        AccountServiceConfig.getInstance().getCrypto_aes_initVector(),
                        AccountServiceConfig.getInstance().getCredential_account_beowulf_cipherPrivkey())));

        myConfig.getPrivateKeyStorage().addAccount(AccountServiceConfig.getInstance().getCredential_account_beowulf_default(), privateKeys);
        return beowulfJ;
    }
}
