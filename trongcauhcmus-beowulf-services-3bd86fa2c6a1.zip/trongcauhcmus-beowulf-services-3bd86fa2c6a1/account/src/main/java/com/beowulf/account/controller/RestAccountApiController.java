package com.beowulf.account.controller;

import com.beowulf.account.documents.ApiKey;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value = "/api/account")
public class RestAccountApiController {

    @RequestMapping(value = "/details", method = RequestMethod.GET)
    public ApiKey getApiKeyDetails(HttpServletRequest request,
                                   @RequestHeader(name = "Authorization") ApiKey apiKey) {
        return apiKey;
    }
}
