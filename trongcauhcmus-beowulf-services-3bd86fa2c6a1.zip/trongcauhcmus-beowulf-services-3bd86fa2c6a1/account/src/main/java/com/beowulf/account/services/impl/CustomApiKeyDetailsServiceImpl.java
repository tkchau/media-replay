package com.beowulf.account.services.impl;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.documents.ApiKeyLevel;
import com.beowulf.account.repository.ApiKeyLevelRepository;
import com.beowulf.account.repository.ApiKeyRepository;
import com.beowulf.account.services.CustomApiKeyDetailsService;
import com.beowulf.constants.AccountRole;
import com.beowulf.model.CurrentApiKeyAuthenticated;
import com.beowulf.utilities.ApiKeyUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("customApiKeyDetailsService")
public class CustomApiKeyDetailsServiceImpl implements CustomApiKeyDetailsService {
    private static final String TAG = CustomApiKeyDetailsServiceImpl.class.getName();

    @Autowired
    ApiKeyRepository apiKeyRepository;

    @Autowired
    ApiKeyLevelRepository apiKeyLevelRepository;

    public List<GrantedAuthority> getAuthorities(Integer role) {
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();
        if (role.intValue() == AccountRole.API_KEY_ROLE) {
            authList.add(new SimpleGrantedAuthority(AccountRole.TEXT_ROLE_API_KEY));
        } else {
            authList.add(new SimpleGrantedAuthority(AccountRole.TEXT_ROLE_ANONYMOUS));
        }
        return authList;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            LoggerUtil.i(TAG, "Load api key: " + username);
            if (StringUtils.hasText(username)) {
                String api_key = username.trim().toLowerCase();
                ApiKey apiKey = apiKeyRepository.findApiKeyByApiKeyId(api_key);
                if (apiKey != null) {
                    ApiKeyLevel apiKeyLevel = apiKeyLevelRepository.findApiKeyLevelByApiKeyLevel(apiKey.getApi_key_level());
                    CurrentApiKeyAuthenticated user =
                            new CurrentApiKeyAuthenticated(apiKey.getApi_key(), ApiKeyUtils.decryptToken(apiKey.getAccess_token()),
                                    true, true, true, true,
                                    getAuthorities(AccountRole.API_KEY_ROLE), apiKey, apiKeyLevel);
                    return user;
                }
            }

        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        throw new UsernameNotFoundException("api key not found");
    }
}
