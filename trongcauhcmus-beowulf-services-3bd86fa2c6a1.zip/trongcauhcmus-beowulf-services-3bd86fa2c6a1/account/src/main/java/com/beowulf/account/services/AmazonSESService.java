package com.beowulf.account.services;

public interface AmazonSESService {
    public boolean sendEmailConfirmRegister(String title, String email, String nickName, String linkRegister,
                                            String linkImage, String language, String time);
}
