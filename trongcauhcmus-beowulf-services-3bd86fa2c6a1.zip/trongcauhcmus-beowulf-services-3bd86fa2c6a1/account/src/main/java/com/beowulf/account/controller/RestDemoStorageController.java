package com.beowulf.account.controller;

import com.beowulf.account.services.DemoStorageService;
import com.beowulf.annotations.GoogleRecaptchaValidated;
import com.beowulf.model.request.DemoCertificateRequest;
import com.beowulf.model.request.DemoLandRegistryRequest;
import com.beowulf.model.response.DemoCertificateResponse;
import com.beowulf.model.response.DemoLandRegistryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("demo")
@Validated
public class RestDemoStorageController {

    @Autowired
    DemoStorageService demoStorageService;

    @RequestMapping(value = "registry/certificate", method = RequestMethod.POST)
    public DemoCertificateResponse pushUniversityCert(@GoogleRecaptchaValidated @RequestHeader("captcha") String captcha,
                                                      @Valid @RequestBody DemoCertificateRequest request) {
        return demoStorageService.pushCertificateRegistry(request);
    }

    @RequestMapping(value = "registry/land", method = RequestMethod.POST)
    public DemoLandRegistryResponse pushLandOwnership(@GoogleRecaptchaValidated @RequestHeader("captcha") String captcha,
                                                      @Valid @RequestBody DemoLandRegistryRequest request) {
        return demoStorageService.pushLandRegistry(request);
    }
}
