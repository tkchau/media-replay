package com.beowulf.account.controller;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.services.BeowulfService;
import com.beowulf.annotations.ApiKeyValidated;
import com.beowulf.annotations.GoogleRecaptchaValidated;
import com.beowulf.annotations.RequestThottlingValidated;
import com.beowulf.model.request.BeowulfCreateAccountRequest;
import com.beowulf.model.request.BeowulfCreateMultisigAccountRequest;
import com.beowulf.model.response.BeowulfCreateAccountResponse;
import com.beowulf.model.response.BeowulfCreateMultisigAccountResponse;
import com.beowulf.utilities.HttpServletUtils;
import com.beowulf.utilities.LoggerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping(value = "register/account")
@Validated
public class AccountRegisterController {

    @Autowired
    BeowulfService beowulfService;

    // api create new wallet
    @RequestMapping(value = "bycaptcha", method = RequestMethod.POST)
    @ResponseBody
    public BeowulfCreateAccountResponse createWalletByCaptcha(
            @GoogleRecaptchaValidated @RequestHeader(name = "captcha") String captcha,
            @RequestBody BeowulfCreateAccountRequest request,
            @RequestThottlingValidated(timeUnit = TimeUnit.DAYS, rate = 1) HttpServletRequest httpServletRequest) throws Exception {
        LoggerUtil.w(this, HttpServletUtils.getClientIP(httpServletRequest));
        try {
            return beowulfService.createAccount(request);
        } catch (Exception e) {
            HttpServletUtils.decreaseRequest(httpServletRequest, TimeUnit.DAYS);
            throw e;
        }
    }

    @RequestMapping(value = "multisig", method = RequestMethod.POST)
    @ResponseBody
    public BeowulfCreateMultisigAccountResponse createMultisigWallet(
            @GoogleRecaptchaValidated @RequestHeader(name = "captcha") String captcha,
            @RequestBody BeowulfCreateMultisigAccountRequest request,
            @RequestThottlingValidated(timeUnit = TimeUnit.DAYS, rate = 1) HttpServletRequest httpServletRequest) throws Exception {
        try {
            return beowulfService.createMultisigAccount(request);
        } catch (Exception e) {
            HttpServletUtils.decreaseRequest(httpServletRequest, TimeUnit.DAYS);
            throw e;
        }
    }

    @RequestMapping(value = "bykey", method = RequestMethod.POST)
    @ResponseBody
    public BeowulfCreateAccountResponse createWalletByApiKey(
            @ApiKeyValidated @RequestHeader(name = "Authorization", required = false) ApiKey apiKey,
            @RequestBody BeowulfCreateAccountRequest request,
            @RequestThottlingValidated(timeUnit = TimeUnit.DAYS, rate = 1) HttpServletRequest servletRequest) throws Exception {
        System.out.println(servletRequest.getRemoteAddr());
        return beowulfService.createAccountByApikey(apiKey, request);
    }
}
