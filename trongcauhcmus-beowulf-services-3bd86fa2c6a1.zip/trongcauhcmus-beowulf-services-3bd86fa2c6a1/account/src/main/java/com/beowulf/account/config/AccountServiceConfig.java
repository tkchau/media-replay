package com.beowulf.account.config;

import com.beowulfchain.beowulfj.protocol.AccountName;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class AccountServiceConfig {
    private static AccountServiceConfig appContext;

    // Secret declare
    private String crypto_aes_secretkey;
    private String crypto_aes_initVector;

    private String payment_aes_secretkey;
    private String payment_aes_initVector;

    private AccountName credential_account_beowulf_default;
    private String credential_account_beowulf_cipherPrivkey;

    private AccountName credential_account_beowulf_university_name;
    private String credential_account_beowulf_university_cipherPrivkey;
    private AccountName credential_account_beowulf_major_name;
    private String credential_account_beowulf_major_cipherPrivkey;

    private AccountName credential_account_beowulf_notary_name;
    private String credential_account_beowulf_notary_cipherPrivkey;
    private AccountName credential_account_beowulf_region_name;
    private String credential_account_beowulf_region_cipherPrivkey;

    private String beowulf_node;
    private String eth_node;

    private AccountServiceConfig() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext();
        Properties properties = new Properties();
        try {

            String configFile = System.getProperty("account_service");
            if (configFile == null) {
                configFile = "classpath:/account-service.properties";
            }
            properties.load(appContext.getResource(configFile).getInputStream());

            crypto_aes_secretkey = properties.getProperty("crypto.aes.secretkey");
            crypto_aes_initVector = "3384eed075d2d9ec";

            payment_aes_secretkey = properties.getProperty("payment.aes.secretkey");
            payment_aes_initVector = "G5GXXpOpapmaVjqQ";


            credential_account_beowulf_default = new AccountName(properties.getProperty("credential.account.beowulf.default"));
            credential_account_beowulf_cipherPrivkey = properties.getProperty("credential.account.beowulf.cipherPrivkey");
            credential_account_beowulf_university_name = new AccountName(properties.getProperty("credential.account.beowulf.university.name"));
            credential_account_beowulf_university_cipherPrivkey = properties.getProperty("credential.account.beowulf.university.cipherPrivkey");
            credential_account_beowulf_major_name = new AccountName(properties.getProperty("credential.account.beowulf.major.name"));
            credential_account_beowulf_major_cipherPrivkey = properties.getProperty("credential.account.beowulf.major.cipherPrivkey");

            credential_account_beowulf_notary_name = new AccountName(properties.getProperty("credential.account.beowulf.notary.name"));
            credential_account_beowulf_notary_cipherPrivkey = properties.getProperty("credential.account.beowulf.notary.cipherPrivkey");
            credential_account_beowulf_region_name = new AccountName(properties.getProperty("credential.account.beowulf.region.name"));
            credential_account_beowulf_region_cipherPrivkey = properties.getProperty("credential.account.beowulf.region.cipherPrivkey");

            beowulf_node = properties.getProperty("beowulf.node");
            eth_node = properties.getProperty("eth.node");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static AccountServiceConfig getInstance() {
        if (appContext == null){
            appContext = new AccountServiceConfig();
        }
        return appContext;
    }

    public String getCrypto_aes_secretkey() {
        return crypto_aes_secretkey;
    }

    public String getCrypto_aes_initVector() {
        return crypto_aes_initVector;
    }

    public AccountName getCredential_account_beowulf_default() {
        return credential_account_beowulf_default;
    }

    public String getCredential_account_beowulf_cipherPrivkey() {
        return credential_account_beowulf_cipherPrivkey;
    }

    public AccountName getCredential_account_beowulf_university_name() {
        return credential_account_beowulf_university_name;
    }

    public String getCredential_account_beowulf_university_cipherPrivkey() {
        return credential_account_beowulf_university_cipherPrivkey;
    }

    public AccountName getCredential_account_beowulf_major_name() {
        return credential_account_beowulf_major_name;
    }

    public String getCredential_account_beowulf_major_cipherPrivkey() {
        return credential_account_beowulf_major_cipherPrivkey;
    }

    public AccountName getCredential_account_beowulf_notary_name() {
        return credential_account_beowulf_notary_name;
    }

    public String getCredential_account_beowulf_notary_cipherPrivkey() {
        return credential_account_beowulf_notary_cipherPrivkey;
    }

    public AccountName getCredential_account_beowulf_region_name() {
        return credential_account_beowulf_region_name;
    }

    public String getCredential_account_beowulf_region_cipherPrivkey() {
        return credential_account_beowulf_region_cipherPrivkey;
    }

    public String getBeowulf_node() {
        return beowulf_node;
    }

    public String getEth_node() {
        return eth_node;
    }
//    @PostConstruct
//    public void init() {
//        AccountServiceConfig.getInstance();
//        System.out.println("complete init config");
//    }
}
