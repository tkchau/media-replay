package com.beowulf.account.controller;

import com.beowulf.account.services.AccountPayment;
import com.beowulf.model.request.AccountPaymentRequest;
import com.beowulf.model.request.DataETHRequest;
import com.beowulf.model.request.ListAddressETHRequest;
import com.beowulf.model.response.AccountPaymentResponse;
import com.beowulf.model.response.ListAddressETHResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "account")
@Validated
public class AccountPaymentController {
    @Autowired
    AccountPayment accountPayment;

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public AccountPaymentResponse createWallet(@Valid @RequestBody AccountPaymentRequest request) {
        return accountPayment.createAccountPayment(request);
    }

    @RequestMapping(value = "/response", method = RequestMethod.POST)
    public boolean checkAccountPayment(@RequestBody DataETHRequest request) {
        return accountPayment.checkAccountPayment(request);
    }

    @RequestMapping(value = "/add/ETH", method = RequestMethod.POST)
    public ListAddressETHResponse addETHAddress(@Valid @RequestBody ListAddressETHRequest request) {
        return accountPayment.addETHAddress(request);
    }

}
