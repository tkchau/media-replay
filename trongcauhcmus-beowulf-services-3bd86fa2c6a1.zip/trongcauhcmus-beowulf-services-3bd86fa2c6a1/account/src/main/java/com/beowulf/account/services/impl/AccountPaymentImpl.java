package com.beowulf.account.services.impl;

import com.beowulf.account.config.AccountServiceConfig;
import com.beowulf.account.documents.AddressPayment;
import com.beowulf.account.documents.PaymentHistory;
import com.beowulf.account.documents.PendingAccount;
import com.beowulf.account.documents.TransactionHistory;
import com.beowulf.account.repository.ETHAddressPaymentRepository;
import com.beowulf.account.repository.HistoryPaymentRepository;
import com.beowulf.account.repository.HistoryTransactionRepository;
import com.beowulf.account.repository.PendingAccountRepository;
import com.beowulf.account.services.AccountPayment;
import com.beowulf.account.services.BeowulfService;
import com.beowulf.constants.PaymentConstants;
import com.beowulf.constants.StatusAddress;
import com.beowulf.constants.StatusPayment;
import com.beowulf.constants.SupportedCoin;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.handler.communication.HttpHandler;
import com.beowulf.model.ethereum.ParsedAmountResponse;
import com.beowulf.model.request.*;
import com.beowulf.model.response.*;
import com.beowulf.utilities.*;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.plugins.apis.condenser.models.ExtendedAccount;
import com.beowulfchain.beowulfj.protocol.AccountName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.web3j.crypto.*;
import org.web3j.protocol.core.methods.response.TransactionReceipt;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
@EnableScheduling
public class AccountPaymentImpl implements AccountPayment {

    private final Logger logger = LoggerFactory.getLogger(AccountPayment.class);

    @Autowired
    BeowulfService beowulfService;

    @Autowired
    PendingAccountRepository pendingAccountRepository;

    @Autowired
    ETHAddressPaymentRepository ethAddressPaymentRepository;

    @Autowired
    HistoryPaymentRepository historyPaymentRepository;

    @Autowired
    HistoryTransactionRepository historyTransactionRepository;

    private static String value_ETH = "0";

    private static long block_highest = 0;

    private static BeowulfJ beowulfJ;

    @PostConstruct
    private void genKeyETH() {
        try {
            // Init network ETH
            beowulfJ = BeowulfCommunicate.init(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node());
            Web3JClient.init(AccountServiceConfig.getInstance().getEth_node());
            if (ethAddressPaymentRepository.count() == 0) {
                generateKeyETH(20);
            }
        } catch (Exception e) {
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Scheduled(initialDelay = 0, fixedDelay = 1000)
    private void getETHValue() {
        try {
            EtherResultResponse etherResultResponse = HttpHandler.getInstance().doGet(EtherResultResponse.class, PaymentConstants.URI_ETHER_VALUE, null);
            BigDecimal rateUSDWithETH = new BigDecimal(etherResultResponse.getResult().getEthusd());
            BigDecimal minFeeAccountPayment = new BigDecimal(PaymentConstants.MIN_FEE_ACCOUNT_PAYMENT);
            value_ETH = minFeeAccountPayment.divide(rateUSDWithETH, 8, BigDecimal.ROUND_CEILING).toString();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Scheduled(initialDelay = 0, fixedDelay = 86400000)
    private void getBlockNum() {
        try {
            block_highest = Web3JClient.blockNumber();
            logger.info(String.valueOf(block_highest));
        } catch (Exception e) {
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Scheduled(initialDelay = 0, fixedDelay = 10000)
    private void genNewKeyETH() {
        try {
            List<AddressPayment> addressPayments = ethAddressPaymentRepository.findAddressPaymentsByStatusAddress(StatusAddress.FREE.getStatus_address());
            if (addressPayments.size() < 10)
                generateKeyETH(10);
        } catch (Exception e) {
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public AccountPaymentResponse createAccountPayment(AccountPaymentRequest request) {
        DefinePaymentCreateAccountRequest define = new DefinePaymentCreateAccountRequest(PaymentConstants.EXPIRED_TIME);
        return accountPayment(request, define);
    }

    /**
     * Receiving information of account and putting into database if it is satisfied.
     *
     * @param request the AccountPaymentRequest object
     *                email: Your email
     *                account_name: Your name
     *                public_key: The key in your pair key
     *                asset_code: name coin paying
     * @param define  the DefinePaymentCreateAccountRequest object
     *                expired_time: Time to expired payment
     *                in_value: min fee create_account
     */
    public AccountPaymentResponse accountPayment(AccountPaymentRequest request, DefinePaymentCreateAccountRequest define) {
        try {
            logger.info("start payment to create account " + request.getAccount_name());
            AccountName accountName = new AccountName(request.getAccount_name());
            List<ExtendedAccount> accountDetail = beowulfJ.getAccounts(Collections.singletonList(accountName));
            if (!accountDetail.isEmpty()) {
                logger.error(request.getAccount_name() + " already exists");
                throw new InvalidParameterException("Your account_name already exists");
            }
            PendingAccount pendingAccountName = pendingAccountRepository.findPendingAccountByName(request.getAccount_name());
            if (pendingAccountName != null) {
                logger.error(pendingAccountName.getAccount_name() + " is being created");
                throw new InvalidParameterException("This account is being created");
            }
            if (!SupportedCoin.contain(request.getAsset_code())) {
                logger.error(request.getAsset_code() + " is invalid");
                throw new InvalidParameterException("Invalid asset code");
            }
            // send mail hello to check email valid
            String minFee = getMinFeeFromAssetCode(request.getAsset_code());
            assert minFee != null;
            int result = (new BigDecimal(minFee)).compareTo(new BigDecimal("0"));
            if (result <= 0) {
                throw new InvalidParameterException("in_value is wrong");
            }
            AddressPayment addressPayment = randomAddressPayment(ethAddressPaymentRepository.findAddressPaymentsByStatusAddress(StatusAddress.FREE.getStatus_address()));
            ethAddressPaymentRepository.updateStatus(addressPayment.getAddress(), StatusAddress.WAITING_PAYMENT.getStatus_address());
            String address = addressPayment.getAddress();
            int expiredTime = define.getExpired_time();
            long startTime = System.currentTimeMillis();
            String paymentId = UUID.randomUUID().toString();
            PendingAccount pendingAccount = new PendingAccount(
                    paymentId,
                    request,
                    startTime,
                    expiredTime,
                    minFee,
                    address,
                    0
            );
            pendingAccountRepository.save(pendingAccount);
            AccountPaymentResponse accountPaymentResponse = new AccountPaymentResponse(
                    paymentId,
                    address,
                    request,
                    minFee,
                    expiredTime
            );
            addHook(address);
            return accountPaymentResponse;
        } catch (InvalidParameterException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public boolean checkAccountPayment(DataETHRequest request) {
        if (request.getConfirmations() == 1) {
            logger.info("Transactions is detected");
            throw ServiceExceptionUtils.invalidRequestParam("Confirmation is not 12");
        } else if (request.getConfirmations() == 6) {
            logger.info("Transactions is confirming");
            throw ServiceExceptionUtils.invalidRequestParam("Confirmation is not 12");
        } else if (request.getConfirmations() == 12) {
            logger.info("Transactions is accepted");
            AddressPayment addressPayment = ethAddressPaymentRepository.findAddressPaymentByAddress(request.getAddress());
            if (addressPayment.getStatus_address() == 2) {
                throw ServiceExceptionUtils.internalServerError("Duplicate request");
            } else {
                ethAddressPaymentRepository.updateStatus(request.getAddress(), StatusAddress.CHECKING_PAYMENT.getStatus_address());
                return checkPayment(request);
            }
        } else {
            throw ServiceExceptionUtils.invalidRequestParam("Confirmations is not 12");
        }
    }

    private boolean checkPayment(DataETHRequest request) {
        try {
            if (request.isErc20()) {
                if (!SupportedCoin.contain(request.getCoinType())) {
                    logger.error(request.getCoinType() + "  is not support!!!");
                    throw new InvalidParameterException("Does not support this coin!!!");
                }
            }
            long highest_block = getHighestBlockNum();
            if ((block_highest - 5000) > request.getBlockNumber() || block_highest == 0 || (highest_block - request.getBlockNumber()) < 12) {
                logger.error("Error block number!!!");
                throw new InvalidParameterException("Error block number!!!");
            }
            long end_time = System.currentTimeMillis();
            PendingAccount pendingAccount = pendingAccountRepository.findAccountPendingAccountByAddress(request.getAddress());
            if (pendingAccount == null) {
                logger.error("Can not find account_created!!!");
                throw new InvalidParameterException("Can not find account_created!!!");
            }
            AddressPayment addressPayment = ethAddressPaymentRepository.findAddressPaymentByAddress(request.getAddress());
            if (addressPayment == null) {
                logger.error("Can not find address_payment!!!");
                throw new InvalidParameterException("Can not find address_payment!!!");
            }
            String value = getInValueNetwork(pendingAccount.getAsset_code(), request);
            if (checkTime(end_time, pendingAccount, addressPayment, request, value)) {
                logger.error("Over time!!!");
                throw new InvalidParameterException("Over time!!!");
            }
            if (checkInValue(end_time, value, pendingAccount, addressPayment, pendingAccount.getMin_fee_payment(), request)) {
                logger.error("Not enough fee!!!");
                throw new InvalidParameterException("Not enough fee!!!");
            }
            BeowulfCreateAccountRequest beowulfCreateAccountRequest = new BeowulfCreateAccountRequest(pendingAccount.getPub_key(), pendingAccount.getAccount_name());
            BeowulfCreateAccountResponse beowulfCreateAccountResponse = beowulfService.createAccount(beowulfCreateAccountRequest);
            logger.info(beowulfCreateAccountResponse.getTxid());
            if (beowulfCreateAccountResponse.getTxid() != null) {
                sendMail(pendingAccount.getAccount_name(), pendingAccount.getEmail());
            } else {
                sendMailError(pendingAccount.getAccount_name(), pendingAccount.getEmail());
                pendingAccountRepository.removeByAccountName(pendingAccount.getAccount_name());
                PaymentHistory paymentFailHistory = new PaymentHistory(
                        request.getHash(),
                        pendingAccount,
                        end_time,
                        value,
                        addressPayment,
                        StatusPayment.ERROR_NETWORK.getStatus_payment()
                );
                pendingAccountRepository.updateCount(request.getAddress(), 1);
                historyPaymentRepository.save(paymentFailHistory);
                logger.error("Can not to create account!!!");
                return true;
            }
            removeHook(request.getAddress());
            PaymentHistory paymentHistory = new PaymentHistory(
                    request.getHash(),
                    pendingAccount,
                    end_time,
                    value,
                    addressPayment,
                    StatusPayment.SUCCESS.getStatus_payment()
            );
            block_highest = request.getBlockNumber();
            historyTransactionRepository.save(new TransactionHistory(request));
            historyPaymentRepository.save(paymentHistory);
            pendingAccountRepository.removeByAccountName(pendingAccount.getAccount_name());
            ethAddressPaymentRepository.updateStatus(request.getAddress(), StatusAddress.FREE.getStatus_address());
            return true;
        } catch (InvalidParameterException e) {
            logger.error(e.getMessage());
            return false;
        } catch (ServiceException e) {
            logger.error(e.getDescription());
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    private String getInValueNetwork(String asset_code, DataETHRequest request) throws IOException {
        TransactionHistory transactionHistory = historyTransactionRepository.findHistoryTransactionByHash(request.getHash());
        if (transactionHistory != null) {
            throw new InvalidParameterException("The hash already exists");
        }
        TransactionReceipt transactionReceipt = Web3JClient.getTransactionReceiptByHash(request.getHash());
        ParsedAmountResponse parsedAmountResponse;
        if (asset_code.equals(SupportedCoin.ETH.toString()) && request.getHash().equals(transactionReceipt.getTransactionHash())) {
            parsedAmountResponse = Web3JClient.getTotalEtherAmountInTxn(request.getHash(), request.getAddress());
            assert parsedAmountResponse != null;
            BigDecimal bigDecimal = new BigDecimal(parsedAmountResponse.getIn_value().toString()).divide(new BigDecimal(SupportedCoin.ETH.getDecimal()), 8, BigDecimal.ROUND_CEILING);
            return bigDecimal.toString();
        } else if (asset_code.equals(SupportedCoin.BWF.toString()) && request.getHash().equals(transactionReceipt.getTransactionHash())) {
            parsedAmountResponse = Web3JClient.getTotalErc20AmountInTnx(transactionReceipt, request.getAddress(), request.getCoinType());
            BigDecimal bigDecimal = new BigDecimal(parsedAmountResponse.getIn_value().toString()).divide(new BigDecimal(SupportedCoin.BWF.getDecimal()), 5, BigDecimal.ROUND_CEILING);
            return bigDecimal.toString();
        } else if (asset_code.equals(SupportedCoin.USDT.toString()) && request.getHash().equals(transactionReceipt.getTransactionHash())) {
            parsedAmountResponse = Web3JClient.getTotalErc20AmountInTnx(transactionReceipt, request.getAddress(), request.getCoinType());
            BigDecimal bigDecimal = new BigDecimal(parsedAmountResponse.getIn_value().toString()).divide(new BigDecimal(SupportedCoin.USDT.getDecimal()), 2, BigDecimal.ROUND_CEILING);
            return bigDecimal.toString();
        } else if (asset_code.equals(SupportedCoin.TUSD.toString()) && request.getHash().equals(transactionReceipt.getTransactionHash())) {
            parsedAmountResponse = Web3JClient.getTotalErc20AmountInTnx(transactionReceipt, request.getAddress(), request.getCoinType());
            BigDecimal bigDecimal = new BigDecimal(parsedAmountResponse.getIn_value().toString()).divide(new BigDecimal(SupportedCoin.TUSD.getDecimal()), 2, BigDecimal.ROUND_CEILING);
            return bigDecimal.toString();
        } else {
            throw new InvalidParameterException("can not get value in network");
        }
    }

    @Override
    public ListAddressETHResponse addETHAddress(ListAddressETHRequest request) {
        try {
            String address = request.getAddress().toLowerCase();
            String private_key = request.getPrivate_key();
            String asset_code = request.getAsset_code();
            AddressPayment addressPayment = new AddressPayment(address, private_key, StatusAddress.FREE.getStatus_address(), asset_code);
            ListAddressETHResponse listAddressETHResponse = new ListAddressETHResponse(address, private_key, request.getAsset_code());
            ethAddressPaymentRepository.save(addressPayment);
            return listAddressETHResponse;
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    private AddressPayment randomAddressPayment(List<AddressPayment> addressPayments) {
        Random rand = new Random();
        return addressPayments.get(rand.nextInt(addressPayments.size()));
    }

    //GET FEE AND SAVE COLLECTION ACCOUNT_CREATED
    private String getMinFeeFromAssetCode(String asset_code) {
        if (asset_code.equals(SupportedCoin.ETH.toString())) {
            return value_ETH;
        } else if (asset_code.equals(SupportedCoin.BWF.toString())) {
            BigDecimal bigDecimal = new BigDecimal(PaymentConstants.MIN_FEE_ACCOUNT_PAYMENT).setScale(5, BigDecimal.ROUND_CEILING);
            return bigDecimal.toString();
        } else if (asset_code.equals(SupportedCoin.USDT.toString())) {
            return PaymentConstants.MIN_FEE_ACCOUNT_PAYMENT;
        } else if (asset_code.equals(SupportedCoin.TUSD.toString())) {
            return PaymentConstants.MIN_FEE_ACCOUNT_PAYMENT;
        } else {
            throw new InvalidParameterException("can not get min fee asset_code");
        }
    }

    private boolean checkCoinType(String asset_code, String coinType) {
        if (asset_code.equals(SupportedCoin.ETH.toString())) {
            return coinType.equals(SupportedCoin.ETH.getAddress());
        } else if (asset_code.equals(SupportedCoin.BWF.toString())) {
            return coinType.equals(SupportedCoin.BWF.getAddress());
        } else if (asset_code.equals(SupportedCoin.USDT.toString())) {
            return coinType.equals(SupportedCoin.USDT.getAddress());
        } else if (asset_code.equals(SupportedCoin.TUSD.toString())) {
            return coinType.equals(SupportedCoin.TUSD.getAddress());
        } else {
            throw new InvalidParameterException("can not check coin type");
        }
    }

    private boolean checkInValue(long end_time, String in_value, PendingAccount pendingAccount, AddressPayment addressPayment, String min_fee_payment, DataETHRequest request) {
        try {
            if (checkCoinType(pendingAccount.getAsset_code(), request.getCoinType())) {
                BigDecimal value_BD = new BigDecimal(in_value);
                BigDecimal min_fee_payment_BD = new BigDecimal(min_fee_payment);
                if (value_BD.compareTo(min_fee_payment_BD) < 0) {
                    ethAddressPaymentRepository.updateStatus(request.getAddress(), StatusAddress.FREE.getStatus_address());
                    pendingAccountRepository.removeByAccountName(pendingAccount.getAccount_name());
                    PaymentHistory paymentHistory = new PaymentHistory(
                            request.getHash(),
                            pendingAccount,
                            end_time,
                            in_value,
                            addressPayment,
                            StatusPayment.NOT_ENOUGH.getStatus_payment()
                    );
                    handleErrorTimeOrValue(request, paymentHistory, pendingAccount, ", Your fee is not enough!!!");
                    return true;
                }
                return false;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean checkTime(long end_time, PendingAccount pendingAccount, AddressPayment addressPayment, DataETHRequest request, String in_value) {
        try {
            if ((end_time - pendingAccount.getStart_time()) > pendingAccount.getExpired_time()) {
                ethAddressPaymentRepository.updateStatus(request.getAddress(), StatusAddress.FREE.getStatus_address());
                pendingAccountRepository.removeByAccountName(pendingAccount.getAccount_name());
                PaymentHistory paymentHistory = new PaymentHistory(
                        request.getHash(),
                        pendingAccount,
                        end_time,
                        in_value,
                        addressPayment,
                        StatusPayment.OVER_TIME.getStatus_payment()
                );
                handleErrorTimeOrValue(request, paymentHistory, pendingAccount, ", Your payment is over time!!!");
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private void handleErrorTimeOrValue(DataETHRequest request, PaymentHistory paymentHistory, PendingAccount pendingAccount, String message) throws Exception {
        historyTransactionRepository.save(new TransactionHistory(request));
        historyPaymentRepository.save(paymentHistory);
        removeHook(request.getAddress());
        String templateContent = pendingAccount.getAccount_name().toUpperCase() + message;
        String[] emails = {pendingAccount.getEmail()};
        AmazonSESSender.sendEmailToAddress("Beowulf create account failed", templateContent, emails);

    }

    private long getHighestBlockNum() {
        try {
            Web3JClient.init(AccountServiceConfig.getInstance().getEth_node());
            return Web3JClient.blockNumber();
        } catch (Exception e) {
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    private void sendMail(String account_name, String email) {
        logger.info(String.format("send mail for account %s", account_name));
        try {
            String[] emails = {email};
            AmazonSESSender.sendEmailToAddress("Beowulf create account success", "WELCOME " + account_name.toUpperCase() + " TO BEOWULF!!!", emails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendMailError(String account_name, String email) {
        logger.info(String.format("send mail for account %s", account_name));
        try {
            String[] emails = {email};
            AmazonSESSender.sendEmailToAddress("Beowulf are temporarily unable to create your account",
                    "We will try to recreate your account, if Beowulf still can not create account, Beowulf will refund you.", emails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addHook(String address) {
        try {
            OpenWebHookRequest openWebHookRequest = new OpenWebHookRequest(address, PaymentConstants.URI_WEB_HOOK);
            ResultHookResponse resultHookResponse = HttpHandler.getInstance().doPost(openWebHookRequest, ResultHookResponse.class, PaymentConstants.URI_ADD_HOOK, null);
            System.out.println(resultHookResponse.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    public void removeHook(String address) {
        try {
            CloseWebHookRequest closeWebHookRequest = new CloseWebHookRequest(address);
            ResultHookResponse resultHookResponse = HttpHandler.getInstance().doPost(closeWebHookRequest, ResultHookResponse.class, PaymentConstants.URI_REMOVE_HOOK, null);
            System.out.println(resultHookResponse.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();

        }
    }

    @Scheduled(initialDelay = 60000, fixedDelay = 60000)
    private void handleAddress() {
        List<AddressPayment> addressPayments = ethAddressPaymentRepository.findAddressPaymentsByStatusAddress(StatusAddress.WAITING_PAYMENT.getStatus_address());
        for (AddressPayment addressPayment : addressPayments) {
            PendingAccount pendingAccount = pendingAccountRepository.findAccountPendingAccountByAddress(addressPayment.getAddress());
            long end_time = System.currentTimeMillis();
            if ((end_time - pendingAccount.getStart_time()) > pendingAccount.getExpired_time()) {
                PaymentHistory paymentHistory = new PaymentHistory(
                        "0",
                        pendingAccount,
                        end_time,
                        "0",
                        addressPayment,
                        StatusPayment.NOT_PAYMENT.getStatus_payment()
                );
                removeHook(pendingAccount.getAddress());
                this.historyPaymentRepository.save(paymentHistory);
                ethAddressPaymentRepository.updateStatus(addressPayment.getAddress(), StatusAddress.FREE.getStatus_address());
                pendingAccountRepository.removeByAccountName(pendingAccount.getAccount_name());
            }
        }
    }

    @Scheduled(initialDelay = 60000, fixedDelay = 60000)
    private void handleFailNetwork() throws Exception {
        List<PendingAccount> pendingAccount3s = pendingAccountRepository.findPendingAccountsByCount(3);
        if (pendingAccount3s != null) {
            for (PendingAccount pendingAccount3 : pendingAccount3s) {
                BeowulfCreateAccountRequest beowulfCreateAccountRequest = new BeowulfCreateAccountRequest(pendingAccount3.getPub_key(), pendingAccount3.getAccount_name());
                BeowulfCreateAccountResponse beowulfCreateAccountResponse = beowulfService.createAccount(beowulfCreateAccountRequest);
                logger.info(beowulfCreateAccountResponse.getTxid());
                if (beowulfCreateAccountResponse.getTxid() != null) {
                    logger.info(pendingAccount3.getAccount_name() + " is created success");
                    sendMail(pendingAccount3.getAccount_name(), pendingAccount3.getEmail());
                } else {
                    pendingAccountRepository.removeByAccountName(pendingAccount3.getAccount_name());
                    logger.error("Three times failed to create" + pendingAccount3.getAccount_name());
                }
            }
        }
        List<PendingAccount> pendingAccount2s = pendingAccountRepository.findPendingAccountsByCount(2);
        if (pendingAccount2s != null) {
            for (PendingAccount pendingAccount2 : pendingAccount2s) {
                BeowulfCreateAccountRequest beowulfCreateAccountRequest = new BeowulfCreateAccountRequest(pendingAccount2.getPub_key(), pendingAccount2.getAccount_name());
                BeowulfCreateAccountResponse beowulfCreateAccountResponse = beowulfService.createAccount(beowulfCreateAccountRequest);
                logger.info(beowulfCreateAccountResponse.getTxid());
                if (beowulfCreateAccountResponse.getTxid() != null) {
                    logger.info(pendingAccount2.getAccount_name() + " is created success");
                    sendMail(pendingAccount2.getAccount_name(), pendingAccount2.getEmail());
                } else {
                    logger.error("Two times failed to create" + pendingAccount2.getAccount_name());
                    pendingAccountRepository.updateCount(pendingAccount2.getAddress(), 3);
                }
            }
        }
        List<PendingAccount> pendingAccounts = pendingAccountRepository.findPendingAccountsByCount(1);
        if (pendingAccounts != null) {
            for (PendingAccount pendingAccount : pendingAccounts) {
                BeowulfCreateAccountRequest beowulfCreateAccountRequest = new BeowulfCreateAccountRequest(pendingAccount.getPub_key(), pendingAccount.getAccount_name());
                BeowulfCreateAccountResponse beowulfCreateAccountResponse = beowulfService.createAccount(beowulfCreateAccountRequest);
                logger.info(beowulfCreateAccountResponse.getTxid());
                if (beowulfCreateAccountResponse.getTxid() != null) {
                    logger.info(pendingAccount.getAccount_name() + " is created success");
                    sendMail(pendingAccount.getAccount_name(), pendingAccount.getEmail());
                } else {
                    logger.error("One time failed to create" + pendingAccount.getAccount_name());
                    pendingAccountRepository.updateCount(pendingAccount.getAddress(), 2);
                }
            }
        }
    }

    private void generateKeyETH(int amount) {
        try {
            for (int i = 0; i < amount; i++) {
                String seed = UUID.randomUUID().toString();
                ECKeyPair ecKeyPair = Keys.createEcKeyPair();
                BigInteger privateKeyInDec = ecKeyPair.getPrivateKey();
                String privateKey = privateKeyInDec.toString(16);
                String privateKeyEncrypt = AESEncryptor.encrypt(PaymentConstants.KEY_HASH, PaymentConstants.INIT_VECTOR, privateKey);

                WalletFile aWallet = Wallet.createLight(seed, ecKeyPair);
                String sAddress = aWallet.getAddress();
                String address = "0x" + sAddress;

                String asset_code = "ETH";
                AddressPayment addressPayment = new AddressPayment(address.toLowerCase(), privateKeyEncrypt, StatusAddress.FREE.getStatus_address(), asset_code);
                ethAddressPaymentRepository.save(addressPayment);
                //            System.out.println(Arrays.toString(new String[]{address, private_key}));
            }
        } catch (NoSuchAlgorithmException | CipherException | NoSuchProviderException | InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }
    }

    private String getOriginalPrivateKey(String privateKeyEncrypted) {
        return AESEncryptor.decrypt(PaymentConstants.KEY_HASH, PaymentConstants.INIT_VECTOR, privateKeyEncrypted);
    }

}






