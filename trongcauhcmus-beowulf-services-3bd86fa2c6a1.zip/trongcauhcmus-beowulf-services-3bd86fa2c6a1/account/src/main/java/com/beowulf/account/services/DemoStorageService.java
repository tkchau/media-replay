package com.beowulf.account.services;

import com.beowulf.model.request.DemoCertificateRequest;
import com.beowulf.model.request.DemoLandRegistryRequest;
import com.beowulf.model.response.DemoCertificateResponse;
import com.beowulf.model.response.DemoLandRegistryResponse;

public interface DemoStorageService {
    DemoCertificateResponse pushCertificateRegistry(DemoCertificateRequest request);

    DemoLandRegistryResponse pushLandRegistry(DemoLandRegistryRequest request);
}
