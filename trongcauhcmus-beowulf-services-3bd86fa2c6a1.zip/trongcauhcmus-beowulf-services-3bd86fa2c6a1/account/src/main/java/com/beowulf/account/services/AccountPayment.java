package com.beowulf.account.services;

import com.beowulf.model.request.AccountPaymentRequest;
import com.beowulf.model.request.DataETHRequest;
import com.beowulf.model.request.ListAddressETHRequest;
import com.beowulf.model.response.AccountPaymentResponse;
import com.beowulf.model.response.ListAddressETHResponse;

public interface AccountPayment {

    AccountPaymentResponse createAccountPayment(AccountPaymentRequest request);

    boolean checkAccountPayment(DataETHRequest request);

    ListAddressETHResponse addETHAddress(ListAddressETHRequest request);

}
