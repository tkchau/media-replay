package com.beowulf.account.services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface CustomApiKeyDetailsService extends UserDetailsService {
}
