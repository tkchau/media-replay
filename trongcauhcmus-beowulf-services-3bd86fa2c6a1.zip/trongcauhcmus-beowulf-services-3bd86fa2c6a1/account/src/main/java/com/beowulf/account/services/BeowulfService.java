package com.beowulf.account.services;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.model.request.BeowulfAccountAirdropRequest;
import com.beowulf.model.request.BeowulfCreateAccountRequest;
import com.beowulf.model.request.BeowulfCreateMultisigAccountRequest;
import com.beowulf.model.response.BeowulfAccountAirdropResponse;
import com.beowulf.model.response.BeowulfCreateAccountResponse;
import com.beowulf.model.response.BeowulfCreateMultisigAccountResponse;

public interface BeowulfService {
    BeowulfCreateAccountResponse createAccount(BeowulfCreateAccountRequest request) throws Exception;

    BeowulfCreateMultisigAccountResponse createMultisigAccount(BeowulfCreateMultisigAccountRequest request) throws Exception;

    BeowulfCreateAccountResponse createAccountByApikey(ApiKey apiKey, BeowulfCreateAccountRequest request) throws Exception;

    BeowulfAccountAirdropResponse accountAirdrop(BeowulfAccountAirdropRequest request) throws Exception;
}
