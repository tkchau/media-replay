package com.beowulf.account.controller;

import com.beowulf.model.request.DragVerifyRequest;
import com.beowulf.utilities.DragCaptchaUtil;
import com.beowulf.utilities.HttpServletUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping(value = "/drag")
public class RestDragCaptchaController {

    @RequestMapping(value = "", method = RequestMethod.GET)
    public Object genNewDrag(HttpServletRequest request) {
        System.out.println("generate drag captcha client ip: " + HttpServletUtils.getClientIP(request));
        return DragCaptchaUtil.generateDragResponse();
    }

    @RequestMapping(value = "/verify", method = RequestMethod.POST)
    public void verify(HttpServletRequest request,
                       HttpServletResponse response,
                       @RequestBody DragVerifyRequest verifyRequest) {
        System.out.println("verify drag client ip: " + HttpServletUtils.getClientIP(request));
        if (DragCaptchaUtil.activateDragToken(verifyRequest.getToken(), verifyRequest.getX()))
            response.setStatus(200);
        else response.setStatus(400);
    }
}
