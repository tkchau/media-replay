package com.beowulf.account.services.impl;

import com.amazonaws.services.simpleemail.model.Destination;
import com.beowulf.account.services.AmazonSESService;
import com.beowulf.handler.MyWorkerMonitorHandler;
import com.beowulf.handler.RejectedExecutionHandlerImpl;
import com.beowulf.utilities.FileUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.StringUtils;
import com.beowulf.worker.AmazonSESWorker;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;

@Service
@EnableScheduling
public class AmazonSESServiceImpl implements AmazonSESService {
    private static final String TAG = AmazonSESServiceImpl.class.getName();

    private RejectedExecutionHandlerImpl rejectedExecutionHandler;
    private ThreadFactory threadFactory;
    private ThreadPoolExecutor executorPool;
    private MyWorkerMonitorHandler monitorHandler;
    private Thread monitorThread;

    @PostConstruct
    public void onStart() {
        try {
            rejectedExecutionHandler = new RejectedExecutionHandlerImpl();
            threadFactory = Executors.defaultThreadFactory();
            executorPool = new ThreadPoolExecutor(10, 50, 5, TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(50), threadFactory, rejectedExecutionHandler);
            monitorHandler = new MyWorkerMonitorHandler(TAG, executorPool, 60);
            monitorThread = new Thread(monitorHandler);
            monitorThread.start();
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
    }

    @PreDestroy
    public void onDestroy() {
        try {
            executorPool.shutdown();
            monitorHandler.shutdown();
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
    }

    private boolean sendEmail(JsonObject jsonObject, String templateName) {

        try {
            String receiver = jsonObject.get("receiver").getAsString();
            String title = jsonObject.get("title").getAsString();
            LoggerUtil.i(TAG, "Send email via Amazon SES to  : " + receiver);


            String templateContent = FileUtils.getTemplate(templateName);

            if (StringUtils.isEmpty(templateContent)) {
                LoggerUtil.e(TAG, "Send email error because template name does not exist");
                return false;
            }

            Destination destination = new Destination();
            destination.withToAddresses(receiver);
            if (jsonObject.get("bcc") != null) {
                destination.withBccAddresses(jsonObject.get("bcc").getAsString());
            }

            JsonObject parameterList = jsonObject.get("parameterList").getAsJsonObject();
            Set<Map.Entry<String, JsonElement>> entrySet = parameterList.entrySet();
            for (Map.Entry<String, JsonElement> entry : entrySet) {
                templateContent = templateContent.replaceAll(entry.getKey(), entry.getValue() == null ? "" : entry.getValue().getAsString());
            }
            executorPool.execute(new AmazonSESWorker(templateContent, title, destination));
            return true;
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return false;
    }

    @Override
    public boolean sendEmailConfirmRegister(String title, String email, String nickName, String linkRegister,
                                            String linkImage, String language, String time) {
        try {
            JsonObject data = new JsonObject();
            data.addProperty("receiver", email);
            data.addProperty("title", title);
            JsonObject params = new JsonObject();
            params.addProperty("@link_email@", linkRegister);
            params.addProperty("@link_image@", linkImage);
            params.addProperty("@nick_name@", nickName);
            params.addProperty("@time@", time);
            data.add("parameterList", params);
            return sendEmail(data, "email_templates/" + language + "/email_verify_register.html");
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return false;
    }
}
