package com.beowulf.account.services;

import com.beowulf.model.request.CreateApiKeyRequest;
import com.beowulf.model.response.ApiKeyResponse;

public interface ApiKeyService {
    ApiKeyResponse createApiKey(CreateApiKeyRequest request);

    boolean verifyApikey(String apikey);
}
