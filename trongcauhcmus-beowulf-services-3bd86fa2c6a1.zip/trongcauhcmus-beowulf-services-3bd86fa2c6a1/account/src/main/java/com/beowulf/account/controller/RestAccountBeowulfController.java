package com.beowulf.account.controller;

import com.beowulf.account.services.BeowulfService;
import com.beowulf.annotations.GoogleRecaptchaValidated;
import com.beowulf.annotations.RequestThottlingValidated;
import com.beowulf.model.request.BeowulfAccountAirdropRequest;
import com.beowulf.model.response.BeowulfAccountAirdropResponse;
import com.beowulf.utilities.HttpServletUtils;
import com.beowulf.utilities.LoggerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.TimeUnit;

/**
 * @author trongcauta
 * @time 11:12 AM
 * @data 6/3/19
 */
@RestController
@RequestMapping(value = "/account")
@Validated
public class RestAccountBeowulfController {

    @Autowired
    BeowulfService beowulfService;

    @RequestMapping(value = "airdrop", method = RequestMethod.POST)
    @ResponseBody
    public BeowulfAccountAirdropResponse createWalletByCaptcha(
            @GoogleRecaptchaValidated @RequestHeader(name = "captcha") String captcha,
            @RequestBody BeowulfAccountAirdropRequest request,
            @RequestThottlingValidated(timeUnit = TimeUnit.HOURS, rate = 1) HttpServletRequest httpServletRequest) throws Exception {
        LoggerUtil.w(this, HttpServletUtils.getClientIP(httpServletRequest));
        try {
            return beowulfService.accountAirdrop(request);
        } catch (Exception e) {
            HttpServletUtils.decreaseRequest(httpServletRequest, TimeUnit.HOURS);
            throw e;
        }
    }
}
