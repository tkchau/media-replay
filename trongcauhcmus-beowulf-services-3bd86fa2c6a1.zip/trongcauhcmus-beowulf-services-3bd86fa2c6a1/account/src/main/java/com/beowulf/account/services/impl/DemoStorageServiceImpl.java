package com.beowulf.account.services.impl;

import com.beowulf.account.config.AccountServiceConfig;
import com.beowulf.account.services.DemoStorageService;
import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.document.certdata.CertificateType;
import com.beowulf.certificate.repository.AcademicCertificateRepository;
import com.beowulf.model.request.DemoCertificateRequest;
import com.beowulf.model.request.DemoLandRegistryRequest;
import com.beowulf.model.response.DemoCertificateResponse;
import com.beowulf.model.response.DemoLandRegistryResponse;
import com.beowulf.utilities.AESEncryptor;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.chain.NetworkProperties;
import com.beowulfchain.beowulfj.configuration.BeowulfJConfig;
import com.beowulfchain.beowulfj.enums.PrivateKeyType;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.AccountName;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.ExtensionValue;
import com.beowulfchain.beowulfj.protocol.TransactionId;
import com.beowulfchain.beowulfj.protocol.enums.AssetSymbolType;
import com.beowulfchain.beowulfj.protocol.extensions.JsonExtension;
import com.beowulfchain.beowulfj.protocol.operations.TransferOperation;
import com.google.gson.Gson;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class DemoStorageServiceImpl implements DemoStorageService {

    private static Gson gson;

    private static BeowulfJ beowulfJ;
    private static NetworkProperties network;
    private static AccountName university;
    private static AccountName major;
    private static AccountName notary;
    private static AccountName region;

    @Autowired
    private AcademicCertificateRepository academicCertificateRepository;

    static {
        try {
            initNetwork();
            gson = GsonSingleton.builder().setDateFormat(DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT.getPattern()).create();
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DemoCertificateResponse pushCertificateRegistry(DemoCertificateRequest request) {
        try {
            Asset transferAmount = new Asset(1L, AssetSymbolType.BWF);
            TransferOperation transferOperation = beowulfJ.transfer(university, major, transferAmount, network.getTransactionFee(), "");
            request.setType(CertificateType.ACADEMIC_CERTIFICATE);

            BeowulfAcademicCertificate existedCert = this.academicCertificateRepository.findAcademicCertificateBySerialNum(request.getSerial_num());
            if (existedCert != null) {
                throw new IllegalArgumentException("Existed Serial Num");
            }
            ExtensionValue value = new ExtensionValue(gson.toJson(request));
            JsonExtension extension = new JsonExtension(value);
            TransactionId transactionId = beowulfJ.signAndBroadcastWithExtension(Collections.singletonList(transferOperation), Collections.singletonList(extension));
            DemoCertificateResponse response = new DemoCertificateResponse();
            response.setTransactionId(transactionId.toString());
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public DemoLandRegistryResponse pushLandRegistry(DemoLandRegistryRequest request) {
        try {
            Asset transferAmount = new Asset(1L, AssetSymbolType.BWF);
            TransferOperation transferOperation = beowulfJ.transfer(notary, region, transferAmount, network.getTransactionFee(), "");
            request.setType(CertificateType.LAND_CERTIFICATE);
            ExtensionValue value = new ExtensionValue(gson.toJson(request));
            JsonExtension extension = new JsonExtension(value);
            TransactionId transactionId = beowulfJ.signAndBroadcastWithExtension(Collections.singletonList(transferOperation), Collections.singletonList(extension));
            DemoLandRegistryResponse response = new DemoLandRegistryResponse();
            response.setTransactionId(transactionId.toString());
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    private static BeowulfJ initNetwork() throws BeowulfCommunicationException, BeowulfResponseException {
        beowulfJ = BeowulfCommunicate.init(AccountServiceConfig.getInstance().getBeowulf_node());
        network = BeowulfJConfig.getInstance().getNetwork();
        BeowulfJConfig myConfig = BeowulfJConfig.getInstance();

        university = AccountServiceConfig.getInstance().getCredential_account_beowulf_university_name();
        List<ImmutablePair<PrivateKeyType, String>> university_key = new ArrayList<>();
        university_key.add(new ImmutablePair<>(PrivateKeyType.OWNER,
                AESEncryptor.decrypt(AccountServiceConfig.getInstance().getCrypto_aes_secretkey(),
                        AccountServiceConfig.getInstance().getCrypto_aes_initVector(),
                        AccountServiceConfig.getInstance().getCredential_account_beowulf_university_cipherPrivkey())));
        myConfig.getPrivateKeyStorage().addAccount(university, university_key);

        major = AccountServiceConfig.getInstance().getCredential_account_beowulf_major_name();
        List<ImmutablePair<PrivateKeyType, String>> major_key = new ArrayList<>();
        major_key.add(new ImmutablePair<>(PrivateKeyType.OWNER,
                AESEncryptor.decrypt(AccountServiceConfig.getInstance().getCrypto_aes_secretkey(),
                        AccountServiceConfig.getInstance().getCrypto_aes_initVector(),
                        AccountServiceConfig.getInstance().getCredential_account_beowulf_major_cipherPrivkey())));
        myConfig.getPrivateKeyStorage().addAccount(major, major_key);

        notary = AccountServiceConfig.getInstance().getCredential_account_beowulf_notary_name();
        List<ImmutablePair<PrivateKeyType, String>> notary_key = new ArrayList<>();
        notary_key.add(new ImmutablePair<>(PrivateKeyType.OWNER,
                AESEncryptor.decrypt(AccountServiceConfig.getInstance().getCrypto_aes_secretkey(),
                        AccountServiceConfig.getInstance().getCrypto_aes_initVector(),
                        AccountServiceConfig.getInstance().getCredential_account_beowulf_notary_cipherPrivkey())));
        myConfig.getPrivateKeyStorage().addAccount(notary, notary_key);

        region = AccountServiceConfig.getInstance().getCredential_account_beowulf_region_name();
        List<ImmutablePair<PrivateKeyType, String>> region_key = new ArrayList<>();
        region_key.add(new ImmutablePair<>(PrivateKeyType.OWNER,
                AESEncryptor.decrypt(AccountServiceConfig.getInstance().getCrypto_aes_secretkey(),
                        AccountServiceConfig.getInstance().getCrypto_aes_initVector(),
                        AccountServiceConfig.getInstance().getCredential_account_beowulf_region_cipherPrivkey())));
        myConfig.getPrivateKeyStorage().addAccount(region, region_key);
        return beowulfJ;
    }
}
