package com.beowulf.account.controller;

import com.beowulf.account.services.ApiKeyService;
import com.beowulf.model.request.CreateApiKeyRequest;
import com.beowulf.model.response.ApiKeyResponse;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value = "/api-key")
public class RestApiKeyController {

    @Autowired
    ApiKeyService apiKeyService;

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ApiKeyResponse createApiKey(HttpServletRequest request,
                                       @RequestBody CreateApiKeyRequest createApiKeyRequest) {
        if (request.getHeader("Authorization").equals("vungoimora")) {
            throw ServiceExceptionUtils.unauthorization();
        }
        return apiKeyService.createApiKey(createApiKeyRequest);
    }
}
