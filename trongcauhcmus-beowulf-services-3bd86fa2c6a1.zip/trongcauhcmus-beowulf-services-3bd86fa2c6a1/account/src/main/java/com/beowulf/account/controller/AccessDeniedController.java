package com.beowulf.account.controller;

import com.beowulf.annotations.DragCaptchaValidated;
import com.beowulf.utilities.RequestRateCaching;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping(value = "/access-denied")
@Validated
public class AccessDeniedController {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public void accessDenied(HttpServletRequest request) {
        throw ServiceExceptionUtils.unauthorization();
    }

    @RequestMapping(value = "/restrict_ip", method = RequestMethod.GET)
    public Object listAllRestrictIp(@RequestParam(value = "timeUnit") String timeUnit,
                                    @DragCaptchaValidated(bypass = "1233937239938953") HttpServletRequest httpServletRequest) {
        return RequestRateCaching.listAll(TimeUnit.valueOf(timeUnit.toUpperCase()));
    }

    @RequestMapping(value = "/reset", method = RequestMethod.GET)
    public Object resetIp(@RequestParam(value = "ip") String ip,
                          @RequestParam(value = "rate") int rate,
                          @RequestParam(value = "timeUnit") String timeUnit,
                          @DragCaptchaValidated(bypass = "1233937239938953") HttpServletRequest httpServletRequest) {
        try {
            RequestRateCaching.get(ip, TimeUnit.valueOf(timeUnit.toUpperCase()));
            RequestRateCaching.put(ip, rate, TimeUnit.valueOf(timeUnit.toUpperCase()));
            return true;
        } catch (ExecutionException e) {
            throw ServiceExceptionUtils.addressNotFound();
        }
    }
}
