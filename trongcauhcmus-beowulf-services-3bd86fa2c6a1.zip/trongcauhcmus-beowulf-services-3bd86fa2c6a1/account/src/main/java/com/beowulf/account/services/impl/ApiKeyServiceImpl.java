package com.beowulf.account.services.impl;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.documents.ApiKeyLevel;
import com.beowulf.account.repository.ApiKeyLevelRepository;
import com.beowulf.account.repository.ApiKeyRepository;
import com.beowulf.account.services.ApiKeyService;
import com.beowulf.constants.ApiKeyStatus;
import com.beowulf.constants.ApiKeyType;
import com.beowulf.model.request.CreateApiKeyRequest;
import com.beowulf.model.response.ApiKeyResponse;
import com.beowulf.utilities.ApiKeyUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulf.utilities.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class ApiKeyServiceImpl implements ApiKeyService {

    @Autowired
    ApiKeyRepository apiKeyRepository;

    @Autowired
    ApiKeyLevelRepository apiKeyLevelRepository;

    @Override
    public ApiKeyResponse createApiKey(CreateApiKeyRequest request) {
        try {
            ApiKey apiKey = new ApiKey();

            // check api key level
            if (StringUtils.isEmpty(request.getLevel())) {
                throw ServiceExceptionUtils.levelNotFound();
            }

            ApiKeyLevel level = apiKeyLevelRepository.findApiKeyLevelByApiKeyLevel(request.getLevel());
            if (level == null) {
                throw ServiceExceptionUtils.levelNotFound();
            }
            apiKey.setApi_key_level(level.getApi_key_level());
            apiKey.setCreate_wallet_counting_per_day(level.getMax_number_wallet());

            String accessToken = UUID.randomUUID().toString();
            apiKey.setApi_key(UUID.randomUUID().toString());
            apiKey.setAccess_token(ApiKeyUtils.encryptToken(accessToken));
            apiKey.setApi_name(request.getLabel());
            apiKey.setCreated_at(System.currentTimeMillis());
            apiKey.setStatus(ApiKeyStatus.ENABLE);
            apiKey.setUpdated_at(System.currentTimeMillis());

            apiKey = apiKeyRepository.save(apiKey);

            ApiKeyResponse response = new ApiKeyResponse();
            response.setToken_type(ApiKeyType.BASIC);
            response.setAccess_token(ApiKeyUtils.createBasicAccessToken(apiKey.getApi_key(), accessToken));
            LoggerUtil.w("apikey", "created: " + response.getAccess_token());
            return response;
        } catch (DuplicateKeyException e) {
            throw ServiceExceptionUtils.apikeyExisted();
        }
    }

    @Override
    public boolean verifyApikey(String apikey) {
        ApiKey apiKeyObj = apiKeyRepository.findApiKeyByApiKeyId(apikey);
        //todo: check api key expire quota
        return apikey != null;
    }
}
