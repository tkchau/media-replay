package com.beowulf.explorer.crawler;

import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.repository.BeowulfAccountRepository;
import com.beowulf.model.response.SupernodeDetailResponse;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.RedisUtils;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.plugins.apis.database.models.Supernode;
import com.beowulfchain.beowulfj.protocol.AccountName;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@EnableScheduling
@Component
public class CrawlSupernodeData {

    private final Logger logger = LoggerFactory.getLogger(CrawlSupernodeData.class);
    private static Map<String, Supernode> SUPERNODES = new HashMap<>();

    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @PostConstruct
    public void onStartup() {
        System.out.println("Start get supernode data");
        purgeSupernodesData();
        getSupernodesData();
    }

    /**
     * Getting top list super-node by vote from Beowulf Block-chain
     * and putting into Map (run in scheduled 60s)
     */
    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void getSupernodeDetails() {
        try {
            List<Supernode> supernodeDetails = BeowulfCommunicate.getBeowulfJ().getSupernodesByVote(new AccountName(""), 1000, 0);
            if (supernodeDetails != null && supernodeDetails.size() > 0) {
                SUPERNODES.clear();
                boolean needToUpdateCache = false;
                for (Supernode supernodeDetail : supernodeDetails) {
                    if (!RedisUtils.exists(Constant.SUPERNODE_CACHE_PRE_FIX + supernodeDetail.getOwner())) {
                        needToUpdateCache = true;
                    }
                    SUPERNODES.put(supernodeDetail.getOwner().getName(), supernodeDetail);
                }
                if (needToUpdateCache) {
                    this.logger.info("==> EXPLORER: " +
                            "[Crawling Super-node] - Start getting data of super-node in 1m period");
                    purgeSupernodesData();
                    getSupernodesData();
                }
            }
        } catch (BeowulfCommunicationException | BeowulfResponseException | NullPointerException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Can not get top list super-node by vote from Beowulf Network");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Can not get list super-node with Error: ");
            e.printStackTrace();
        }
    }

    /**
     * Remove old cached data
     */
    @Scheduled(initialDelay = 300000, fixedDelay = 300000)
    private void purgeSupernodesData() {
        try {
            Set<String> cachedSupernodeNames = RedisUtils.getAllKey(Constant.SUPERNODE_CACHE_PRE_FIX);
            if (cachedSupernodeNames != null) {
                this.logger.info("==> EXPLORER: " +
                        "[Crawling Super-node] - Start purging data of super-node");
                for (String supernodeKeyName : cachedSupernodeNames) {
                    RedisUtils.delete(supernodeKeyName);
                }
            }
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Can not purge cached super-node data with Error: ");
            e.printStackTrace();
        }
    }

    /**
     * Getting data of Super-node in Map and AccountRepository and
     * putting in Super-node Redis hash-map
     */
    private void getSupernodesData() {
        if (SUPERNODES != null && SUPERNODES.size() > 0) {
            this.logger.info("==> EXPLORER: " +
                    "[Crawling Super-node] - Number super-node: {}", SUPERNODES.size());
            for (String supernodeName : SUPERNODES.keySet()) {
                new Thread(() -> {
                    try {
                        if (!RedisUtils.exists(Constant.SUPERNODE_CACHE_PRE_FIX + supernodeName)) {
                            SupernodeDetailResponse supernodeDetailResponse = null;
                            BeowulfAccount supernodeAccount = beowulfAccountRepository.findAccountByName(supernodeName);
                            if (supernodeAccount != null) {
                                supernodeDetailResponse = new SupernodeDetailResponse(SUPERNODES.get(supernodeName));
                                supernodeDetailResponse.setTotal_confirmed_blocks(supernodeAccount.getTotal_mined_block());
                                supernodeDetailResponse.setTotal_block_rewards(supernodeAccount.getTotal_mined_reward());
                                supernodeDetailResponse.setTotal_fee_mined(supernodeAccount.getTotal_mined_fee());
                                supernodeDetailResponse.setTotal_confirmed_operations(supernodeAccount.getTotal_confirmed_operation());
                            }
                            RedisUtils.set(
                                    Constant.SUPERNODE_CACHE_PRE_FIX + supernodeName,
                                    GsonSingleton.getInstance().toJson(supernodeDetailResponse));
                            this.logger.info("==> EXPLORER: " +
                                    "[Crawling Super-node] - Put super-node: {} to caching successfully", supernodeName);
                        }
                    } catch (Exception e) {
                        this.logger.error("==> EXPLORER: " +
                                "[Crawling Super-node] - Can not put super-node to caching Redis with Error: ");
                        e.printStackTrace();
                    }
                }).start();
            }
        }
    }

    /**
     * Updating Super-node Redis hash-map when Block-chain has new block.
     */
    void updateDataSupernodeInCache(String supernodeName) {
        try {
            String keyRedis = Constant.SUPERNODE_CACHE_PRE_FIX + supernodeName;
            Gson gson = GsonSingleton.getInstance();
            if (RedisUtils.exists(keyRedis)) {
                String data = RedisUtils.get(keyRedis);
                SupernodeDetailResponse supernodeDetailResponse = gson.fromJson(data, SupernodeDetailResponse.class);

                BeowulfAccount supernodeAccount = beowulfAccountRepository.findAccountByName(supernodeName);
                if (supernodeAccount != null) {
                    supernodeDetailResponse.setTotal_confirmed_blocks(supernodeAccount.getTotal_mined_block());
                    supernodeDetailResponse.setTotal_block_rewards(supernodeAccount.getTotal_mined_reward());
                    supernodeDetailResponse.setTotal_fee_mined(supernodeAccount.getTotal_mined_fee());
                    supernodeDetailResponse.setTotal_confirmed_operations(supernodeAccount.getTotal_confirmed_operation());
                }
                RedisUtils.set(
                        keyRedis,
                        gson.toJson(supernodeDetailResponse)
                );
            }
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Can not update super-node in cache Redis with Error: ");
            e.printStackTrace();
        }
    }
}
