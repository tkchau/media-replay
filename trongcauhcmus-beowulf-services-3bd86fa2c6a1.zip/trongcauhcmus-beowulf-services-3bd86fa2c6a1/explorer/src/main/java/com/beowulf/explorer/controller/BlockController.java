package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.BlockService;
import com.beowulf.model.request.ListBlockPagingRequest;
import com.beowulf.model.request.ListBlocksByBlockNumberPagingRequest;
import com.beowulf.model.response.BlockDetailExtendResponse;
import com.beowulf.model.response.BlockDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import java.util.List;

@RestController
@RequestMapping(value = "v1/block", produces = "application/json; charset=UTF-8")
@Validated
public class BlockController {
    @Autowired
    private BlockService blockService;

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public long countTotalBlock() {
        return blockService.getTotalBlock();
    }

    @RequestMapping(value = "/number/{block_number}", method = RequestMethod.GET)
    public BlockDetailResponse getBlockDetailByBlockNum(
            @Valid
            @PathVariable("block_number")
            @Min(value = 1, message = "Block number must be greater than 0") Long blockNumber) {
        return blockService.getBlockDetailByBlockNum(blockNumber);
    }

    @RequestMapping(value = "/ext/number/{block_number}", method = RequestMethod.GET)
    public BlockDetailExtendResponse getBlockDetailExtendByBlockNum(
            @Valid
            @PathVariable("block_number")
            @Min(value = 1, message = "Block number must be greater than 0") Long blockNumber) {
        return blockService.getBlockDetailExtendByBlockNum(blockNumber);
    }

    @RequestMapping(value = "/ext/id/{id}", method = RequestMethod.GET)
    public BlockDetailExtendResponse getBlockDetailExtendByBlockID(@PathVariable("id") String blockId) {
        return blockService.getBlockDetailExtendByBlockID(blockId);
    }

    @RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
    public BlockDetailResponse getBlockDetailByBlockID(@PathVariable("id") String blockId) {
        return blockService.getBlockDetailByBlockID(blockId);
    }

    @RequestMapping(value = "/number", method = RequestMethod.POST)
    public List<BlockDetailResponse> getListBlockByBlockNum(@RequestBody ListBlocksByBlockNumberPagingRequest request) {
        return blockService.getListBlockByBlockNum(request);
    }

    @RequestMapping(value = "/latest/{limit}", method = RequestMethod.GET)
    public List<BlockDetailResponse> getListLatestBlock(@PathVariable(value = "limit") int limit) {
        return blockService.getListLatestBlock(limit);
    }

    @RequestMapping(value = "/paging", method = RequestMethod.POST)
    public List<BlockDetailResponse> getListBlockByPaging(@RequestBody ListBlockPagingRequest request) {
        return blockService.getListBlockByPaging(request);
    }
}
