package com.beowulf.explorer.crawler;

import com.beowulf.constants.ActionConstant;
import com.beowulf.constants.BeowulfConstant;
import com.beowulf.constants.Constant;
import com.beowulf.constants.TypeAuthConstant;
import com.beowulf.explorer.config.AppConfig;
import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.explorer.document.*;
import com.beowulf.explorer.document.operations.AccountCreateData;
import com.beowulf.explorer.document.operations.SmtCreateData;
import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulf.explorer.repository.*;
import com.beowulf.model.BeowulfData;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.LoggerUtil;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.base.models.Block;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.enums.OperationType;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.plugins.apis.condenser.models.ExtendedAccount;
import com.beowulfchain.beowulfj.protocol.AccountName;
import com.beowulfchain.beowulfj.protocol.operations.Operation;
import com.mongodb.MongoException;
import com.mongodb.MongoSocketOpenException;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
@Scope(value = "prototype")
public class CrawlHighestBlockData extends CrawlerThread {

    @Autowired
    private ActionRepository actionRepository;

    @Autowired
    private BeowulfBlockRepository beowulfBlockRepository;

    @Autowired
    private BeowulfTransactionRepository beowulfTransactionRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @Autowired
    private BeowulfAuthReferencesRepository beowulfAuthReferencesRepository;

    @Autowired
    private BeowulfTokenRepository beowulfTokenRepository;

    @Autowired
    private NodeCrawlingInfoRepository nodeCrawlingInfoRepository;

    @Autowired
    private CrawlSupernodeData crawlSupernodeData;

    private final Logger logger = LoggerFactory.getLogger(CrawlHighestBlockData.class);
    // Handle initial Beowulf node
    private BeowulfJ beowulfJ;
    private String nodeUrl;
    private String crawlerName;

    // Handle for crawling highest block
    private long currentBlock;
    private ObjectId currentAction;
    private long successfulCrawlBlock;

    // Handle field bc_id in document
    private long currentBlockTimestamp;
    private boolean isProcessing;

    public void init(String name, boolean onSegment) throws BeowulfCommunicationException, BeowulfResponseException {
        this.crawlerName = name;
        _init(onSegment);
    }

    private void _init(boolean onSegment) throws BeowulfCommunicationException, BeowulfResponseException {
        this.isProcessing = false;
        this.nodeUrl = BeowulfExplorerServiceConfig.getInstance().getBeowulf_node();
        this.beowulfJ = BeowulfCommunicate.init(nodeUrl);

        long startBlock = BeowulfExplorerServiceConfig.getInstance().getBeowulf_startblock();
        if (onSegment) {
            int lastSegment = nodeCrawlingInfoRepository.getLastSegment(nodeUrl);
            this.currentBlock = lastSegment * Constant.CRAWLER_JUMPSTEP;
        } else {
            this.currentBlock = nodeCrawlingInfoRepository.getLastCrawlingBlock(startBlock, this.nodeUrl);
        }

        if (this.currentBlock <= 1L) {
            this.currentBlock = 1;
            initAccountGenesis(BeowulfConstant.NULL_ACCOUNT_NAME);
            initAccountGenesis(BeowulfConstant.GENESIS_ACCOUNT_NAME);
        }
    }

    /**
     * Init genesis account: beowulf & null
     */
    private void initAccountGenesis(String accountName) {
        try {
            if (this.beowulfAccountRepository.findAccountByName(accountName) == null) {
                AccountName genesisAccountName = new AccountName(accountName);

                // Step 1: Get account information through Condenser API:
                List<ExtendedAccount> newAccount = this.beowulfJ.getAccounts(Collections.singletonList(genesisAccountName));

                boolean multisig = getAccountMultisig(new AuthorityData(newAccount.get(0).getOwner()));
                // Step 2: Create new Account document:
                BeowulfAccount genesisAccount = new BeowulfAccount(newAccount.get(0));
                genesisAccount.setCreated_block(0L);
                genesisAccount.setCreated_operation_id(BeowulfConstant.GENESIS_CREATE_OPERATION_ID);
                genesisAccount.setMultisig(multisig);

                // get account references
                getAccountReferences(genesisAccount.getPermissions(), genesisAccount.getName());
                //Step 3: Insert new Account document into DB:
                this.beowulfAccountRepository.save(genesisAccount);
            }
        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Genesis accounts] - Has been handle by another bot");
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Genesis accounts] - Can not get data of from Beowulf Network");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Genesis accounts] - Can not handle data of genesis accounts: ");
            e.printStackTrace();
        }
    }

    @Override
    public long onDestroy() {
        int i = 0;
        while (this.isProcessing) {
            System.out.println((i + 1) + "s");
            i++;
            doSleep(1000);
        }
        LoggerUtil.w(this.getName(), "Service shutdown completed!");
        return this.successfulCrawlBlock;
    }

    @Override
    public void run() {
        LoggerUtil.i(this.getName(), String.format("Start Beowulf Crawling %s with block %s", this.getCrawlerName(), this.currentBlock));
        long highestBlock = this.currentBlock;
        while (AppConfig.isAlive()) {
            try {
                highestBlock = this.beowulfJ.getDynamicGlobalProperties().getHeadBlockNumber();
            } catch (BeowulfCommunicationException e) {
                e.printStackTrace();
                this.logger.error("==> EXPLORER: " +
                        "[Crawler] - Can not connect with beowulf node");
            } catch (BeowulfResponseException e) {
                e.printStackTrace();
                this.logger.error("==> EXPLORER: " +
                        "[Crawler] - Beowulf node response exception");
            }
            while (this.currentBlock <= highestBlock && AppConfig.isAlive()) {
                this.isProcessing = true;
                try {
                    // Handle block
                    Block block = this.beowulfJ.getBlock(this.currentBlock);
                    handleBlock(this.currentBlock, block);
                    // Update crawl block
                    this.successfulCrawlBlock = this.currentBlock;
                    updateLastCrawl(this.successfulCrawlBlock);
                    AppConfig.putCrawler(this.crawlerName, this.successfulCrawlBlock);
                    this.currentBlock++;

                } catch (BeowulfCommunicationException | BeowulfResponseException | IndexOutOfBoundsException e) {
                    this.logger.error("==> EXPLORER: " +
                            "[Crawling Block] - Can not get data of Block {} from Beowulf Network with Error {}", this.currentBlock, e.getMessage());
                } catch (Exception e) {
                    this.logger.error("==> EXPLORER: " +
                            "[Crawling Block] - Can not handle data of Block {} with Error: ", this.currentBlock);
                    e.printStackTrace();
                } finally {
                    this.isProcessing = false;
                }
            }
            if (!AppConfig.isAlive()) break;
            doSleep();
        }
        LoggerUtil.w(this.getName(), String.format("[Crawler] on destroy method completed with block: %s", this.successfulCrawlBlock));
    }

    /**
     * Handling new data of Block for Explorer Service documents
     * and putting into DB if it is satisfied
     *
     * @param blockNumber The Block number of Block
     * @param block       The Block object of Beowulf Block-chain
     */
    private void handleBlock(long blockNumber, Block block) {
        try {
            long start = System.currentTimeMillis();
            // Step 1: Create new Action for handle new block document into DB:
            String blockId = block.getBlockId().toString();
            this.currentBlockTimestamp = block.getTimestamp().getDateTimeAsTimestamp();

            Action handleBlockAction = new Action(
                    String.valueOf(blockNumber),
                    ActionConstant.HIGHEST_HANDLE_ACTION,
                    ActionConstant.TTL_ACTION
            );
            handleBlockAction = this.actionRepository.save(handleBlockAction);
            // Get current action => remove action when handle failed
            this.currentAction = handleBlockAction.getId();

            long totalBlockFee = 0L;
            int totalOperations = 0;

            // Step 2: Get list transactions in Block Object:
            List<CompletedTransaction> transactions = block.getTransactions();
            for (CompletedTransaction transaction : transactions) {

                long totalTransactionFee = 0L;
                int txIndex = transaction.getTransactionNum();
                String transactionId = transaction.getTransactionId().toString();

                // Get list of Operation.
                List<Operation> operations = transaction.getOperations();
                totalOperations += operations.size();

                for (int opIndex = 0; opIndex < operations.size(); opIndex++) {
                    // Step 3: Parse data of Operation and insert into OperationRepository in sequence:
                    getBeowulfOperationData(opIndex, transactionId, operations.get(opIndex), txIndex);
                    // Calculate Total fee of transaction:
                    totalTransactionFee += BeowulfCommunicate.getFeeOfOperation(operations.get(opIndex));
                }
                // Step 4: Parse data of Transaction and insert into TransactionRepository in sequence:
                getTransactionData(transaction, blockId, totalTransactionFee, txIndex);
                // Total operation of Block:
                totalBlockFee += totalTransactionFee;
            }

            // Step 5: Parse data of block and insert into BlockRepository:
            boolean isSuccessfulProcess = getBlockData(blockNumber, block, totalBlockFee);

            // Step 6: Parse data belongs to Super-node Account from Block and update data in AccountRepository:
            if (isSuccessfulProcess) {
                BeowulfSupernode dataSupernode = new BeowulfSupernode(
                        block.getSupernode().getName(),
                        block.getBlockId().toString(),
                        blockNumber,
                        totalOperations,
                        block.getBlockReward().getAmount(),
                        totalBlockFee);
                // Update data of Account Supernode in AccountRepository:
                updateAccountSupernode(dataSupernode);
                new Thread(() -> this.crawlSupernodeData.updateDataSupernodeInCache(dataSupernode.getSupernode_account())).start();
            }
            long end = System.currentTimeMillis();
            this.logger.info((String.format("[Crawler] - End scan block: %s == time execute: %sms",
                    this.currentBlock, end - start)));
        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Block] - Has been handle by another bot");
        }
    }

    /**
     * Updating last crawling block number of Block-chain when shutdown or
     * maintenance services.
     *
     * @param blockNumber last block number crawling
     */
    private void updateLastCrawl(long blockNumber) {
        try {
            this.nodeCrawlingInfoRepository.updateLastCrawl(this.nodeUrl, blockNumber);
        } catch (MongoSocketOpenException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawler] - Can not open connection to mongodb to update last sync");
        }
    }

    /**
     * Getting new data of Block and putting into DB if it is satisfied
     *
     * @param blockNumber   The block number of block.
     * @param block         The Block object of Beowulf Block-chain.
     * @param totalBlockFee The total fee of transactions in block.
     * @return Successful Handle get data of Block or not?
     */
    private boolean getBlockData(long blockNumber, Block block, long totalBlockFee) {
        try {
            //Step 1: Create new Block document:
            BeowulfBlock beowulfBlock = new BeowulfBlock(block);
            beowulfBlock.setBlock_number(blockNumber);
            beowulfBlock.setTotal_fee(totalBlockFee);

            BeowulfData bcData = new BeowulfData(blockNumber, 0, 0, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfBlock.setBc_id(bcId);

            //Step 2: Insert new block document into DB:
            this.beowulfBlockRepository.save(beowulfBlock);
            return true;

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Block] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Block] - Cannot get and insert data of Block: {}", blockNumber);
            e.printStackTrace();
            this.actionRepository.removeAction(this.currentAction);
        }
        return false;
    }

    /**
     * Getting new data of Transaction and putting into DB if it is satisfied
     *
     * @param transaction         The CompletedTransaction object of Beowulf Block-chain.
     * @param blockId             The Block Id of Block contains transaction.
     * @param totalTransactionFee The Total transaction fee.
     * @param txIndex             The Transaction number for generation bc_id
     */
    private void getTransactionData(CompletedTransaction transaction, String blockId, long totalTransactionFee, int txIndex) {
        try {
            //Step 1: Create new Transaction document:
            BeowulfTransaction beowulfTransaction = new BeowulfTransaction(transaction, blockId, totalTransactionFee);

            BeowulfData bcData = new BeowulfData(this.currentBlock, txIndex, 0, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfTransaction.setBc_id(bcId);

            //Step 2: Insert new transaction document into DB:
            this.beowulfTransactionRepository.save(beowulfTransaction);

        } catch (DuplicateKeyException e) {
            logger.debug("==> EXPLORER: " +
                    "[Crawling Transaction] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Transaction] - Cannot get and insert data of Transaction with Tx_id: {}", transaction.getTransactionId().toString());
            e.printStackTrace();
        }
    }

    private void getAccountReferences(AuthorityData authorityData, String name) {
        Map<String, Integer> mapAccount = authorityData.getAccountAuths();
        for (Map.Entry<String, Integer> entry : mapAccount.entrySet()) {
            beowulfAuthReferencesRepository.save(new BeowulfAuthReferences(entry.getKey(), entry.getValue(), name, TypeAuthConstant.ACCOUNT));
        }
        Map<String, Integer> mapKey = authorityData.getKeyAuths();
        for (Map.Entry<String, Integer> entry : mapKey.entrySet()) {
            beowulfAuthReferencesRepository.save(new BeowulfAuthReferences(entry.getKey(), entry.getValue(), name, TypeAuthConstant.KEY));
        }
    }

    private boolean getAccountMultisig(AuthorityData authorityData) {
        Map<String, Integer> mapAccountS = authorityData.getAccountAuths();
        Map<String, Integer> mapKeyS = authorityData.getKeyAuths();
        return (mapAccountS.size() + mapKeyS.size()) > 1;
    }

    /**
     * Getting new data of Account and putting into DB if it is satisfied
     *
     * @param accountCreateOperation The AccountCreateOperation object of Beowulf Block-chain.
     * @param blockNumber            The block number of Block has this create account operation.
     * @param createdTime            The time created transaction contains this account create operation.
     */
    private void getBeowulfAccountData(BeowulfOperation accountCreateOperation, long blockNumber, long createdTime) {

        String accountName = accountCreateOperation.getRelate_account_2();
        try {
            // Step 1: Create new Account document:
            boolean multisig = getAccountMultisig(((AccountCreateData) accountCreateOperation.getOperation()).getOwner());
            BeowulfAccount beowulfAccount = new BeowulfAccount((AccountCreateData) accountCreateOperation.getOperation());
            beowulfAccount.setCreated_operation_id(accountCreateOperation.getOperation_id());
            beowulfAccount.setCreated_block(blockNumber);
            beowulfAccount.setCreated_at(createdTime);
            beowulfAccount.setMultisig(multisig);

            //Step 2: Insert new Account document into DB:
            this.beowulfAccountRepository.save(beowulfAccount);

            // Add accounts references
            getAccountReferences(((AccountCreateData) accountCreateOperation.getOperation()).getOwner(), accountName);

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Account] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account] - Cannot get and insert data of Account: {}", accountName);
            e.printStackTrace();
        }
    }

    /**
     * Getting new data of Token and putting into DB if it is satisfied
     *
     * @param smtCreateOperation The SmtCreateOperation object of Beowulf Block-chain.
     * @param blockNumber        The block number of Block has this create account operation.
     * @param createdTime        The time created transaction contains this account create operation.
     * @param operationId        The operation id of operation create smt token.
     */
    private void getBeowulfTokenData(BeowulfOperation smtCreateOperation, long blockNumber, long createdTime, String operationId) {
        SmtCreateData smtCreateData = (SmtCreateData) smtCreateOperation.getOperation();
        String tokenName = smtCreateData.getSymbol().getName();
        try {
            // Step 1: Create new Token document:
            BeowulfToken beowulfToken = new BeowulfToken(smtCreateData);
            beowulfToken.setCreated_block(blockNumber);
            beowulfToken.setCreated_at(createdTime);
            beowulfToken.setOperation_id(operationId);
            //Step 2: Insert new Token document into DB:
            this.beowulfTokenRepository.save(beowulfToken);

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Token] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - Cannot get and insert data of Token: {}", tokenName);
            e.printStackTrace();
        }
    }

    /**
     * Getting new data of Operation and putting into DB if it is satisfied
     *
     * @param opIndex       The Order of Operation in List Operation of Transaction.
     * @param transactionId The transaction id of Transaction.
     * @param operation     The Operation object in Beowulf Block-chain.
     * @param txIndex       The Transaction num for generation bc_id
     */
    private void getBeowulfOperationData(int opIndex, String transactionId, Operation operation, int txIndex) {
        BeowulfOperation beowulfOperation = null;
        try {
            //Step 1: Create new Operation Document:
            beowulfOperation = BeowulfOperation.parseOperation(operation, transactionId, opIndex);

            BeowulfData bcData = new BeowulfData(this.currentBlock, txIndex, opIndex, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfOperation.setBc_id(bcId);

            //Step 2: Insert new Operation document into DB:
            beowulfOperation = beowulfOperationRepository.save(beowulfOperation);

        } catch (DuplicateKeyException e) {
            logger.debug("==> EXPLORER: " +
                    "[Crawling Operation] - Has been gotten by another bot");
        } catch (IllegalArgumentException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Operation] - Not supported on this Operation");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Operation] - Cannot get and insert data of Operation with tx_id: {} - index: {}", transactionId, opIndex);
            e.printStackTrace();
        }

        if (beowulfOperation != null) {
            // Step 3: Check operation if it is the AccountCreate Operation:
            if (beowulfOperation.getType() == OperationType.ACCOUNT_CREATE_OPERATION) {
                // ==> Parse data of Operation for Account data and insert into AccountRepository.
                getBeowulfAccountData(beowulfOperation, this.currentBlock, this.currentBlockTimestamp);
            } else if (beowulfOperation.getType() == OperationType.SMT_CREATE_OPERATION) {
                // ==> Parse data of Operation for Token data and insert into TokenRepository.
                getBeowulfTokenData(beowulfOperation, this.currentBlock, this.currentBlockTimestamp, beowulfOperation.getOperation_id());
            }
        }
    }

    /**
     * Getting new data for Account is Super-node Type and updating into DB if it is satisfied
     *
     * @param dataSupernode The Data Supernode Document object of block in Beowulf Block-chain.
     */
    private void updateAccountSupernode(BeowulfSupernode dataSupernode) {
        String supernodeName = dataSupernode.getSupernode_account();
        try {
            BeowulfAccount existedAccount = this.beowulfAccountRepository.findAccountByName(supernodeName);
            if (existedAccount == null) {
                throw new Exception(String.format("updateAccountSupernode fail because account %s does not exist", supernodeName));
            }
            this.beowulfAccountRepository.increaseDataOfSupernode(
                    supernodeName,
                    dataSupernode.getTotal_rewards(),
                    dataSupernode.getTotal_fee(),
                    dataSupernode.getTotal_operations()
            );
        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Super-node] - Has been handle by another bot");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Cannot update Data of Account");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Cannot get and update data of Account super-node with block: {}", dataSupernode.getMined_block_number());
            e.printStackTrace();
        }
    }

    /**
     * Putting thread sleep.
     */
    private static void doSleep() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void doSleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getCrawlerName() {
        return crawlerName;
    }

    public void setCrawlerName(String crawlerName) {
        this.crawlerName = crawlerName;
    }

    public void setCurrentBlock(long currentBlock) {
        this.currentBlock = currentBlock;
    }
}
