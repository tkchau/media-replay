package com.beowulf.explorer.services.impl;

import com.beowulf.constants.BeowulfConstant;
import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.BeowulfAuthReferences;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.repository.BeowulfAccountRepository;
import com.beowulf.explorer.repository.BeowulfAuthReferencesRepository;
import com.beowulf.explorer.repository.BeowulfOperationRepository;
import com.beowulf.explorer.services.AccountDetailService;
import com.beowulf.model.request.ListBeowulfAccountPagingRequest;
import com.beowulf.model.request.ListCreatedAccountPagingRequest;
import com.beowulf.model.response.AccountDetailResponse;
import com.beowulf.model.response.BeowulfAccountResponse;
import com.beowulf.model.response.CreatedAccountResponse;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulfchain.beowulfj.plugins.apis.condenser.models.ExtendedAccount;
import com.beowulfchain.beowulfj.protocol.AccountName;
import com.beowulfchain.beowulfj.protocol.PublicKey;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountDetailServiceImpl implements AccountDetailService {

    private final Logger logger = LoggerFactory.getLogger(AccountDetailService.class);

    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private BeowulfAuthReferencesRepository beowulfAuthReferencesRepository;

    @Override
    public AccountDetailResponse getAccountDetailByName(String accountName) throws Exception {
        logger.info("==> EXPLORER: " +
                "Get account detail for account name: {}", accountName);
        AccountName name = new AccountName(accountName);
        BeowulfAccount beowulfAccount = beowulfAccountRepository.findAccountByName(accountName);
        if (beowulfAccount == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        List<ExtendedAccount> accountDetail = null;
        accountDetail = BeowulfCommunicate.getBeowulfJ().getAccounts(Collections.singletonList(name));

        if (accountDetail == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        AccountDetailResponse accountDetailResponse = new AccountDetailResponse(beowulfAccount, accountDetail.get(0));
        if (beowulfAccount.getCreated_operation_id().equals(BeowulfConstant.GENESIS_CREATE_OPERATION_ID)) {
            accountDetailResponse.setTransaction_id(null);
            return accountDetailResponse;
        }
        BeowulfOperation createdOperation = beowulfOperationRepository.findBeowulfOperationByOperation_id(beowulfAccount.getCreated_operation_id());
        if (createdOperation == null) {
            throw ServiceExceptionUtils.operationNotFound(beowulfAccount.getCreated_operation_id());
        } else {
            accountDetailResponse.setTransaction_id(createdOperation.getTransaction_id());
        }
        return accountDetailResponse;
    }

    @Override
    public long getTotalAccountInData() throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get total account in database");
        return beowulfAccountRepository.count();
    }

    @Override
    public List<CreatedAccountResponse> listCreatedAccount(ListCreatedAccountPagingRequest listCreatedAccountPagingRequest) throws ServiceException {
        BeowulfAccount account = beowulfAccountRepository.findAccountByName(listCreatedAccountPagingRequest.getCreator());
        if (account == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }

        int limit = Common.makeStableLimitation(listCreatedAccountPagingRequest.getLimit());
        String direction = Common.handleDirectionRequest(listCreatedAccountPagingRequest.getDirection());
        ObjectId startId = Common.makeStableObjectIdRequest(listCreatedAccountPagingRequest.getStart_id());
        String creator = listCreatedAccountPagingRequest.getCreator();
        logger.info("==> EXPLORER: " +
                "Get all created account in database by creator: " + listCreatedAccountPagingRequest.getCreator());
        List<BeowulfAccount> beowulfAccounts = beowulfAccountRepository.findCreatedAccount(startId, limit, creator, direction);
        List<CreatedAccountResponse> accounts = new ArrayList<>();
        for (BeowulfAccount beowulfAccount : beowulfAccounts) {
            accounts.add(new CreatedAccountResponse(beowulfAccount));
        }
        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (startId != null)) {
            Collections.reverse(accounts);
        }
        return accounts;
    }

    @Override
    public List<BeowulfAccountResponse> listAccountByPaging(ListBeowulfAccountPagingRequest request) throws ServiceException {
        this.logger.info("Get list Account detail");
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        List<BeowulfAccount> beowulfAccounts = beowulfAccountRepository.getBeowulfAccountByPaging(startId, limit, direction);

        List<BeowulfAccountResponse> beowulfAccountResponses = new ArrayList<>();
        for (BeowulfAccount beowulfAccount : beowulfAccounts) {
            beowulfAccountResponses.add(new BeowulfAccountResponse(beowulfAccount));
        }
        if (startId != null && direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(beowulfAccountResponses);
        }
        return beowulfAccountResponses;
    }

    @Override
    public List<String> listAccountReferences(String accountName) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get accounts references for account name: {}", accountName);
        AccountName name = new AccountName(accountName);
        BeowulfAccount beowulfAccount = beowulfAccountRepository.findAccountByName(accountName);
        if (beowulfAccount == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        List<String> names = new ArrayList<>();
        List<BeowulfAuthReferences> lists = beowulfAuthReferencesRepository.findBeowulfAccountReferencesByName(accountName);
        for (BeowulfAuthReferences list : lists) {
            names.add(list.getName_references());
        }
        return names.stream().sorted().collect(Collectors.toList());
    }

    @Override
    public List<String> listKeyReferences(String key) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get accounts references for key: {}", key);
        if (key.length() != 53) {
            throw ServiceExceptionUtils.invalidRequestParam("invalid key " + key);
        }
        PublicKey publicKey = new PublicKey(key);
        List<BeowulfAuthReferences> lists = beowulfAuthReferencesRepository.findBeowulfAccountReferencesByName(key);
        List<String> names = new ArrayList<>();
        for (BeowulfAuthReferences list : lists) {
            names.add(list.getName_references());
        }
        return names.stream().sorted().collect(Collectors.toList());
    }

    @Override
    public boolean checkAccountMultisig(String accountName) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Check account multisig for account name: {}", accountName);
        AccountName name = new AccountName(accountName);
        BeowulfAccount beowulfAccount = beowulfAccountRepository.findAccountByName(accountName);
        if (beowulfAccount == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        return beowulfAccount.isMultisig();
    }

    @Override
    public List<BeowulfAccountResponse> getAccountsMultisig(ListBeowulfAccountPagingRequest request) throws ServiceException {
        this.logger.info("Get list account multisig");
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        List<BeowulfAccount> beowulfAccounts = beowulfAccountRepository.getAccountMultisigByPaging(startId, limit, direction, request.getMultisig());
        List<BeowulfAccountResponse> beowulfAccountResponses = new ArrayList<>();
        for (BeowulfAccount beowulfAccount : beowulfAccounts) {
            beowulfAccountResponses.add(new BeowulfAccountResponse(beowulfAccount));
        }
        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (startId != null)) {
            Collections.reverse(beowulfAccountResponses);
        }
        return beowulfAccountResponses;
    }
}

