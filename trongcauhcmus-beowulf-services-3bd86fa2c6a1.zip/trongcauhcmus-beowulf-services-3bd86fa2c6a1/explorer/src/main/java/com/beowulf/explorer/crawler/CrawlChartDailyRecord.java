package com.beowulf.explorer.crawler;

import com.beowulf.constants.BeowulfConstant;
import com.beowulf.explorer.config.AppConfig;
import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.repository.BeowulfBlockRepository;
import com.beowulf.explorer.repository.BeowulfOperationRepository;
import com.beowulf.explorer.repository.ChartCrawlingConfigRepository;
import com.beowulf.model.aggregate.AggregateAccountItem;
import com.beowulf.model.aggregate.AggregateAmountTransferItem;
import com.beowulf.model.aggregate.AggregateBlockAndTxItem;
import com.beowulf.model.chart.record.ChartDailyRecord;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.CSVUtil;
import com.beowulf.utilities.DateTimeUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

import static org.apache.commons.lang3.time.DateUtils.MILLIS_PER_MINUTE;

@Service(value = "crawlChartDailyRecord")
public class CrawlChartDailyRecord extends CrawlerThread {

    @Autowired
    private BeowulfBlockRepository beowulfBlockRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private ChartCrawlingConfigRepository chartCrawlingConfigRepository;

    private Logger logger = LoggerFactory.getLogger(CrawlChartDailyRecord.class);

    private String csvFilepath;

    private static final String[] HEADERS = {"Year", "Month", "Day", "UnixTimeStamp", "BlockGrowth", "TxGrowth", "AccountGrowth", "BWFTransfer", "WTransfer"};

    private String nodeUrl;

    private Date syncingTimestamp;

    private Date SOD;

    private Date EOD;

    private Date timeCursor;

    private ChartDailyRecord dailyRecord;

    private long successfulCrawlDate;

    private ChartDailyRecord successfulCrawlRecord;

    private boolean isProcessingChartCrawler = false;

    public void onStartup() throws BeowulfCommunicationException, BeowulfResponseException {
        // Get config
        nodeUrl = BeowulfExplorerServiceConfig.getInstance().getBeowulf_node();
        long startDate = DateTimeUtils.atStartOfDay(BeowulfCommunicate.init(nodeUrl).getBlock(1).getTimestamp().getDateTimeAsTimestamp()).getTime();
        csvFilepath = BeowulfExplorerServiceConfig.getInstance().getBeowulf_csv_filepath();
        Date lastCrawlDate = new Date(chartCrawlingConfigRepository.getLastCrawlDate(startDate, nodeUrl));
        successfulCrawlDate = lastCrawlDate.getTime();
        dailyRecord = successfulCrawlRecord = chartCrawlingConfigRepository.getLastCrawlChartRecord(startDate, nodeUrl);

        // Initial
        SOD = DateTimeUtils.atStartOfDay(lastCrawlDate);
        EOD = DateTimeUtils.atEndOfDay(lastCrawlDate);
        timeCursor = new Date(dailyRecord.getTime_cursor());

        // Create new file if not exist
        CSVUtil.generateCSVFile(csvFilepath, HEADERS);
    }

    @Override
    public long onDestroy() {
        int i = 0;
        while (this.isProcessingChartCrawler) {
            System.out.println((i + 1) + "s");
            i++;
            doSleep(1000);
        }
        LoggerUtil.w("Chart", "Service shutdown completed!");
        return 0;
    }

    /**
     * Handle data and append into CSV File for charts
     */
    @Scheduled(initialDelay = 5000, fixedDelay = 10 * MILLIS_PER_MINUTE)
    private void handleChartData() {

        if (!AppConfig.isAlive()) return;

        try {
            logger.info("==> EXPLORER: [Crawling Chart] - Handle chart data");
            isProcessingChartCrawler = true;
            // Get current syncing Blockchain:
            List<BeowulfBlock> latestBlocks = beowulfBlockRepository.getLastNBlocks(1);
            if (latestBlocks.iterator().hasNext()) {
                syncingTimestamp = new Date(latestBlocks.iterator().next().getTimestamp());
            }

            // If SOD is before Current date => handle data:
            while (EOD.before(syncingTimestamp)) {

                // Handle data within the day (24h):
                while (timeCursor.before(EOD)) {
                    try {
                        // Create range of cursor:
                        ObjectId startId = new ObjectId(timeCursor);
                        Date nextTimeCursor = DateTimeUtils.plusMinutesWithinADay(EOD, timeCursor, 30);
                        ObjectId endId = new ObjectId(nextTimeCursor);

                        // Aggregate chart items in range (startId & endId):
                        AggregateBlockAndTxItem blockAndTxItem = beowulfBlockRepository.getTotalIncBlockAndTxDaily(startId, endId);
                        AggregateAccountItem accountItem = beowulfOperationRepository.getTotalIncAccountDaily(startId, endId);
                        List<AggregateAmountTransferItem> transferItems = beowulfOperationRepository.getTotalAmountTransferDaily(startId, endId);

                        // Increase time cursor:
                        timeCursor = nextTimeCursor;

                        // Update record and DB config:
                        updateDailyRecord(blockAndTxItem, accountItem, transferItems, timeCursor.getTime());

                    } catch (Exception e) {
                        logger.error("==> EXPLORER: " +
                                "[Crawling Chart] - Cannot get and update daily record at {}", timeCursor);
                        e.printStackTrace();
                    }
                }
                // Update Main CSV File at the end of day:
                if (!dailyRecord.isWritten()) {

                    boolean successfulUpdate = CSVUtil.appendCSV(csvFilepath, dailyRecord, true);

                    if (successfulUpdate) {
                        // Update crawling config
                        dailyRecord.setWritten(true);
                        chartCrawlingConfigRepository.updateLastCrawlChartRecord(nodeUrl, dailyRecord);
                        chartCrawlingConfigRepository.updateLastCrawlDate(nodeUrl, EOD.getTime());
                        successfulCrawlDate = EOD.getTime();
                        logger.info("==> EXPLORER: " +
                                "[Crawling Chart] - Update SUCCESSFULLY daily record {}", EOD.toString());
                    }
                }
                // Increase SOD & EOD, create new record for next day:
                SOD = DateTimeUtils.plusOneDay(SOD);
                EOD = DateTimeUtils.plusOneDay(EOD);
                dailyRecord = new ChartDailyRecord(SOD);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            isProcessingChartCrawler = false;
        }
    }

    /**
     * Update daily record.
     *
     * @param blockAndTxItem Block & tx growth item in Chart daily record
     * @param accountItem    Account growth item in Chart daily record
     * @param transferItems  Transfer amount items in Chart daily record
     * @param timeCursor     Time cursor in day
     */
    private void updateDailyRecord(AggregateBlockAndTxItem blockAndTxItem, AggregateAccountItem accountItem, List<AggregateAmountTransferItem> transferItems, long timeCursor) {
        // Update items for daily record & current time cursor:
        dailyRecord.setDaily_inc_block(dailyRecord.getDaily_inc_block() + blockAndTxItem.getDaily_inc_block());
        dailyRecord.setDaily_inc_tx(dailyRecord.getDaily_inc_tx() + blockAndTxItem.getDaily_inc_tx());
        dailyRecord.setDaily_inc_account(dailyRecord.getDaily_inc_account() + accountItem.getDaily_inc_account());
        transferItems
                .forEach(item -> {
                    if (BeowulfConstant.W_ASSET_SYMBOL.equals(item.get_id())) {
                        dailyRecord.setDaily_transfer_w(item.getDaily_transfer_amount());
                    } else if (BeowulfConstant.BWF_ASSET_SYMBOL.equals(item.get_id())) {
                        dailyRecord.setDaily_transfer_bwf(item.getDaily_transfer_amount());
                    }
                });
        dailyRecord.setTime_cursor(timeCursor);

        // Update Config repository:
        chartCrawlingConfigRepository.updateLastCrawlChartRecord(nodeUrl, dailyRecord);
        successfulCrawlRecord = dailyRecord;
    }

    public ChartDailyRecord getSuccessfulCrawlRecord() {
        return successfulCrawlRecord;
    }

    public long getSuccessfulCrawlDate() {
        return successfulCrawlDate;
    }

    private static void doSleep() {
        doSleep(60000);
    }

    private static void doSleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
