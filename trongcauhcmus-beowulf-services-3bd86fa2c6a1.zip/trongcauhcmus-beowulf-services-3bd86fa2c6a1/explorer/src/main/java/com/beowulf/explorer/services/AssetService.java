package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.request.ListBeowulfOperationByAssetPagingRequest;
import com.beowulf.model.request.ListTokenPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import com.beowulf.model.response.TokenDetailResponse;
import com.beowulf.model.response.TokenHolderDetailResponse;

import java.util.List;

public interface AssetService {

	List<OperationDetailResponse> getListTransferOperationByCurrencyCode(ListBeowulfOperationByAssetPagingRequest request) throws ServiceException;

    List<TokenDetailResponse> getListTokenByPaging(ListTokenPagingRequest request) throws ServiceException;

    long getTotalTokenHolders(String token) throws ServiceException;

    TokenHolderDetailResponse getAccountControl(String token) throws ServiceException;

    List<TokenHolderDetailResponse> getTopTokenHolders(String token, int limit) throws ServiceException;

    TokenDetailResponse getTokenDetail(String token) throws ServiceException;

    int getTotalToken() throws ServiceException;
}
