package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.request.ListBeowulfAccountPagingRequest;
import com.beowulf.model.request.ListCreatedAccountPagingRequest;
import com.beowulf.model.response.AccountDetailResponse;
import com.beowulf.model.response.BeowulfAccountResponse;
import com.beowulf.model.response.CreatedAccountResponse;

import java.util.List;

public interface AccountDetailService {

    AccountDetailResponse getAccountDetailByName(String accountName) throws Exception;

    long getTotalAccountInData() throws ServiceException;

    List<CreatedAccountResponse> listCreatedAccount(ListCreatedAccountPagingRequest listCreatedAccountPagingRequest) throws ServiceException;

    List<String> listAccountReferences(String accountName) throws ServiceException;

    List<String> listKeyReferences(String key) throws ServiceException;

    List<BeowulfAccountResponse> listAccountByPaging(ListBeowulfAccountPagingRequest request) throws ServiceException;

    boolean checkAccountMultisig(String accountName) throws ServiceException;

    List<BeowulfAccountResponse> getAccountsMultisig(ListBeowulfAccountPagingRequest request) throws ServiceException;
}
