package com.beowulf.explorer.services.impl;

import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.repository.BeowulfAccountRepository;
import com.beowulf.explorer.repository.BeowulfOperationRepository;
import com.beowulf.explorer.services.OperationService;
import com.beowulf.model.request.ListBeowulfOperationPagingRequest;
import com.beowulf.model.request.ListOperationByAccountPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulf.utilities.StringUtils;
import com.beowulfchain.beowulfj.protocol.AccountName;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class OperationServiceImpl implements OperationService {

    private Logger logger = LoggerFactory.getLogger(OperationService.class);

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;
    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @Override
    public long totalOperations() throws ServiceException {
        logger.info("EXPLORER: Request total operations");
        return beowulfOperationRepository.count();
    }

    @Override
    public long totalOperationOfAccount(String accountName) throws ServiceException {
        AccountName var1 = new AccountName(accountName);
        BeowulfAccount beowulfAccount = beowulfAccountRepository.findAccountByName(accountName);
        if (beowulfAccount == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        logger.info("EXPLORER: Request total operations belong to " + accountName);
        return beowulfOperationRepository.countOperationByAccount(accountName);
    }

    @Override
    public List<OperationDetailResponse> getListOperation(ListBeowulfOperationPagingRequest request) throws ServiceException {
        logger.info("EXPLORER: Request lasted operation");
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        String type = StringUtils.isNotEmpty(request.getType()) ? request.getType() : null;

        List<OperationDetailResponse> operationDetail = new ArrayList<>();
        List<BeowulfOperation> beowulfOperations = beowulfOperationRepository.getListOperation(startId, limit, direction, type);
        for (BeowulfOperation beowulfOperation : beowulfOperations) {
            OperationDetailResponse operationDetailResponse = new OperationDetailResponse(beowulfOperation);
            operationDetail.add(operationDetailResponse);
        }
        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (startId != null)) {
            Collections.reverse(operationDetail);
        }
        return operationDetail;
    }

    @Override
    public List<OperationDetailResponse> getOperationByAccount(ListOperationByAccountPagingRequest request) throws ServiceException {
        AccountName var = new AccountName(request.getAccount());
        BeowulfAccount beowulfAccount = beowulfAccountRepository.findAccountByName(request.getAccount());
        if (beowulfAccount == null) {
            throw ServiceExceptionUtils.accountNotExisted();
        }
        logger.info("EXPLORER: Get operations belong to account " + request.getAccount());

        int limit = Common.makeStableLimitation(request.getLimit());
        String account = request.getAccount();
        String direction = Common.handleDirectionRequest(request.getDirection());
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        String type = StringUtils.isNotEmpty(request.getType()) ? request.getType() : null;
        List<BeowulfOperation> relate_account = beowulfOperationRepository.findBeowulfOperationByRelateAccount(startId, account, direction, limit, type);

        List<OperationDetailResponse> operationDetailResponses = new ArrayList<>();
        List<BeowulfOperation> beowulfOperations = new ArrayList<>(relate_account);
        for (BeowulfOperation beowulfOperation : beowulfOperations) {
            operationDetailResponses.add(new OperationDetailResponse(beowulfOperation));
        }
        if ((startId != null) && direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(operationDetailResponses);
        }
        return operationDetailResponses;
    }

    @Override
    public List<OperationDetailResponse> getOperationByTransactionId(String transaction_id) throws ServiceException {
        List<BeowulfOperation> beowulfOperations = beowulfOperationRepository.findBeowulfOperationByTransactionId(transaction_id);
        if (beowulfOperations == null || beowulfOperations.isEmpty()) {
            throw ServiceExceptionUtils.transactionNotFound(transaction_id);
        }
        logger.info("EXPLORER: Get oprerations by transaction_id");
        List<OperationDetailResponse> operationDetailResponses = new ArrayList<>();
        List<BeowulfOperation> listBeowulfOperations = new ArrayList<>(beowulfOperations);
        for (BeowulfOperation listBeowulfOperation : listBeowulfOperations) {
            operationDetailResponses.add(new OperationDetailResponse(listBeowulfOperation));
        }
        return operationDetailResponses;
    }

    @Override
    public OperationDetailResponse getOperationByOperationId(String operation_id) throws ServiceException {
        BeowulfOperation beowulfOperation = beowulfOperationRepository.findBeowulfOperationByOperation_id(operation_id);
        if (beowulfOperation == null) {
            throw ServiceExceptionUtils.operationNotFound(operation_id);
        }
        logger.info("EXPLORER: Get opreration by operation_id");
        return new OperationDetailResponse(beowulfOperation);
    }
}
