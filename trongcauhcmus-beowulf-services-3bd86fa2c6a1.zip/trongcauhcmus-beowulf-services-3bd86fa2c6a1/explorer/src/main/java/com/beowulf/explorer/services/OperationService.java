package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.request.ListBeowulfOperationPagingRequest;
import com.beowulf.model.request.ListOperationByAccountPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;

import java.util.List;

public interface OperationService {

    long totalOperations() throws ServiceException;

    List<OperationDetailResponse> getListOperation(ListBeowulfOperationPagingRequest request) throws ServiceException;

    List<OperationDetailResponse> getOperationByAccount(ListOperationByAccountPagingRequest request) throws ServiceException;

    List<OperationDetailResponse> getOperationByTransactionId(String transaction_id) throws ServiceException;

    long totalOperationOfAccount(String accountName) throws ServiceException;

    OperationDetailResponse getOperationByOperationId(String operation_id) throws ServiceException;
}
