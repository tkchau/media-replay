package com.beowulf.explorer.config;

import com.beowulf.constants.Constant;
import com.beowulf.explorer.crawler.*;
import com.beowulf.explorer.repository.ChartCrawlingConfigRepository;
import com.beowulf.explorer.repository.NodeCrawlingInfoRepository;
import com.beowulf.model.chart.record.ChartDailyRecord;
import com.beowulf.utilities.LoggerUtil;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.time.DateUtils.MILLIS_PER_MINUTE;

@Configuration
@EnableScheduling
public class AppConfig {
    private static final String tag = "APP";

    private static boolean alive;

    private static boolean onSegment;

    private final ApplicationContext applicationContext;

    private List<CrawlerThread> crawlers = new ArrayList<>();

    private List<CrawlerThread> irrCrawlers = new ArrayList<>();

    private static Map<String, Long> crawlerStatus = new HashMap<>();

    private static Map<String, Long> irrCrawlerStatus = new HashMap<>();

    @Autowired
    NodeCrawlingInfoRepository nodeCrawlingInfoRepository;

    @Autowired
    ChartCrawlingConfigRepository chartCrawlingConfigRepository;

    private CrawlAccountData crawlAccountData;

    private CrawlChartDailyRecord crawlChartDailyRecord;

    @Autowired
    public AppConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    public static boolean isAlive() {
        return alive;
    }

    @PostConstruct
    public void onConstruct() {
        alive = true;
        LoggerUtil.w(tag, "Start checking last run...");
        if (nodeCrawlingInfoRepository.isTurnedOff(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node())) {
            onSegment = false;
            nodeCrawlingInfoRepository.turnOn(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node());
            LoggerUtil.w(tag, "Checking service completed, nothing weird!");
        } else {
            onSegment = true;
            LoggerUtil.w(tag, "Service was not shutdown by the right way.");
            LoggerUtil.w(tag, "Start running on segment...");
        }

        try {
            crawlAccountData = applicationContext.getBean(CrawlAccountData.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            crawlChartDailyRecord = applicationContext.getBean(CrawlChartDailyRecord.class);
            crawlChartDailyRecord.onStartup();
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            e.printStackTrace();
        }

    }

    @PreDestroy
    public void onDestroy() {
        LoggerUtil.w(tag, "ON DESTROY METHOD:");
        alive = false;
        String nodeUrl = BeowulfExplorerServiceConfig.getInstance().getBeowulf_node();

        LoggerUtil.w("Crawler", "Service is shutting down, please wait...");
        long successfulCrawlBlock = Long.MAX_VALUE;
        for (CrawlerThread component : crawlers) {
            long current = component.onDestroy();
            if (successfulCrawlBlock > current)
                successfulCrawlBlock = current;
        }
        if (this.nodeCrawlingInfoRepository.updateLastCrawlOnDestroy(nodeUrl, successfulCrawlBlock)) {
            LoggerUtil.w(tag, String.format("[Crawler] Update final crawl successfully: %s", successfulCrawlBlock));
        }

        LoggerUtil.w("Crawler", "Irreversible Service is shutting down, please wait...");
        long successIrreversibleBlock = Long.MAX_VALUE;
        for (CrawlerThread component : irrCrawlers) {
            long current = component.onDestroy();
            if (successIrreversibleBlock > current)
                successIrreversibleBlock = current;
        }
        if (this.nodeCrawlingInfoRepository.updateLastIrreversibleCrawlOnDestroy(nodeUrl, successIrreversibleBlock)) {
            LoggerUtil.w(tag, "[Irreversible] Update final crawl irreversible successfully: " + successIrreversibleBlock);
        }

        try {
            LoggerUtil.w("Account", "Service is shutting down, please wait...");
            crawlAccountData.onDestroy();
        } catch (Exception e) {
            LoggerUtil.e(this, "Error while shutting down CrawlAccountData");
            LoggerUtil.exception(this, e, true);
        }

        // turn off crawler node
        if (nodeCrawlingInfoRepository.turnOff(nodeUrl))
            LoggerUtil.w(tag, "Service is turned off!");
        else
            LoggerUtil.w(tag, "Service is NOT turned off!");

        //turn of chart
        try {
            LoggerUtil.w("Chart", "Service is shutting down, please wait...");
            ChartDailyRecord successfulCrawlRecord = crawlChartDailyRecord.getSuccessfulCrawlRecord();
            long successfulCrawlDate = crawlChartDailyRecord.getSuccessfulCrawlDate();
            if (this.chartCrawlingConfigRepository.updateLastCrawlChartRecordOnDestroy(nodeUrl, successfulCrawlRecord)
                    && chartCrawlingConfigRepository.updateLastCrawlDateOnDestroy(nodeUrl, successfulCrawlDate)) {
                LoggerUtil.w(tag, "[Chart] Update final crawl record successfully: " + successfulCrawlRecord.getUnixTimeStamp());
            }
            crawlChartDailyRecord.onDestroy();
        } catch (Exception e) {
            LoggerUtil.e(this, "Error while shutting down CrawlChartDailyRecord");
            LoggerUtil.exception(this, e, true);
        }
    }

    /**
     * update jumpStep after 100 000 blocks for irreversible crawler
     */
    @Scheduled(initialDelay = 5000, fixedDelay = MILLIS_PER_MINUTE)
    private void handleBackupSegment() {
        long slowestBlock = AppConfig.getBeowulf_slowestIrreversibleCrawlBlock();
        int currentSegment = (int) slowestBlock / Constant.CRAWLER_JUMPSTEP;
        int lastSegment = this.nodeCrawlingInfoRepository.findNodeInfoByNode_url(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node()).getLast_segment();
        LoggerUtil.d(tag, String.format("Schedule update crawling segment:\n\tCurrent Segment: %s\n\tLast Segment: %s", currentSegment, lastSegment));
        if (currentSegment > lastSegment) {
            if (this.nodeCrawlingInfoRepository.updateSegment(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node(), currentSegment)) {
                LoggerUtil.w(tag, String.format("==> [Segment]: " +
                        "update %s SUCCESSFULLY", currentSegment));
            }
        }
    }

    @Bean
    public CrawlHighestBlockData beowulfCrawler1() {
        try {
            LoggerUtil.i(tag, "Beowulf crawler 1");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlHighestBlockData beowulfCrawler = (CrawlHighestBlockData) this.applicationContext.getBean(
                        "crawlHighestBlockData");
                beowulfCrawler.init("crawler1", onSegment);
                beowulfCrawler.start();
                crawlers.add(beowulfCrawler);
                return beowulfCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Bean
    public CrawlHighestBlockData beowulfCrawler2() {
        try {
            LoggerUtil.i(tag, "Beowulf crawler 2");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlHighestBlockData beowulfCrawler = (CrawlHighestBlockData) this.applicationContext.getBean(
                        "crawlHighestBlockData");
                beowulfCrawler.init("crawler2", onSegment);
                beowulfCrawler.start();
                crawlers.add(beowulfCrawler);
                return beowulfCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Bean
    public CrawlHighestBlockData beowulfCrawler3() {
        try {
            LoggerUtil.i(tag, "Beowulf crawler 3");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlHighestBlockData beowulfCrawler = (CrawlHighestBlockData) this.applicationContext.getBean(
                        "crawlHighestBlockData");
                beowulfCrawler.init("crawler3", onSegment);
                beowulfCrawler.start();
                crawlers.add(beowulfCrawler);
                return beowulfCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Bean
    public CrawlIrreversibleBlock beowulfIrrCrawler1() {
        try {
            LoggerUtil.i(tag, "Beowulf IrrCrawler 1");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlIrreversibleBlock beowulfIrrCrawler = (CrawlIrreversibleBlock) this.applicationContext.getBean(
                        "crawlIrreversibleBlock");
                beowulfIrrCrawler.init("irr1");
                beowulfIrrCrawler.start();
                irrCrawlers.add(beowulfIrrCrawler);
                return beowulfIrrCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*@Bean
    public CrawlIrreversibleBlock beowulfIrrCrawler2() {
        try {
            LoggerUtil.i(tag, "Beowulf IrrCrawler 1");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlIrreversibleBlock beowulfIrrCrawler = (CrawlIrreversibleBlock) this.applicationContext.getBean(
                        "crawlIrreversibleBlock");
                beowulfIrrCrawler.init("irr2");
                beowulfIrrCrawler.start();
                irrCrawlers.add(beowulfIrrCrawler);
                return beowulfIrrCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Bean
    public CrawlIrreversibleBlock beowulfIrrCrawler3() {
        try {
            LoggerUtil.i(tag, "Beowulf IrrCrawler 1");
            if (BeowulfExplorerServiceConfig.getInstance().isBeowulf_crawler_enable()) {
                CrawlIrreversibleBlock beowulfIrrCrawler = (CrawlIrreversibleBlock) this.applicationContext.getBean(
                        "crawlIrreversibleBlock");
                beowulfIrrCrawler.init("irr3");
                beowulfIrrCrawler.start();
                irrCrawlers.add(beowulfIrrCrawler);
                return beowulfIrrCrawler;
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }*/

    public long getBeowulf_fastestCrawlBlock() {
        long fastestBlock = 0L;
        for (String crawler : crawlerStatus.keySet()) {
            if (fastestBlock < crawlerStatus.get(crawler)) {
                fastestBlock = crawlerStatus.get(crawler);
            }
        }
        return fastestBlock;
    }

    public static long getBeowulf_slowestCrawlBlock() {
        long slowestBlock = Long.MAX_VALUE;
        for (String crawler : crawlerStatus.keySet()) {
            if (slowestBlock > crawlerStatus.get(crawler)) {
                slowestBlock = crawlerStatus.get(crawler);
            }
        }
        return slowestBlock;
    }

    public static void putCrawler(String crawlerName, long crawlBlock) {
        crawlerStatus.put(crawlerName, crawlBlock);
    }

    /**
     * IRREVERSIBLE
     */

    public long getBeowulf_fastestIrreversibleCrawlBlock() {
        long fastestBlock = 0L;
        for (String crawler : irrCrawlerStatus.keySet()) {
            if (fastestBlock < irrCrawlerStatus.get(crawler)) {
                fastestBlock = irrCrawlerStatus.get(crawler);
            }
        }
        return fastestBlock;
    }

    public static long getBeowulf_slowestIrreversibleCrawlBlock() {
        long slowestBlock = Long.MAX_VALUE;
        for (String crawler : irrCrawlerStatus.keySet()) {
            if (slowestBlock > irrCrawlerStatus.get(crawler)) {
                slowestBlock = irrCrawlerStatus.get(crawler);
            }
        }
        return slowestBlock;
    }

    public static void putIrreversibleCrawler(String crawlerName, long crawlBlock) {
        irrCrawlerStatus.put(crawlerName, crawlBlock);
    }
}
