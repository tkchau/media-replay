package com.beowulf.explorer.services.impl;

import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.document.NodeInfo;
import com.beowulf.explorer.repository.BeowulfBlockRepository;
import com.beowulf.explorer.repository.BeowulfTransactionRepository;
import com.beowulf.explorer.repository.NodeCrawlingInfoRepository;
import com.beowulf.explorer.services.BlockService;
import com.beowulf.model.request.ListBlockPagingRequest;
import com.beowulf.model.request.ListBlockProducedBySupernodePagingRequest;
import com.beowulf.model.request.ListBlocksByBlockNumberPagingRequest;
import com.beowulf.model.response.BlockDetailExtendResponse;
import com.beowulf.model.response.BlockDetailResponse;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.google.gson.Gson;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class BlockServiceImpl implements BlockService {

    private final Logger logger = LoggerFactory.getLogger(BlockService.class);

    @Autowired
    private BeowulfBlockRepository beowulfBlockRepository;

    @Autowired
    private BeowulfTransactionRepository beowulfTransactionRepository;

    @Autowired
    private NodeCrawlingInfoRepository nodeCrawlingInfoRepository;

    private List<BlockDetailResponse> convertToListBlockDetailResponse(List<BeowulfBlock> beowulfBlocks) {
        List<BlockDetailResponse> blockDetailResponses = new ArrayList<>();
        for (BeowulfBlock beowulfBlock : beowulfBlocks) {
            BlockDetailResponse blockDetailResponse = new BlockDetailResponse(beowulfBlock);
            blockDetailResponses.add(blockDetailResponse);
        }
        return blockDetailResponses;
    }

    private boolean isValidBlockRequest(long blockNumber) {
        NodeInfo nodeInfo = this.nodeCrawlingInfoRepository.findNodeInfoByNode_url(BeowulfExplorerServiceConfig.getInstance().getBeowulf_node());
        long last_crawling_block = nodeInfo.getLast_crawl();
        return blockNumber <= last_crawling_block;
    }


    private BlockDetailExtendResponse getBlockDetailExtendResponse(BeowulfBlock beowulfBlock, List<BeowulfTransaction> beowulfTransactions) {
        List<String> transactionIds = new ArrayList<>();
        for (BeowulfTransaction transaction : beowulfTransactions) {
            transactionIds.add(transaction.getTransaction_id());
        }
        BlockDetailExtendResponse blockDetailExtendResponse = new BlockDetailExtendResponse(beowulfBlock);
        blockDetailExtendResponse.setTransaction_ids(transactionIds);
        return blockDetailExtendResponse;
    }

    @Override
    public BlockDetailResponse getBlockDetailByBlockNum(long blockNumber) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get block detail for block number : " + blockNumber);
        BeowulfBlock beowulfBlock = beowulfBlockRepository.findByBlockNumber(blockNumber);
        if (beowulfBlock == null) {
            throw ServiceExceptionUtils.blockNotFound(blockNumber);
        }
        return new BlockDetailResponse(beowulfBlock);
    }

    @Override
    public BlockDetailResponse getBlockDetailByBlockID(String blockId) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get block detail for block id : " + blockId);

        BeowulfBlock beowulfBlock = beowulfBlockRepository.findByBlockId(blockId);
        if (beowulfBlock == null) {
            throw ServiceExceptionUtils.blockNotFound(blockId);
        }
        return new BlockDetailResponse(beowulfBlock);
    }

    @Override
    public List<BlockDetailResponse> getListBlockByBlockNum(ListBlocksByBlockNumberPagingRequest request) throws ServiceException {
        long startBlock = request.getStart_block();
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        logger.info("==> EXPLORER: " +
                "Request get block list with data : " + GsonSingleton.getInstance().toJson(request));

        List<BeowulfBlock> beowulfBlocks = beowulfBlockRepository.getListBlockByBlockNum(startBlock, limit, direction);
        List<BlockDetailResponse> blockDetailResponses = convertToListBlockDetailResponse(beowulfBlocks);
        if (direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(blockDetailResponses);
        }
        return blockDetailResponses;
    }

    @Override
    public List<BlockDetailResponse> getListLatestBlock(int limit) throws ServiceException {
        limit = Common.makeStableLimitation(limit);
        logger.info("==> EXPLORER: " +
                "Request get latest blocks list with limitation : " + limit);

        List<BeowulfBlock> beowulfBlocks = beowulfBlockRepository.getLastNBlocks(limit);
        return convertToListBlockDetailResponse(beowulfBlocks);
    }

    @Override
    public List<BlockDetailResponse> getListBlockProducedBySupernode(ListBlockProducedBySupernodePagingRequest request) throws ServiceException {
        Common.isValidAccountName(request.getSupernode_name());
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());

        logger.info("==> EXPLORER: " +
                "Request list blocks produced by supernode with data :" + new Gson().toJson(request));

        List<BeowulfBlock> beowulfBlocks = beowulfBlockRepository.getBlockPagingProduceBySupernode(startId, limit, direction, request.getSupernode_name());
        List<BlockDetailResponse> blockDetailResponses = convertToListBlockDetailResponse(beowulfBlocks);

        if (startId != null && direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(blockDetailResponses);
        }
        return blockDetailResponses;
    }

    @Override
    public List<BlockDetailResponse> getListBlockByPaging(ListBlockPagingRequest request) throws ServiceException {
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());

        logger.info("==> EXPLORER: " +
                "Request list blocks produced by supernode with data :" + new Gson().toJson(request));

        List<BeowulfBlock> beowulfBlocks = beowulfBlockRepository.getBlockPaging(startId, limit, direction);
        List<BlockDetailResponse> blockDetailResponses = convertToListBlockDetailResponse(beowulfBlocks);
        if (startId != null && direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(blockDetailResponses);
        }
        return blockDetailResponses;
    }

    @Override
    public long getTotalBlock() throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request total block");
        return beowulfBlockRepository.count();
    }

    @Override
    public BlockDetailExtendResponse getBlockDetailExtendByBlockNum(long blockNumber) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get block detail extend for block number : " + blockNumber);
        BeowulfBlock beowulfBlock = beowulfBlockRepository.findByBlockNumber(blockNumber);
        if (beowulfBlock == null) {
            throw ServiceExceptionUtils.blockNotFound(blockNumber);
        }
        // TODO: 27/12/2019 Consider get transaction by regex block_id
        List<BeowulfTransaction> beowulfTransactions = beowulfTransactionRepository.findByRegexBlock_id(beowulfBlock.getBlock_id());
        return getBlockDetailExtendResponse(beowulfBlock, beowulfTransactions);
    }

    @Override
    public BlockDetailExtendResponse getBlockDetailExtendByBlockID(String blockId) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Get block detail extend for block id : " + blockId);

        BeowulfBlock beowulfBlock = beowulfBlockRepository.findByBlockId(blockId);
        if (beowulfBlock == null) {
            throw ServiceExceptionUtils.blockNotFound(blockId);
        }
        List<BeowulfTransaction> beowulfTransactions = beowulfTransactionRepository.findByBlock_id(blockId);
        return getBlockDetailExtendResponse(beowulfBlock, beowulfTransactions);
    }
}