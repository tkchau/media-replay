package com.beowulf.explorer.services.impl;

import com.beowulf.constants.BeowulfConstant;
import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.BeowulfToken;
import com.beowulf.explorer.document.BeowulfTokenHolder;
import com.beowulf.explorer.repository.BeowulfOperationRepository;
import com.beowulf.explorer.repository.BeowulfTokenHolderRepository;
import com.beowulf.explorer.repository.BeowulfTokenRepository;
import com.beowulf.explorer.services.AssetService;
import com.beowulf.model.request.ListBeowulfOperationByAssetPagingRequest;
import com.beowulf.model.request.ListTokenPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import com.beowulf.model.response.TokenDetailResponse;
import com.beowulf.model.response.TokenHolderDetailResponse;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulf.utilities.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AssetServiceImpl implements AssetService {

    private final Logger logger = LoggerFactory.getLogger(AssetService.class);

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private BeowulfTokenRepository beowulfTokenRepository;

    @Autowired
    private BeowulfTokenHolderRepository beowulfTokenHolderRepository;

    @Override
    public List<OperationDetailResponse> getListTransferOperationByCurrencyCode(ListBeowulfOperationByAssetPagingRequest request) throws ServiceException {
        if (StringUtils.isEmpty(request.getCurrency_code())) {
            throw ServiceExceptionUtils.invalidRequestParam("invalid currency_code");
        }
        this.logger.info("Get transfer transaction request : " + GsonSingleton.getInstance().toJson(request));
        String transferAsset = request.getCurrency_code().trim();
        String direction = Common.handleDirectionRequest(request.getDirection());
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        List<BeowulfOperation> beowulfOperations = beowulfOperationRepository.getOperationByTransferAsset(startId, limit, direction, transferAsset);
        List<OperationDetailResponse> operationDetailResponses = beowulfOperations.stream().map(OperationDetailResponse::new).collect(Collectors.toList());
        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (startId != null)) {
            Collections.reverse(operationDetailResponses);
        }
        return operationDetailResponses;
    }

    @Override
    public List<TokenDetailResponse> getListTokenByPaging(ListTokenPagingRequest request) throws ServiceException {
        this.logger.info("Get list token detail");
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        List<BeowulfToken> beowulfTokens = beowulfTokenRepository.getTokenPaging(startId, limit, direction);

        List<TokenDetailResponse> tokenDetailResponses = new ArrayList<>();
        for (BeowulfToken token : beowulfTokens) {
            tokenDetailResponses.add(new TokenDetailResponse(token));
        }
        if (startId != null && direction.equals(Constant.LIST_DIRECTION_PREVIOUS)) {
            Collections.reverse(tokenDetailResponses);
        }
        return tokenDetailResponses;
    }

    @Override
    public int getTotalToken() throws ServiceException {
        this.logger.info("Get total token");
        long totalToken = beowulfTokenRepository.count();
        return Math.toIntExact(totalToken);
    }

    @Override
    public long getTotalTokenHolders(String token) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request total token {} holder", token);
        token = token.toUpperCase();
        if (!isSupportedAsset(token)) {
            throw ServiceExceptionUtils.invalidRequestParam(String.format("Unsupported asset: %s", token));
        }
        return this.beowulfTokenHolderRepository.getTotalHolders(token);
    }

    @Override
    public TokenHolderDetailResponse getAccountControl(String token) throws ServiceException {
        this.logger.info("Get account control");
        token = token.toUpperCase();
        BeowulfToken beowulfToken = checkTokenAndFindBeowulfToken(token);
        int tokenPrecision = beowulfToken.getDecimals();
        String name = beowulfToken.getControl_account();
        BeowulfTokenHolder beowulfTokenHolder = this.beowulfTokenHolderRepository.findBeowulfTokenHolderByTokenAndAccount(token, name);
        return new TokenHolderDetailResponse(beowulfTokenHolder, tokenPrecision);
    }

    @Override
    public List<TokenHolderDetailResponse> getTopTokenHolders(String token, int limit) throws ServiceException {
        this.logger.info("Get top {} - {} holder detail", limit, token);
        if (limit <= 0 || limit > Constant.MAX_TOKEN_HOLDER_RESPONSE) {
            limit = Constant.MAX_TOKEN_HOLDER_RESPONSE;
        }
        token = token.toUpperCase();
        BeowulfToken beowulfToken = checkTokenAndFindBeowulfToken(token);
        int tokenPrecision = beowulfToken.getDecimals();
        List<BeowulfTokenHolder> topHolders = this.beowulfTokenHolderRepository.getTopTokenHoldersByTokenName(token, limit);

        List<TokenHolderDetailResponse> topHolderResponses = new ArrayList<>();
        for (BeowulfTokenHolder holder : topHolders) {
            topHolderResponses.add(new TokenHolderDetailResponse(holder, tokenPrecision));
        }
        return topHolderResponses;
    }

    @Override
    public TokenDetailResponse getTokenDetail(String token) throws ServiceException {
        this.logger.info("Get token detail {}", token);
        token = token.toUpperCase();
        BeowulfToken beowulfToken = checkTokenAndFindBeowulfToken(token);
        return new TokenDetailResponse(beowulfToken);
    }

    private BeowulfToken checkTokenAndFindBeowulfToken(String token) {
        if (token.length() > BeowulfConstant.MAXIMUM_ASSET_LEN) {
            throw ServiceExceptionUtils.invalidRequestParam(String.format("Invalid asset: %s", token));
        }
        BeowulfToken beowulfToken = this.beowulfTokenRepository.findBeowulfTokenByName(token);
        if (beowulfToken == null) {
            throw ServiceExceptionUtils.invalidRequestParam(String.format("Unsupported asset: %s", token));
        }
        return beowulfToken;
    }

    private boolean isSupportedAsset(String asset) throws InvalidParameterException {
        if (asset.equals(BeowulfConstant.BWF_ASSET_SYMBOL) || asset.equals(BeowulfConstant.W_ASSET_SYMBOL)) {
            return true;
        } else if (asset.length() > BeowulfConstant.MAXIMUM_ASSET_LEN) {
            throw new InvalidParameterException(String.format("Invalid asset: %s", asset));
        }
        return this.beowulfTokenRepository.findBeowulfTokenByName(asset) != null;
    }
}
