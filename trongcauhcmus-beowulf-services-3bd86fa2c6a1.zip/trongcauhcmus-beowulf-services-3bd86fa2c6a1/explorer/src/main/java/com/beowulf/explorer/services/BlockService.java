package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.request.ListBlockPagingRequest;
import com.beowulf.model.request.ListBlockProducedBySupernodePagingRequest;
import com.beowulf.model.request.ListBlocksByBlockNumberPagingRequest;
import com.beowulf.model.response.BlockDetailExtendResponse;
import com.beowulf.model.response.BlockDetailResponse;

import java.util.List;

public interface BlockService {

    long getTotalBlock() throws ServiceException;

    List<BlockDetailResponse> getListBlockByBlockNum(ListBlocksByBlockNumberPagingRequest request) throws ServiceException;

    BlockDetailResponse getBlockDetailByBlockNum(long blockNumberRequest) throws ServiceException;

    BlockDetailResponse getBlockDetailByBlockID(String blockId) throws ServiceException;

    List<BlockDetailResponse> getListLatestBlock(int limit) throws ServiceException;

    List<BlockDetailResponse> getListBlockProducedBySupernode(ListBlockProducedBySupernodePagingRequest request) throws ServiceException;

    List<BlockDetailResponse> getListBlockByPaging(ListBlockPagingRequest request);

    BlockDetailExtendResponse getBlockDetailExtendByBlockNum(long blockNumberRequest) throws ServiceException;

    BlockDetailExtendResponse getBlockDetailExtendByBlockID(String blockID) throws ServiceException;
}
