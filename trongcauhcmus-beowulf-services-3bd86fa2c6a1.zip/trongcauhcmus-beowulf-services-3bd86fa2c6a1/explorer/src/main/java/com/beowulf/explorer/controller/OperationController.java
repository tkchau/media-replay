package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.OperationService;
import com.beowulf.model.request.ListBeowulfOperationPagingRequest;
import com.beowulf.model.request.ListOperationByAccountPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "v1/operation", produces = "application/json; charset=UTF-8")
public class OperationController {

    @Autowired
    private OperationService operationService;

    @RequestMapping(value = "/paging", method = RequestMethod.POST)
    public List<OperationDetailResponse> listOperationPaging(@RequestBody ListBeowulfOperationPagingRequest request) {
        return operationService.getListOperation(request);
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public long totalOperation() {
        return operationService.totalOperations();
    }

    @RequestMapping(value = "/count/account/{account_name}", method = RequestMethod.GET)
    public long totalOperationOfAccount(@PathVariable(name = "account_name") String accountName){
        return operationService.totalOperationOfAccount(accountName);
    }

    @RequestMapping(value = "/account/list", method = RequestMethod.POST)
    public List<OperationDetailResponse> getOperationByName(@RequestBody ListOperationByAccountPagingRequest request) {
        return operationService.getOperationByAccount(request);
    }

    @RequestMapping(value = "/transaction/{transaction_id}", method = RequestMethod.GET)
    public List<OperationDetailResponse> getOperationByTransactionId(@PathVariable(name = "transaction_id") String transaction_id){
        return operationService.getOperationByTransactionId(transaction_id);
    }

    @RequestMapping(value = "/id/{operation_id}", method = RequestMethod.GET)
    public OperationDetailResponse getOperationByOperationId(@PathVariable(name = "operation_id") String operation_id){
        return operationService.getOperationByOperationId(operation_id);
    }
}
