package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.response.SupernodeDetailResponse;

import java.util.List;

public interface SupernodeService {

    SupernodeDetailResponse getSupernodeDetailByName(String supernodeName) throws ServiceException;

//    public Object getSuperNodeTransaction(GetSupernodeTransactionRequest request) throws ServiceException;

    List<SupernodeDetailResponse> getSupernodeList() throws ServiceException;

}
