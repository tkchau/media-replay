package com.beowulf.explorer.crawler;

import com.beowulf.constants.ActionConstant;
import com.beowulf.explorer.config.AppConfig;
import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.explorer.document.*;
import com.beowulf.explorer.document.operations.AccountCreateData;
import com.beowulf.explorer.document.operations.AccountUpdateData;
import com.beowulf.explorer.document.operations.SmtCreateData;
import com.beowulf.explorer.document.operations.TransferData;
import com.beowulf.explorer.repository.*;
import com.beowulf.explorer.repository.folked.extend.BeowulfFolkedDataRepositoryExtend;
import com.beowulf.model.BeowulfData;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.LoggerUtil;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.base.models.Block;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.enums.OperationType;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.operations.Operation;
import com.mongodb.MongoException;
import com.mongodb.MongoSocketOpenException;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Scope("prototype")
public class CrawlIrreversibleBlock extends CrawlerThread {
    @Autowired
    private ActionRepository actionRepository;

    @Autowired
    private BeowulfBlockRepository beowulfBlockRepository;

    @Autowired
    private BeowulfTransactionRepository beowulfTransactionRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @Autowired
    private BeowulfTokenRepository beowulfTokenRepository;

    @Autowired
    private NodeCrawlingInfoRepository nodeCrawlingInfoRepository;

    @Autowired
    private BeowulfFolkedDataRepositoryExtend beowulfFolkedDataRepositoryExtend;

    @Autowired
    private CrawlAccountData crawlAccountData;

    private final Logger logger = LoggerFactory.getLogger(CrawlIrreversibleBlock.class);

    // Handle initial Beowulf node
    private BeowulfJ beowulfJ;
    private String nodeUrl;
    private String crawlerName;

    // Handle for crawling irreversible block
    private long currentIrreversibleBlock;
    private ObjectId currentAction;
    private String currentIrreversibleBlockId;
    private long successIrreversibleBlock;

    // Handle field bc_id in document
    private long currentBlockTimestamp;

    // Handle failed remove folked document
    private Map<String, BeowulfTransaction> failedRemoveTransaction = new HashMap<>();

    private boolean isProcessing;

    public void init(String name) throws BeowulfCommunicationException, BeowulfResponseException {
        this.crawlerName = name;
        _init();
    }

    private void _init() throws BeowulfCommunicationException, BeowulfResponseException {
        this.nodeUrl = BeowulfExplorerServiceConfig.getInstance().getBeowulf_node();
        this.beowulfJ = BeowulfCommunicate.init(nodeUrl);
        long startBlock = BeowulfExplorerServiceConfig.getInstance().getBeowulf_startblock();
        this.currentIrreversibleBlock = nodeCrawlingInfoRepository.getLastCrawlingIrreversibleBlock(startBlock, this.nodeUrl);
        long irreversibleBlock = this.beowulfJ.getDynamicGlobalProperties().getLastIrreversibleBlockNum();
        if (irreversibleBlock < this.currentIrreversibleBlock) {
            this.currentIrreversibleBlock = irreversibleBlock;
        }
    }

    @Override
    public long onDestroy() {
        int i = 0;
        while (this.isProcessing) {
            System.out.println((i + 1) + "s");
            i++;
            doSleep(1000);
        }
        LoggerUtil.w(this.getName(), "Irreversible Service shutdown completed!");
        return this.successIrreversibleBlock;
    }

    @Override
    public void run() {
        LoggerUtil.i(this.getName(), String.format("Start Beowulf Irreversible Crawling %s with block %s", this.getCrawlerName(), this.currentIrreversibleBlock));
        long lastIrreversibleBlock = this.currentIrreversibleBlock;
        while (AppConfig.isAlive()) {
            try {
                lastIrreversibleBlock = Math.min(this.beowulfJ.getDynamicGlobalProperties().getLastIrreversibleBlockNum(),
                        AppConfig.getBeowulf_slowestCrawlBlock());
            } catch (Exception e) {
                e.printStackTrace();
                this.logger.error("==> EXPLORER: " +
                        "[Crawler] - Beowulf node get irreversible block exception");
            }
            while (this.currentIrreversibleBlock <= lastIrreversibleBlock && AppConfig.isAlive()) {
                this.isProcessing = true;
                try {
                    // Handle block
                    Block block = this.beowulfJ.getBlock(this.currentIrreversibleBlock);
                    this.currentIrreversibleBlockId = block.getBlockId().toString();
                    handleBlock(block);

                    // Update crawl data
                    this.successIrreversibleBlock = this.currentIrreversibleBlock;
                    updateLastIrreversibleCrawl(this.successIrreversibleBlock);
                    AppConfig.putIrreversibleCrawler(this.crawlerName, this.successIrreversibleBlock);
                    this.currentIrreversibleBlock++;
                } catch (BeowulfCommunicationException | BeowulfResponseException e) {
                    this.logger.error("==> EXPLORER: " +
                            "[Crawling Irreversible Block] - Can not get data of Block {} from Beowulf Network", this.currentIrreversibleBlock);
                } catch (Exception e) {
                    this.logger.error("==> EXPLORER: " +
                            "[Crawling Irreversible Block] - Can not handle data of Block with Error: ");
                    e.printStackTrace();
                } finally {
                    this.isProcessing = false;
                }
            }

            if (!AppConfig.isAlive()) break;
            doSleep();
        }
        LoggerUtil.w(this.getName(), "[Crawler Irreversible] on destroy method completed with block: " + this.currentIrreversibleBlock);
    }

    /**
     * Handling data of Irreversible Block for Explorer Service documents
     * and putting into DB if it is satisfied
     *
     * @param block The Block object of Beowulf Block-chain
     */
    private void handleBlock(Block block) {
        try {
            long start = System.currentTimeMillis();
            // Step 1: Create new Action for handle new block document into DB:
            Action handleIrrBlockAction = new Action(
                    this.currentIrreversibleBlockId,
                    ActionConstant.IRREVERSIBLE_HANDLE_ACTION,
                    ActionConstant.TTL_ACTION
            );

            handleIrrBlockAction = this.actionRepository.save(handleIrrBlockAction);
            this.currentAction = handleIrrBlockAction.getId();

            // Find last crawl block with block number:
            BeowulfBlock temporaryBlock = this.beowulfBlockRepository.findByBlockNumber(this.currentIrreversibleBlock);

            // If block has different block id from old one => folked block
            if (temporaryBlock != null && !this.currentIrreversibleBlockId.equals(temporaryBlock.getBlock_id())) {
                this.logger.warn("==> EXPLORER: " +
                        "[Crawling Irreversible Block] - Handle folked Block {}", this.currentIrreversibleBlock);
                // Step 2: Handle old folked block => remove old data:
                handleFolkedBlock(temporaryBlock);
                // Step 3: Handle new block => insert new data:
                handleIrreversibleBlock(block, false);

            } else {
                // Step 4: Handle check consistency for this current block:
                handleIrreversibleBlock(block, true);
            }
            long end = System.currentTimeMillis();
            this.logger.info((String.format("[Crawler Irreversible] - End scan block: %s == time execute: %sms",
                    this.currentIrreversibleBlock, end - start)));
        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Irreversible Block] - Has been handle by another bot");
        }
    }

    // TODO: 13/01/2020 Check consistency by Query list transactions paging

    /**
     * Handle data of irreversible block - insert new data Block-chain in this block
     *
     * @param block            The Block object of Beowulf Block-chain.
     * @param checkConsistency The flag check consistency process.
     */
    private void handleIrreversibleBlock(Block block, boolean checkConsistency) {

        this.currentBlockTimestamp = block.getTimestamp().getDateTimeAsTimestamp();
        long blockFee = 0L;
        int blockOperation = 0;

        // Step 1: Get list transactions in Block Object:
        List<CompletedTransaction> transactions = block.getTransactions();
        for (CompletedTransaction transaction : transactions) {
            String transactionId = transaction.getTransactionId().toString();
            long transactionFee = 0L;
            int txIndex = transaction.getTransactionNum();

            List<Operation> operations = transaction.getOperations();
            blockOperation += operations.size();

            for (int indexOp = 0; indexOp < operations.size(); indexOp++) {
                Operation operation = operations.get(indexOp);
                // Step 2: Parse data of Operation and insert into OperationRepository in sequence:
                handleOperation(indexOp, transactionId, operation, txIndex, checkConsistency);
                // Step 3: Calculate Total fee, total operation of Block:
                transactionFee += BeowulfCommunicate.getFeeOfOperation(operation);
            }
            handleTransaction(transaction, transactionFee, txIndex, checkConsistency);
            blockFee += transactionFee;
        }

        // Step 4: Parse data of block and insert into BlockRepository:
        boolean isSuccessfulProcess = getBlockData(block, blockFee);

        // Step 5: Parse data belongs to Super-node Account from Block and update data in AccountRepository:
        if (isSuccessfulProcess) {
            BeowulfSupernode dataSupernode = new BeowulfSupernode(
                    block.getSupernode().getName(),
                    this.currentIrreversibleBlockId,
                    this.currentIrreversibleBlock,
                    blockOperation,
                    block.getBlockReward().getAmount(),
                    blockFee);
            updateAccountSupernode(dataSupernode);
        }
    }

    /**
     * Updating last crawling block number of Block-chain when shutdown or
     * maintenance services.
     *
     * @param blockNumber last block number crawling
     */
    private void updateLastIrreversibleCrawl(long blockNumber) {
        try {
            this.nodeCrawlingInfoRepository.updateLastIrreversibleCrawl(this.nodeUrl, blockNumber);
        } catch (MongoSocketOpenException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawler] - Can not open connection to mongodb to update last sync");
        }
    }

    /**
     * Getting new data of Block and putting into DB if it is satisfied
     *
     * @param block    The Block object of Beowulf Block-chain.
     * @param totalFee The total fee of transactions in block.
     * @return Successful Handle get data of Block or not?
     */
    private boolean getBlockData(Block block, long totalFee) {
        try {
            //Step 1: Create new Block document:
            BeowulfBlock beowulfBlock = new BeowulfBlock(block);
            beowulfBlock.setBlock_number(this.currentIrreversibleBlock);
            beowulfBlock.setTotal_fee(totalFee);

            BeowulfData bcData = new BeowulfData(this.currentIrreversibleBlock, 0, 0, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfBlock.setBc_id(bcId);

            //Step 2: Insert new Block document into DB:
            this.beowulfBlockRepository.save(beowulfBlock);
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Irreversible Block] - Update SUCCESSFULLY Block id {}", beowulfBlock.getBlock_id());
            return true;

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Block] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Block] - Cannot get and insert data of Block: {}", this.currentIrreversibleBlock);
            e.printStackTrace();
            this.actionRepository.removeAction(this.currentAction);
        }
        return false;
    }

    /**
     * Getting new data of Transaction and putting into DB if it is satisfied
     *
     * @param transaction      The CompletedTransaction object of Beowulf Block-chain.
     * @param txIndex          The Transaction num for generation bc_id
     * @param checkConsistency The flag check consistency process.
     */
    private void handleTransaction(CompletedTransaction transaction, long transactionFee, int txIndex, boolean checkConsistency) {
        try {
            //Step 1: Create new Transaction document:
            BeowulfTransaction beowulfTransaction = new BeowulfTransaction(transaction, this.currentIrreversibleBlockId, transactionFee);
            BeowulfData bcData = new BeowulfData(this.currentIrreversibleBlock, txIndex, 0, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfTransaction.setBc_id(bcId);

            //Step 2: Insert new Transaction document into DB:
            BeowulfTransaction existedTransaction = this.beowulfTransactionRepository.findByTransactionId(beowulfTransaction.getTransaction_id());
            if (existedTransaction == null) {
                this.beowulfTransactionRepository.save(beowulfTransaction);
                this.logger.debug("==> EXPLORER: " +
                        "[Crawling Irreversible Transaction] - Update SUCCESSFULLY transaction id {}", beowulfTransaction.getTransaction_id());

            } else if (!checkConsistency) {
                // If existed transaction in another Block => remove this transaction document:
                this.beowulfTransactionRepository.removeTransactionByTransactionId(beowulfTransaction.getTransaction_id());
                this.beowulfTransactionRepository.save(beowulfTransaction);
            }

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Transaction] - Has been gotten by another bot");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Transaction] - <Mongo> Cannot remove Transaction with Tx_id: {}", transaction.getTransactionId().toString());
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Transaction] - Cannot get and insert data of Transaction with Tx_id: {}", transaction.getTransactionId().toString());
            e.printStackTrace();
        }
    }

    /**
     * Getting new data of Account and putting into DB if it is satisfied
     *
     * @param accountCreateOperation The AccountCreateOperation object of Beowulf Block-chain.
     * @param blockNumber            The block number of Block has this create account operation.
     * @param createdTime            The time created transaction contains this account create operation.
     * @param checkConsistency       The flag check consistency process.
     */
    private void handleAccountData(BeowulfOperation accountCreateOperation, long blockNumber, long createdTime, boolean checkConsistency) {
        String accountName = accountCreateOperation.getRelate_account_2();
        try {
            //Step 1: Create new Account document:
            BeowulfAccount beowulfAccount = new BeowulfAccount((AccountCreateData) accountCreateOperation.getOperation());
            beowulfAccount.setCreated_operation_id(accountCreateOperation.getOperation_id());
            beowulfAccount.setCreated_block(blockNumber);
            beowulfAccount.setCreated_at(createdTime);

            //Step 2: Insert new Account document into DB:
            BeowulfAccount existedAccount = this.beowulfAccountRepository.findAccountByName(accountName);

            if (existedAccount == null) {
                this.beowulfAccountRepository.save(beowulfAccount);
                this.logger.debug("==> EXPLORER: " +
                        "[Crawling Irreversible Account] - Update SUCCESSFULLY account {}", accountName);

            } else if (!checkConsistency) {
                // If existed Account created in another Block => remove this Account document:
                this.beowulfAccountRepository.removeAccountByAccountName(accountName);
                this.beowulfAccountRepository.save(beowulfAccount);
            }

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Account] - Has been gotten by another bot");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account] - <Mongo> Cannot remove Account: {}", accountName);
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account] - Cannot get and insert data of Account: {}", accountName);
            e.printStackTrace();
        }
    }

    /**
     * Getting new data of Token and putting into DB if it is satisfied
     *
     * @param smtCreateOperation The SmtCreateOperation object of Beowulf Block-chain.
     * @param blockNumber        The block number of Block has this create account operation.
     * @param createdTime        The time created transaction contains this account create operation.
     * @param operationId        The operation id of operation create smt token.
     * @param checkConsistency   The flag check consistency process.
     */
    private void handleTokenData(BeowulfOperation smtCreateOperation, long blockNumber, Long createdTime, String operationId, boolean checkConsistency) {
        SmtCreateData smtCreateData = (SmtCreateData) smtCreateOperation.getOperation();
        String tokenName = smtCreateData.getSymbol().getName();
        try {
            // Step 1: Create new Token document:
            BeowulfToken beowulfToken = new BeowulfToken(smtCreateData);
            beowulfToken.setCreated_block(blockNumber);
            beowulfToken.setCreated_at(createdTime);
            beowulfToken.setOperation_id(operationId);

            //Step 2: Insert new Token document into DB:
            BeowulfToken existedToken = this.beowulfTokenRepository.findBeowulfTokenByName(tokenName);
            if (existedToken == null) {
                this.beowulfTokenRepository.save(beowulfToken);
                this.logger.debug("==> EXPLORER: " +
                        "[Crawling Irreversible Token] - Update SUCCESSFULLY Token {}", tokenName);

            } else if (!checkConsistency) {
                this.beowulfTokenRepository.removeTokenByName(tokenName);
                this.beowulfTokenRepository.save(beowulfToken);
            }

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Token] - Has been gotten by another bot");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - <Mongo> Cannot remove Token: {}", tokenName);
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - Cannot get and insert data of Token: {}", tokenName);
            e.printStackTrace();
        }
    }

    /**
     * Getting new data of Operation and putting into DB if it is satisfied
     * and update account, token, token holder collections.
     *
     * @param opIndex          The Order of Operation in List Operation of Transaction.
     * @param transactionId    The transaction id of Transaction.
     * @param operation        The Operation object in Beowulf Block-chain.
     * @param txIndex          The Transaction num for generation bc_id
     * @param checkConsistency The flag check consistency process.
     */
    private void handleOperation(int opIndex, String transactionId, Operation operation, int txIndex, boolean checkConsistency) {
        BeowulfOperation beowulfOperation = null;
        try {
            //Step 1: Create new Operation Document:
            beowulfOperation = BeowulfOperation.parseOperation(operation, transactionId, opIndex);
            BeowulfData bcData = new BeowulfData(this.currentIrreversibleBlock, txIndex, opIndex, this.currentBlockTimestamp);
            ObjectId bcId = Common.generateObjectIdFromData(bcData);
            beowulfOperation.setBc_id(bcId);

            //Step 2: Insert new Operation document into DB:
            BeowulfOperation existedOperation = this.beowulfOperationRepository.findBeowulfOperationByOperation_id(beowulfOperation.getOperation_id());

            if (existedOperation == null) {
                beowulfOperation = this.beowulfOperationRepository.save(beowulfOperation);
                this.logger.debug("==> EXPLORER: " +
                        "[Crawling Irreversible Operation] - Update SUCCESSFULLY operation id {}", beowulfOperation.getOperation_id());

            } else if (!checkConsistency) {
                // If existed operation in another Block => remove this operation document:
                this.beowulfOperationRepository.removeOperationByOperationId(beowulfOperation.getOperation_id());
                beowulfOperation = this.beowulfOperationRepository.save(beowulfOperation);
            }

        } catch (IllegalArgumentException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Operation] - Not supported on this Operation");
        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Operation] - Has been gotten by another bot");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Operation] - <Mongo> Cannot remove Operation with tx_id: {} - index: {}", transactionId, opIndex);
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account] - Cannot get and insert data of Operation with tx_id: {} - index: {}", transactionId, opIndex);
            e.printStackTrace();
        }

        // Step 3: Update account, token, token holder collections.
        if (beowulfOperation != null) {
            if (beowulfOperation.getType() == OperationType.ACCOUNT_CREATE_OPERATION) {
                // If operation is account create operation => create new account document:
                handleAccountData(beowulfOperation, this.currentIrreversibleBlock, this.currentBlockTimestamp, checkConsistency);

            } else if (beowulfOperation.getType() == OperationType.SMT_CREATE_OPERATION) {
                // ==> Parse data of Operation for Token data and insert into TokenRepository.
                handleTokenData(beowulfOperation, this.currentIrreversibleBlock, this.currentBlockTimestamp, beowulfOperation.getOperation_id(), checkConsistency);
                // Handle update new data token holder:
                SmtCreateData smtCreateData = (SmtCreateData) beowulfOperation.getOperation();
                new Thread(() -> this.crawlAccountData.syncTokenHolderBalance(smtCreateData.getControlAccount(), smtCreateData.getSymbol().getName())).start();

            } else if (beowulfOperation.getType() == OperationType.TRANSFER_OPERATION) {
                // Handle update data token holders are in Transfer operation:
                TransferData transferData = (TransferData) beowulfOperation.getOperation();
                new Thread(() -> {
                    this.crawlAccountData.syncTokenHolderBalance(transferData.getFrom(), transferData.getAmount().getName());
                    this.crawlAccountData.syncTokenHolderBalance(transferData.getTo(), transferData.getAmount().getName());
                }).start();

            } else if (beowulfOperation.getType() == OperationType.ACCOUNT_UPDATE_OPERATION) {
                // Handle update data of account is in Account Update operation:
                AccountUpdateData accountUpdateData = (AccountUpdateData) beowulfOperation.getOperation();
                new Thread(() -> this.crawlAccountData.updateAccountInfo(accountUpdateData)).start();
            }
        }
    }

    /**
     * Getting new data for Account is Super-node Type and updating into DB if it is satisfied
     *
     * @param dataSupernode The Data Supernode Document object of block in Beowulf Block-chain.
     */
    private void updateAccountSupernode(BeowulfSupernode dataSupernode) {
        String supernodeName = dataSupernode.getSupernode_account();
        try {
            BeowulfAccount existedAccount =
                    this.beowulfAccountRepository.findAccountByName(supernodeName);
            // Step 1: Ensure data of account super-node exist
            if (existedAccount == null) {
                throw new Exception(String.format("updateAccountSupernode fail because account %s does not exist", supernodeName));
            }
            //Step 2: Increase data belongs to Super-node type for Account document in DB:
            this.beowulfAccountRepository.increaseDataOfSupernode(
                    supernodeName,
                    dataSupernode.getTotal_rewards(),
                    dataSupernode.getTotal_fee(),
                    dataSupernode.getTotal_operations()
            );
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - <Mongo> Cannot update Data of Account Supernode");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Cannot get and update data of Account super-node with block: {} with Error {}", dataSupernode.getMined_block_number(), e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Getting folked data for Account is Super-node Type and update data (decrease) into DB if it is satisfied
     *
     * @param dataSupernode The Data Supernode Document object of block in Beowulf Block-chain.
     */
    private void reUpdateAccountSupernode(BeowulfSupernode dataSupernode) {
        String supernodeName = dataSupernode.getSupernode_account();
        try {
            BeowulfAccount existedAccount =
                    this.beowulfAccountRepository.findAccountByName(supernodeName);
            // Step 1: Ensure data of account super-node exist
            if (existedAccount == null) {
                throw new Exception(String.format("updateAccountSupernode fail because account %s does not exist", supernodeName));
            }
            // Step 2: Decrease data belongs to Super-node type for Account document in DB:
            this.beowulfAccountRepository.decreaseDataOfSupernode(
                    supernodeName,
                    dataSupernode.getTotal_rewards(),
                    dataSupernode.getTotal_fee(),
                    dataSupernode.getTotal_operations()
            );
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - <Mongo> Cannot update Data for Account Supernode");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Super-node] - Cannot get and update data of Account super-node with block: {} with Error {}", dataSupernode.getMined_block_number(), e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Putting thread sleep.
     */
    private static void doSleep() {
        doSleep(5000);
    }

    private static void doSleep(long millisecond) {
        try {
            Thread.sleep(millisecond);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle data of folked block - remove data Block-chain in this block
     *
     * @param folkedBlock The Block document object of Folked block in Beowulf Block-chain.
     */
    private void handleFolkedBlock(BeowulfBlock folkedBlock) {
        String folkedBlockId = folkedBlock.getBlock_id();
        try {
            // Step 1: Get list transactions of folked Block and handle these:
            List<BeowulfTransaction> folkedTransactionList =
                    this.beowulfTransactionRepository.findByBlock_id(folkedBlockId);

            int totalOperations = 0;
            for (BeowulfTransaction folkedTx : folkedTransactionList) {
                // Handle folked Transaction:
                this.beowulfFolkedDataRepositoryExtend.insertFolkedTransaction(folkedTx);
                totalOperations += handleFolkedTransaction(folkedTx);
            }

            // Step 2: Add to FolkedBlockRepository and Remove folked Block document in BlockRepository:
            // Save to Folked Block Repository
            this.beowulfFolkedDataRepositoryExtend.insertFolkedBlock(folkedBlock);
            // Remove from Stable Block Repository
            boolean isSuccessfulProcess = this.beowulfBlockRepository.removeBlockById(folkedBlock.getId());

            // Step 3: Parse data belongs to Super-node Account from Block and re-update data in AccountRepository:
            if (isSuccessfulProcess) {
                BeowulfSupernode dataSupernode = new BeowulfSupernode(
                        folkedBlock.getSupernode(),
                        folkedBlock.getBlock_id(),
                        folkedBlock.getBlock_number(),
                        totalOperations,
                        folkedBlock.getBlock_reward(),
                        folkedBlock.getTotal_fee());
                reUpdateAccountSupernode(dataSupernode);
            }

        } catch (DuplicateKeyException e) {
            this.logger.debug("==> EXPLORER: " +
                    "[Crawling Irreversible Block] - Has been gotten by another bot");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Irreversible Block] - Cannot remove folked block {}", folkedBlockId);
            e.printStackTrace();
            this.actionRepository.removeAction(this.currentAction);
        }
    }

    /**
     * Handle data of folked transaction - remove data Block-chain belongs to this transaction (Operations and Accounts)
     *
     * @param folkedTransaction The Transaction document object of Folked transaction in Beowulf Block-chain.
     * @return number operations in transaction
     */
    private int handleFolkedTransaction(BeowulfTransaction folkedTransaction) {
        String folkedBlockId = folkedTransaction.getBlock_id();
        String folkedTransactionId = folkedTransaction.getTransaction_id();
        // Find list operations of folked transaction by transaction_id
        List<BeowulfOperation> folkedOperationList =
                this.beowulfOperationRepository.findBeowulfOperationByTransactionId(folkedTransactionId);
        // Number of operations successful remove
        int successCount = 0;

        // Remove operations & accounts
        for (BeowulfOperation folkedOperation : folkedOperationList) {
            try {
                // Step 1: Handle remove Operation document in Transaction with Object Id
                if (this.beowulfOperationRepository.removeOperationById(folkedOperation.getId())) {
                    // Save to Folked Operation Repository:
                    this.beowulfFolkedDataRepositoryExtend.insertFolkedOperation(folkedOperation);
                    successCount++;
                    this.logger.debug("==> EXPLORER: " +
                            "[Crawling Irreversible Operation] - Remove SUCCESSFULLY operation id {} in folked block {}", folkedOperation.getOperation_id(), folkedBlockId);
                }
                // Step 2: Handle remove Account created in folked block
                if (folkedOperation.getType() == OperationType.ACCOUNT_CREATE_OPERATION) {
                    String newFolkedAccount = folkedOperation.getRelate_account_2();
                    if (this.beowulfAccountRepository.removeAccountByAccountName(newFolkedAccount)) {
                        this.logger.debug("==> EXPLORER: " +
                                "[Crawling Irreversible Account] - Remove SUCCESSFULLY account {} from folked block {}", newFolkedAccount, folkedBlockId);
                    }
                    // Remove Token created in folked block
                } else if (folkedOperation.getType() == OperationType.SMT_CREATE_OPERATION) {
                    SmtCreateData smtCreateData = (SmtCreateData) folkedOperation.getOperation();
                    if (this.beowulfTokenRepository.removeTokenByName(smtCreateData.getSymbol().getName())) {
                        this.logger.debug("==> EXPLORER: " +
                                "[Crawling Irreversible Account] - Remove SUCCESSFULLY token {} from folked block {}", smtCreateData.getSymbol().getName(), folkedBlockId);
                    }
                }
            } catch (MongoException e) {
                this.logger.error("==> EXPLORER: " +
                        "[Crawling Irreversible Operation] - <Mongo> Cannot remove Operation Document - Object id {}", folkedOperation.getId());
            } catch (Exception e) {
                this.logger.error("==> EXPLORER: " +
                        "[Crawling Irreversible Operation] - Cannot remove Tx {} in folked block {}", folkedTransaction.getTransaction_id(), folkedBlockId);
                e.printStackTrace();
            }
        }

        // Remove transaction
        try {
            // Step 3: If unsuccessful remove all operations in transaction
            if (successCount != folkedOperationList.size()) {
                // Put this transaction document to map to remove later
                this.failedRemoveTransaction.put(folkedTransactionId, folkedTransaction);
            }
            // Handle remove Transaction document with Object Id
            this.beowulfTransactionRepository.removeTransactionById(folkedTransaction.getId());

        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Irreversible Transaction] - <Mongo> Cannot remove Transaction Document - Object id {}", folkedTransaction.getId());
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Irreversible Transaction] - Cannot remove Tx {} in folked block {}", folkedTransactionId, folkedBlockId);
            e.printStackTrace();
        }
        return folkedOperationList.size();
    }

    public void setCurrentIrreversibleBlock(long currentIrreversibleBlock) {
        this.currentIrreversibleBlock = currentIrreversibleBlock;
    }

    public String getCrawlerName() {
        return crawlerName;
    }

    public void setCrawlerName(String crawlerName) {
        this.crawlerName = crawlerName;
    }
}