package com.beowulf.explorer.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class BeowulfExplorerServiceConfig {
    private static BeowulfExplorerServiceConfig appContext;

    // Secret declare
    private String crypto_aes_secretkey;
    private String crypto_aes_initVector;

    private String beowulf_node;
    private long beowulf_startblock;
    private boolean beowulf_crawler_enable;
    private String allow_origin_domains;

    // Chart config
    private String beowulf_csv_filepath;

    private BeowulfExplorerServiceConfig() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext();
        Properties properties = new Properties();
        try {

            String configFile = System.getProperty("explorer.conf");
            if (configFile == null) {
                configFile = "classpath:/explorer.properties";
            }
            properties.load(appContext.getResource(configFile).getInputStream());

            crypto_aes_secretkey = properties.getProperty("crypto.aes.secretkey");
            crypto_aes_initVector = "1234567812345678";

            beowulf_node = properties.getProperty("beowulf.node");
            beowulf_startblock = Long.parseLong(properties.getProperty("beowulf.startblock"));
            beowulf_crawler_enable = Boolean.parseBoolean(properties.getProperty("beowulf.explorer.crawler.enable", "true"));

            allow_origin_domains = properties.getProperty("host.cors", "beowulfchain.com");
            // Config crawl chart services
            beowulf_csv_filepath = properties.getProperty("beowulf.csv.filepath", "./chart_sample.csv");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static BeowulfExplorerServiceConfig getInstance() {
        if (appContext == null) {
            appContext = new BeowulfExplorerServiceConfig();
        }
        return appContext;
    }

    public String getCrypto_aes_secretkey() {
        return crypto_aes_secretkey;
    }

    public String getCrypto_aes_initVector() {
        return crypto_aes_initVector;
    }

    public static BeowulfExplorerServiceConfig getAppContext() {
        return appContext;
    }

    public long getBeowulf_startblock() {
        return beowulf_startblock;
    }

    public String getBeowulf_node() {
        return beowulf_node;
    }

    public boolean isBeowulf_crawler_enable() {
        return beowulf_crawler_enable;
    }

    public String getAllow_origin_domains() {
        return allow_origin_domains;
    }

    public String getBeowulf_csv_filepath() {
        return beowulf_csv_filepath;
    }
}
