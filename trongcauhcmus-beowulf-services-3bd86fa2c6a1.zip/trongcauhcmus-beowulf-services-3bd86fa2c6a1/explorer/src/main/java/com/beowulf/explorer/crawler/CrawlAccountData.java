package com.beowulf.explorer.crawler;

import com.beowulf.constants.BeowulfConstant;
import com.beowulf.constants.TypeAuthConstant;
import com.beowulf.explorer.config.AppConfig;
import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.BeowulfAuthReferences;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.operations.AccountUpdateData;
import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulf.explorer.repository.*;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.LoggerUtil;
import com.beowulfchain.beowulfj.enums.OperationType;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.plugins.apis.condenser.models.ExtendedAccount;
import com.beowulfchain.beowulfj.plugins.apis.database.models.DynamicGlobalProperty;
import com.beowulfchain.beowulfj.protocol.AccountName;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.mongodb.MongoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service(value = "crawlAccountData")
public class CrawlAccountData extends CrawlerThread {

    @Autowired
    private BeowulfAccountRepository beowulfAccountRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Autowired
    private BeowulfTokenHolderRepository beowulfTokenHolderRepository;

    @Autowired
    private BeowulfTokenRepository beowulfTokenRepository;

    @Autowired
    private BeowulfAuthReferencesRepository beowulfAuthReferencesRepository;

    private final Logger logger = LoggerFactory.getLogger(CrawlAccountData.class);

    private final static int limit = 50;
    private boolean isProcessingCurrentSupply = false;
    private boolean isProcessingAccountId = false;


    private static void doSleep() {
        doSleep(60000);
    }

    private static void doSleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public long onDestroy() {
        int i = 0;
        while (isProcessingCurrentSupply | isProcessingAccountId) {
            System.out.println((i + 1) + "s");
            i++;
            doSleep(1000);
        }
        LoggerUtil.w("Account", "Service shutdown completed!");
        return 0;
    }

    /**
     * Synchronize balance for token holder from Beowulf Network when have new Operation related with Token.
     *
     * @param account The account name of holder.
     * @param token   The asset symbol.
     */
    void syncTokenHolderBalance(String account, String token) {
        AccountName accountName = new AccountName(account);
        try {
            List<ExtendedAccount> accountDetails = BeowulfCommunicate.getBeowulfJ().getAccounts(Collections.singletonList(accountName));
            if (accountDetails != null) {
                if (token.equals(BeowulfConstant.BWF_ASSET_SYMBOL)) {
                    findAndUpdateTokenHolder(account, accountDetails.get(0).getBalance());
                } else if (token.equals(BeowulfConstant.W_ASSET_SYMBOL)) {
                    findAndUpdateTokenHolder(account, accountDetails.get(0).getWdBalance());
                } else {
                    List<Asset> accountBalances = accountDetails.get(0).getTokenList();
                    accountBalances.stream()
                            .filter(asset -> token.equals(asset.getName()))
                            .findAny().ifPresent(
                            asset -> findAndUpdateTokenHolder(account, asset)
                    );
                }
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token Holder] - Can not get data of account from Beowulf Network");
        } catch (NullPointerException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token Holder] - Account {} is invalid in Beowulf Network", account);
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token Holder] - Cannot get and update data of Token holder: {}", account);
            e.printStackTrace();
        }
    }

    /**
     * Update document Token holder in Repository.
     *
     * @param holder       The account name of holder.
     * @param tokenBalance The new token balance of holder.
     */
    private void findAndUpdateTokenHolder(String holder, Asset tokenBalance) {
        try {
            if (this.beowulfTokenHolderRepository.updateBalanceTokenHolder(holder, tokenBalance)) {
                this.logger.info("==> EXPLORER: " +
                        "[Crawling Token Holder] - Handle Update token {} balance of {} SUCCESSFULLY", tokenBalance.getName(), holder);
            }
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token Holder] - <Mongo> Cannot update Token holder {}", holder);
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token Holder] - Cannot get and update data of Token holder: {}", holder);
            e.printStackTrace();
        }
    }

    @Scheduled(initialDelay = 1000, fixedDelay = 10000)
    private void updateCurrentSupply() {
        if (!AppConfig.isAlive()) return;
        try {
            this.isProcessingCurrentSupply = true;
            DynamicGlobalProperty properties = BeowulfCommunicate.getBeowulfJ().getDynamicGlobalProperties();
            Asset currentSupply = properties.getCurrentSupply();
            Asset currentWSupply = properties.getCurrentWdSupply();
            if (this.beowulfTokenRepository.updateNativeSupply(BeowulfConstant.BWF_ASSET_SYMBOL, currentSupply)) {
                this.logger.info("==> EXPLORER: " +
                        "[Crawling Token] - Handle Update current supply BWF SUCCESSFULLY");
            }
            if (this.beowulfTokenRepository.updateNativeSupply(BeowulfConstant.W_ASSET_SYMBOL, currentWSupply)) {
                this.logger.info("==> EXPLORER: " +
                        "[Crawling Token] - Handle Update current supply W SUCCESSFULLY");
            }
        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - Can not get data current supply from Beowulf Network");
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - <Mongo> Cannot update Token BWF");
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Token] - Cannot get and update data of Token BWF");
            e.printStackTrace();
        } finally {
            this.isProcessingCurrentSupply = false;
        }
    }

    @Scheduled(initialDelay = 1000, fixedDelay = 1000)
    private void updateAccountId() {
        if (!AppConfig.isAlive()) return;
        try {
            this.isProcessingAccountId = true;
            int i = 0;
            while (i < 20 && AppConfig.isAlive()) {
                logger.debug("Update beowulf account");
                List<BeowulfAccount> beowulfAccounts = beowulfAccountRepository.findAccountID(0, limit);
                if (beowulfAccounts.isEmpty()) break;

                List<AccountName> accountNames = beowulfAccounts.stream().map(beowulfAccount -> new AccountName(beowulfAccount.getName())).collect(Collectors.toList());
                List<ExtendedAccount> extendedAccounts = BeowulfCommunicate.getBeowulfJ().getAccounts(accountNames);
                for (ExtendedAccount extendedAccount : extendedAccounts) {
                    beowulfAccountRepository.updateAccountId(extendedAccount.getName().getName(), extendedAccount.getId());
                }
                beowulfAccounts.clear();
                accountNames.clear();
                extendedAccounts.clear();
                i++;
            }
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Update Account Data] - Can not get data of from Beowulf Network");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.isProcessingAccountId = false;
        }
    }

    @PostConstruct
    public void updateOldAccountUpdateOperation() {
        try {
            List<BeowulfOperation> operations = this.beowulfOperationRepository.findBeowulfOperationsByType(OperationType.ACCOUNT_UPDATE_OPERATION);
            for (BeowulfOperation operation : operations) {
                updateAccountInfo((AccountUpdateData) operation.getOperation());
            }
            LoggerUtil.w(this.getName(), "Beowulf Account Update re-update SUCCESSFULLY");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Update document Account in Repository.
     *
     * @param operation The operation update account.
     */
    void updateAccountInfo(AccountUpdateData operation) {
        try {
            String accountName = operation.getAccount();
            BeowulfAccount account = this.beowulfAccountRepository.findAccountByName(accountName);

            if (account != null) {
                // Remove old keys & accounts reference
                removeOldAccountReferences(account.getPermissions(), accountName);
                // Update new account info
                if (this.beowulfAccountRepository.updateAccountInfo(operation)) {
                    // Insert new key & account reference documents
                    insertNewAccountReferences(operation.getOwner(), accountName);
                    this.logger.info("==> EXPLORER: " +
                            "[Crawling Account Update] - Handle Update account {} SUCCESSFULLY", accountName);
                }
            }
        } catch (MongoException e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account Update] - <Mongo> Cannot update Account info {}", operation.getAccount());
        } catch (Exception e) {
            this.logger.error("==> EXPLORER: " +
                    "[Crawling Account Update] - Cannot get and update data of Account: {}", operation.getAccount());
            e.printStackTrace();
        }
    }

    private void removeOldAccountReferences(AuthorityData authorityData, String accountName) {
        Map<String, Integer> mapAccount = authorityData.getAccountAuths();
        for (Map.Entry<String, Integer> entry : mapAccount.entrySet()) {
            this.beowulfAuthReferencesRepository.removeOldAccountReference(entry.getKey(), accountName);
        }
        Map<String, Integer> mapKey = authorityData.getKeyAuths();
        for (Map.Entry<String, Integer> entry : mapKey.entrySet()) {
            this.beowulfAuthReferencesRepository.removeOldAccountReference(entry.getKey(), accountName);
        }
    }

    private void insertNewAccountReferences(AuthorityData authorityData, String accountName) {
        Map<String, Integer> mapAccount = authorityData.getAccountAuths();
        for (Map.Entry<String, Integer> entry : mapAccount.entrySet()) {
            beowulfAuthReferencesRepository.save(new BeowulfAuthReferences(entry.getKey(), entry.getValue(), accountName, TypeAuthConstant.ACCOUNT));
        }
        Map<String, Integer> mapKey = authorityData.getKeyAuths();
        for (Map.Entry<String, Integer> entry : mapKey.entrySet()) {
            beowulfAuthReferencesRepository.save(new BeowulfAuthReferences(entry.getKey(), entry.getValue(), accountName, TypeAuthConstant.KEY));
        }
    }
}
