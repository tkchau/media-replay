package com.beowulf.explorer.services.impl;

import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.services.SupernodeService;
import com.beowulf.model.response.SupernodeDetailResponse;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.RedisUtils;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class SupernodeServiceImpl implements SupernodeService {

    private final Logger logger = LoggerFactory.getLogger(SupernodeService.class);

    @Override
    public SupernodeDetailResponse getSupernodeDetailByName(String supernodeName) throws ServiceException {
        this.logger.info("==> EXPLORER: " +
                "Get supernode detail for account name: {}", supernodeName);
        String data = RedisUtils.get(Constant.SUPERNODE_CACHE_PRE_FIX + supernodeName);
        if (!StringUtils.hasText(data)) {
            throw ServiceExceptionUtils.supernodeNotFound(supernodeName);
        }
        return GsonSingleton.getInstance().fromJson(data, SupernodeDetailResponse.class);
    }

    @Override
    public List<SupernodeDetailResponse> getSupernodeList() throws ServiceException {
        this.logger.info("==> EXPLORER: " +
                "Get super-node list ");
        List<SupernodeDetailResponse> detailResponses = new ArrayList<>();
        Set<String> cachedSupernodeNames = RedisUtils.getAllKey(Constant.SUPERNODE_CACHE_PRE_FIX);
        Gson gson = GsonSingleton.getInstance();
        if (cachedSupernodeNames != null) {
            for (String supernodeName : cachedSupernodeNames) {
                if (StringUtils.hasText(supernodeName)) {
                    String data = RedisUtils.get(supernodeName);
                    if (StringUtils.hasText(data)) {
                        SupernodeDetailResponse supernodeDetailResponse = gson.fromJson(data, SupernodeDetailResponse.class);
                        detailResponses.add(supernodeDetailResponse);
                    }
                }
            }
        }
        return detailResponses;
    }
}
