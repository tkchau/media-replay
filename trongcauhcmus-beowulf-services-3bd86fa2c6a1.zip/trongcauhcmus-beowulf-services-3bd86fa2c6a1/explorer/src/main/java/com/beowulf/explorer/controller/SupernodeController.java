package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.BlockService;
import com.beowulf.explorer.services.SupernodeService;
import com.beowulf.model.request.ListBlockProducedBySupernodePagingRequest;
import com.beowulf.model.response.BlockDetailResponse;
import com.beowulf.model.response.SupernodeDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "v1/supernode", produces = "application/json; charset=UTF-8")
public class SupernodeController {

	@Autowired
	private SupernodeService supernodeService;

	@Autowired
	private BlockService blockService;

	@RequestMapping(value = "/name/{name}", method = RequestMethod.GET)
	public SupernodeDetailResponse getSupernodeDetail(@PathVariable("name") String supernodeName) {
		return supernodeService.getSupernodeDetailByName(supernodeName);
	}

	@RequestMapping(value = "/block", method = RequestMethod.POST)
	public List<BlockDetailResponse> getListBlockProducedBySupernode(@RequestBody ListBlockProducedBySupernodePagingRequest request) {
		return blockService.getListBlockProducedBySupernode(request);
	}
//
//	@RequestMapping(value = "/transactions", method = RequestMethod.POST)
//	public Object getTransactionBelongToSupernode(@RequestBody GetSupernodeTransactionRequest request) {
//		return supernodeService.getSuperNodeTransaction(request);
//	}
//
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<SupernodeDetailResponse> getSupernodeList() {
		return supernodeService.getSupernodeList();
	}
}
