package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.TransactionService;
import com.beowulf.model.request.ListTransactionPagingRequest;
import com.beowulf.model.request.ListTransactionsBlockIdPagingRequest;
import com.beowulf.model.response.TransactionDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value = "v1/transaction", produces = "application/json; charset=UTF-8")
@Validated
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	@RequestMapping(value = "/count", method = RequestMethod.GET)
	public long countTotalTransaction() {
		return transactionService.getTotalTransaction();
	}

	@RequestMapping(value = "/block_id/{block_id}", method = RequestMethod.GET)
    public List<TransactionDetailResponse> getTransactionListByBlockId(@PathVariable("block_id") String blockId) {
		return transactionService.getTransactionListByBlockId(blockId);
	}

    @RequestMapping(value = "paging/block_id", method = RequestMethod.POST)
    public List<TransactionDetailResponse> getTransactionListPagingByBlockId(@Valid @RequestBody ListTransactionsBlockIdPagingRequest request) {
        return transactionService.getTransactionListPagingByBlockId(request);
    }

	@RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
	public TransactionDetailResponse getTransactionDetail(@PathVariable(name = "id") String transactionId) {
		return transactionService.getTransactionDetail(transactionId);
	}

	@RequestMapping(value = "/paging", method = RequestMethod.POST)
	public List<TransactionDetailResponse> getTransactionListByObjectId(@RequestBody ListTransactionPagingRequest request) {
		return transactionService.getTransactionListByPaging(request);
	}
}
