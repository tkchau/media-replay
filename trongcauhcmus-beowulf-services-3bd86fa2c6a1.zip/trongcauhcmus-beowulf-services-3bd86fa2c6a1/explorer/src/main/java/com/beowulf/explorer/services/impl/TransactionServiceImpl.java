
package com.beowulf.explorer.services.impl;

import com.beowulf.constants.Constant;
import com.beowulf.exception.ServiceException;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.BeowulfOperationRepository;
import com.beowulf.explorer.repository.BeowulfTransactionRepository;
import com.beowulf.explorer.services.TransactionService;
import com.beowulf.model.request.ListTransactionPagingRequest;
import com.beowulf.model.request.ListTransactionsBlockIdPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import com.beowulf.model.response.TransactionDetailResponse;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class TransactionServiceImpl implements TransactionService {

    private Logger logger = LoggerFactory.getLogger(TransactionService.class);

    @Autowired
    private BeowulfTransactionRepository beowulfTransactionRepository;

    @Autowired
    private BeowulfOperationRepository beowulfOperationRepository;

    @Override
    public long getTotalTransaction() throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request total transactions");
        return beowulfTransactionRepository.count();
    }

    @Override
    public List<TransactionDetailResponse> getTransactionListByBlockId(String blockId) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request list detail transactions with block id: " + blockId);
        List<TransactionDetailResponse> responses = new ArrayList<>();
        List<BeowulfTransaction> transactions = beowulfTransactionRepository.findByBlock_id(blockId);
        if (transactions == null || transactions.isEmpty()) {
            return responses;
        } else {
            for (BeowulfTransaction transaction : transactions) {
                TransactionDetailResponse response = getTransactionDetail(transaction.getTransaction_id());
                responses.add(response);
            }
        }
        return responses;
    }

    @Override
    public TransactionDetailResponse getTransactionDetail(String transactionId) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request detail transaction with id: " + transactionId);
        BeowulfTransaction beowulfTransaction = beowulfTransactionRepository.findByTransactionId(transactionId);
        if (beowulfTransaction == null) {
            throw ServiceExceptionUtils.transactionNotFound(transactionId);
        }
        List<BeowulfOperation> beowulfOperations = beowulfOperationRepository.findBeowulfOperationByTransactionId(transactionId);
        List<String> operationIds = new ArrayList<>();
        List<OperationDetailResponse> operationDetailResponses = new ArrayList<>();
        for (BeowulfOperation operation : beowulfOperations) {
            operationIds.add(operation.getOperation_id());
            operationDetailResponses.add(new OperationDetailResponse(operation));
        }
        return new TransactionDetailResponse(beowulfTransaction, operationIds, operationDetailResponses);
    }

    @Override
    public List<TransactionDetailResponse> getTransactionListByPaging(ListTransactionPagingRequest request) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request list detail transactions with data: " + GsonSingleton.getInstance().toJson(request));
        ObjectId startId = Common.makeStableObjectIdRequest(request.getStart_id());
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());

        List<BeowulfTransaction> transactions = beowulfTransactionRepository.getTransactionPaging(startId, limit, direction);
        List<TransactionDetailResponse> responses = getListTransactionDetailResponse(transactions);

        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (startId != null)) {
            Collections.reverse(responses);
        }
        return responses;
    }

    @Override
    public List<TransactionDetailResponse> getTransactionListPagingByBlockId(ListTransactionsBlockIdPagingRequest request) throws ServiceException {
        logger.info("==> EXPLORER: " +
                "Request list detail transactions of block with data: " + GsonSingleton.getInstance().toJson(request));

        int position = request.getPosition();
        int limit = Common.makeStableLimitation(request.getLimit());
        String direction = Common.handleDirectionRequest(request.getDirection());
        String blockId = request.getBlock_id();

        List<BeowulfTransaction> transactions = beowulfTransactionRepository.getTransactionPagingByBlockId(blockId, position, limit, direction);
        List<TransactionDetailResponse> responses = getListTransactionDetailResponse(transactions);

        if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) && (position > 0)) {
            Collections.reverse(responses);
        }
        return responses;
    }

    private List<TransactionDetailResponse> getListTransactionDetailResponse(List<BeowulfTransaction> transactions) {
        List<TransactionDetailResponse> responses = new ArrayList<>();

        for (BeowulfTransaction transaction : transactions) {
            List<BeowulfOperation> operations = beowulfOperationRepository.findBeowulfOperationByTransactionId(transaction.getTransaction_id());
            List<String> operationIds = new ArrayList<>();
            List<OperationDetailResponse> operationDetailResponses = new ArrayList<>();
            for (BeowulfOperation operation : operations) {
                operationIds.add(operation.getOperation_id());
                operationDetailResponses.add(new OperationDetailResponse(operation));
            }
            TransactionDetailResponse response = new TransactionDetailResponse(transaction, operationIds, operationDetailResponses);
            responses.add(response);
        }
        return responses;
    }
}

