package com.beowulf.explorer.crawler;

public abstract class CrawlerThread extends Thread {
    public abstract long onDestroy();
}
