package com.beowulf.explorer.filter;

import com.beowulf.explorer.config.BeowulfExplorerServiceConfig;
import com.beowulf.filter.CrossOriginResourceFilter;

/**
 * Servlet Filter implementation class CrossOriginResourceFilter
 */
public class ExplorerCrossOriginResourceFilter extends CrossOriginResourceFilter {
    private static final String TAG = ExplorerCrossOriginResourceFilter.class.getName();

    public ExplorerCrossOriginResourceFilter() {
        super();
    }

    @Override
    public boolean validateOrigin(String origin) {
        String cors = BeowulfExplorerServiceConfig.getInstance().getAllow_origin_domains();
        return origin.endsWith(cors) || origin.endsWith("localhost:8080");
    }
}
