package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.AccountDetailService;
import com.beowulf.model.request.ListBeowulfAccountPagingRequest;
import com.beowulf.model.request.ListCreatedAccountPagingRequest;
import com.beowulf.model.response.AccountDetailResponse;
import com.beowulf.model.response.BeowulfAccountResponse;
import com.beowulf.model.response.CreatedAccountResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "v1/account", produces = "application/json; charset=UTF-8")
public class AccountController {

    @Autowired
    private AccountDetailService accountDetailService;

    @RequestMapping(value = "/name/{name}", method = RequestMethod.GET)
    public AccountDetailResponse getAccountDetailByName(@PathVariable("name") String accountName) throws Exception {
        return accountDetailService.getAccountDetailByName(accountName);
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public long getTotalAccountInData() {
        return accountDetailService.getTotalAccountInData();
    }

    @RequestMapping(value = "/created", method = RequestMethod.POST)
    public List<CreatedAccountResponse> listCreatedAccount(@RequestBody ListCreatedAccountPagingRequest listCreatedAccountPagingRequest) {
        return accountDetailService.listCreatedAccount(listCreatedAccountPagingRequest);
    }

    @RequestMapping(value = "/paging", method = RequestMethod.POST)
    public List<BeowulfAccountResponse> listAccountByPaging(@RequestBody ListBeowulfAccountPagingRequest request) {
        return accountDetailService.listAccountByPaging(request);
    }

    @RequestMapping(value = "/references/{name}", method = RequestMethod.GET)
    public List<String> listAccountReferences(@PathVariable("name") String accountName) {
        return accountDetailService.listAccountReferences(accountName);
    }

    @RequestMapping(value = "/references/key/{key}", method = RequestMethod.GET)
    public List<String> listKeyReferences(@PathVariable("key") String key) {
        return accountDetailService.listKeyReferences(key);
    }

    @RequestMapping(value = "/multisig/{name}", method = RequestMethod.GET)
    public boolean checkAccountMultisig(@PathVariable("name") String accountName) {
        return accountDetailService.checkAccountMultisig(accountName);
    }

    @RequestMapping(value = "/multisig", method = RequestMethod.POST)
    public List<BeowulfAccountResponse> getAccountsMultisig(@RequestBody ListBeowulfAccountPagingRequest request) {
        return accountDetailService.getAccountsMultisig(request);
    }

}
