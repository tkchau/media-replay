package com.beowulf.explorer.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.request.ListTransactionPagingRequest;
import com.beowulf.model.request.ListTransactionsBlockIdPagingRequest;
import com.beowulf.model.response.TransactionDetailResponse;

import java.util.List;

public interface TransactionService {

    long getTotalTransaction() throws ServiceException;

    List<TransactionDetailResponse> getTransactionListByBlockId(String blockId) throws ServiceException;

    TransactionDetailResponse getTransactionDetail(String transactionId) throws ServiceException;

    List<TransactionDetailResponse> getTransactionListByPaging(ListTransactionPagingRequest request) throws ServiceException;

    List<TransactionDetailResponse> getTransactionListPagingByBlockId(ListTransactionsBlockIdPagingRequest request) throws ServiceException;
}
