package com.beowulf.explorer.controller;

import com.beowulf.explorer.services.AssetService;
import com.beowulf.model.request.ListBeowulfOperationByAssetPagingRequest;
import com.beowulf.model.request.ListTokenPagingRequest;
import com.beowulf.model.response.OperationDetailResponse;
import com.beowulf.model.response.TokenDetailResponse;
import com.beowulf.model.response.TokenHolderDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "v1/asset", produces = "application/json; charset=UTF-8")
public class AssetController {

    @Autowired
    private AssetService assetService;

    @RequestMapping(value = "/transfer", method = RequestMethod.POST)
    public List<OperationDetailResponse> getTransferOperationByCurrencyCode(
            @RequestBody ListBeowulfOperationByAssetPagingRequest request) {
        return assetService.getListTransferOperationByCurrencyCode(request);
    }

    @RequestMapping(value = "/paging", method = RequestMethod.POST)
    public List<TokenDetailResponse> getListToken(@RequestBody ListTokenPagingRequest request) {
        return assetService.getListTokenByPaging(request);
    }

    @RequestMapping(value = "/{asset}/holder/count", method = RequestMethod.GET)
    public long getTotalTokenHolders(@PathVariable("asset") String token) {
        return assetService.getTotalTokenHolders(token);
    }

    @RequestMapping(value = "/account/control/{token}", method = RequestMethod.GET)
    public TokenHolderDetailResponse getAccountControl(@PathVariable("token") String token) {
        return assetService.getAccountControl(token);
    }

    @RequestMapping(value = "/{asset}/top/{limit}", method = RequestMethod.GET)
    public List<TokenHolderDetailResponse> getTopTokenHolders(@PathVariable("asset") String token, @PathVariable("limit") int limit) {
        return assetService.getTopTokenHolders(token, limit);
    }

    @RequestMapping(value = "/name/{name}", method = RequestMethod.GET)
    public TokenDetailResponse getTokenDetail(@PathVariable("name") String name) {
        return assetService.getTokenDetail(name);
    }

    @RequestMapping(value = "/total", method = RequestMethod.GET)
    public int getTotalToken() {
        return assetService.getTotalToken();
    }
}
