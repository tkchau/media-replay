package com.beowulf.hook.services;

import com.beowulf.handler.communication.HttpHandler;
import com.beowulf.hook.config.BeowulfHookServiceConfig;
import com.beowulf.hook.document.Action;
import com.beowulf.hook.document.BeowulfAccountWebhook;
import com.beowulf.hook.document.BeowulfTransactionReceipt;
import com.beowulf.hook.document.NodeInfo;
import com.beowulf.hook.repository.BeowulfAccountWebhookRepository;
import com.beowulf.hook.repository.BeowulfHookHistoryRepository;
import com.beowulf.hook.repository.HookActionRepository;
import com.beowulf.hook.repository.NodeInfoRepository;
import com.beowulf.hook.repository.extend.HookPendingRepositoryExtend;
import com.beowulf.model.BlockchainType;
import com.beowulf.model.response.HttpResponseObject;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.base.models.Block;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.operations.Operation;
import com.beowulfchain.beowulfj.protocol.operations.TransferOperation;
import com.mongodb.MongoSocketOpenException;
import com.mongodb.MongoWriteException;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import java.io.InvalidObjectException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author tatrongcau
 * @project beowulf-services
 * @time 2019-09-24
 */

@Component
@Scope(value = "prototype")
public class BeowulfTransactionDetector extends Thread {
    private final Logger logger = LoggerFactory.getLogger(BeowulfTransactionDetector.class);

    private int confirmation;
    private long currentBlock;
    private String node_url;
    private HashMap<Pair<String, String>, BeowulfTransactionReceipt> txnMap;
    private BeowulfJ beowulfJ;

    @Autowired
    TokenMapping tokenMapping;

    @Autowired
    NodeInfoRepository nodeInfoRepository;

    @Autowired
    BeowulfAccountWebhookRepository beowulfAccountWebhookRepository;

    @Autowired
    HookActionRepository hookActionRepository;

    @Autowired
    BeowulfHookHistoryRepository beowulfHookHistoryRepository;

    @Autowired
    HookPendingRepositoryExtend hookPendingRepositoryExtend;

    public void init(int confirmation) throws BeowulfCommunicationException, BeowulfResponseException {
        this.confirmation = confirmation;
        this.node_url = BeowulfHookServiceConfig.getInstance().getBeowulf_node();
        beowulfJ = BeowulfCommunicate.init(node_url);

        long startBlock = BeowulfHookServiceConfig.getInstance().getBeowulf_startblock();
        currentBlock = getLastSync(startBlock) - confirmation;
        txnMap = new HashMap<>();
    }

    private long getLastSync(long startBlock) {
        NodeInfo nodeInfo = nodeInfoRepository.findNodeInfoByNode_url(node_url);
        if (nodeInfo == null) {
            nodeInfo = new NodeInfo();
            nodeInfo.setNode_url(this.node_url);
            nodeInfo.setLast_sync(startBlock);
            nodeInfo.setType(BlockchainType.BWF.name());
            nodeInfoRepository.save(nodeInfo);
            return startBlock;
        } else {
            long last_sync = nodeInfo.getLast_sync();
            if (last_sync > startBlock) {
                return last_sync;
            } else {
                return startBlock;
            }
        }
    }

    private void updateLastSync(long blockNumber) {
        try {
            nodeInfoRepository.updateLastSync(this.node_url, blockNumber);
        } catch (MongoSocketOpenException e) {
            System.out.println("BWF == Can not open connection to mongodb to update last sync");
            e.printStackTrace();
        }
    }

    private static void sleep() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println(String.format("Start Beowulf Scanning with %s confirmations", this.confirmation));
        long highestBlock = currentBlock;
        while (true) {
            try {
                highestBlock = beowulfJ.getDynamicGlobalProperties().getHeadBlockNumber();
            } catch (BeowulfCommunicationException e) {
                e.printStackTrace();
                logger.error("Can not connect with beowulf node");
            } catch (BeowulfResponseException e) {
                e.printStackTrace();
                logger.error("Beowulf node response exception");
            }
            while (currentBlock <= highestBlock - confirmation) {
                try {
                    if (BeowulfHookServiceConfig.getInstance().getBeowulf_highestblock() < currentBlock) {
                        BeowulfHookServiceConfig.getInstance().setBeowulf_highestblock(currentBlock);
                    }
                    long start = System.currentTimeMillis();
                    handleBlock(currentBlock);
                    long end = System.currentTimeMillis();
                    logger.info((String.format("End scan confirmation %s block: %s == time execute: %sms == txns size: %s", confirmation, currentBlock, end - start, txnMap.size())));
                    fireHookData(txnMap);
                    currentBlock++;
                } catch (Exception e) {
                    logger.info("BWF == can not handle block, error occur: " + e.getMessage());
                } finally {
                    txnMap.clear();
                }
            }
            updateLastSync(highestBlock);
            sleep();
        }
    }

    private void handleBlock(long currentBlock) throws Exception {
        Block block = beowulfJ.getBlock(currentBlock);
        List<CompletedTransaction> transactions = block.getTransactions();
        for (int i = 0; i < transactions.size(); i++) {
            try {
                CompletedTransaction transaction = transactions.get(i);
                List<Operation> operations = transaction.getOperations();
                for (Operation operation :
                        operations) {
                    TransferOperation transferOperation;
                    if (operation instanceof TransferOperation) {
                        transferOperation = (TransferOperation) operation;
                    } else {
                        throw new InvalidObjectException("operation is not transfer");
                    }

                    String asset_txid = transferOperation.getAmount().getName() + transaction.getTransactionId().toString();
                    Pair<String, String> asset_txid_from = new Pair<>(asset_txid, transferOperation.getFrom().getName());
                    Pair<String, String> asset_txid_to = new Pair<>(asset_txid, transferOperation.getTo().getName());

                    BeowulfTransactionReceipt receiptFrom = new BeowulfTransactionReceipt(transferOperation.getFrom().getName(),
                            transaction.getTransactionId().toString(),
                            transferOperation.getAmount().getAmount(),
                            transferOperation.getAmount().getName(),
                            this.confirmation,
                            "out",
                            transferOperation.getMemo());
                    if (txnMap.get(asset_txid_from) != null) {
                        txnMap.get(asset_txid_from).mergeReceipt(receiptFrom);
                    } else {
                        txnMap.put(asset_txid_from, receiptFrom);
                    }

                    BeowulfTransactionReceipt receiptTo = new BeowulfTransactionReceipt(transferOperation.getTo().getName(),
                            transaction.getTransactionId().toString(),
                            transferOperation.getAmount().getAmount(),
                            transferOperation.getAmount().getName(),
                            this.confirmation,
                            "in",
                            transferOperation.getMemo());
                    if (txnMap.get(asset_txid_to) != null) {
                        txnMap.get(asset_txid_to).mergeReceipt(receiptTo);
                    } else {
                        txnMap.put(asset_txid_to, receiptTo);
                    }
                }


            } catch (Exception e) {
                logger.debug("transaction exception: " + e.getMessage());
            }
        }
    }


    /**
     * checking new transaction in map and calling hook if it is valid transaction
     *
     * @param txnMap transaction map
     */
    private void fireHookData(HashMap<Pair<String, String>, BeowulfTransactionReceipt> txnMap) {
        for (Pair<String, String> asset_txid_account : txnMap.keySet()) {
            BeowulfTransactionReceipt transactionReceipt = txnMap.get(asset_txid_account);
            BeowulfAccountWebhook beowulfAccount = beowulfAccountWebhookRepository.findBeowulfAccountWebhooksByAccount_name(transactionReceipt.getAccount());
            Action action = new Action();

            if (beowulfAccount != null && tokenMapping.isAllowed(transactionReceipt.getAsset())) {
                try {
                    transactionReceipt.setConfirmation(this.confirmation);

                    // add action hook avoid duplicate hook
                    action.setActionId(transactionReceipt.getActionId());
                    action.setCreateAt(new Date());
                    hookActionRepository.addNewAction(action);

                    // calling hook data
                    HttpResponseObject responseObject = HttpHandler.getInstance().doPost(transactionReceipt, HttpResponseObject.class, beowulfAccount.getUrl(), null);
                    beowulfHookHistoryRepository.save(transactionReceipt);
                    logger.warn(beowulfAccount.getAccount_name() + " ====> HOOKING: " + transactionReceipt.toString());
                } catch (DuplicateKeyException | MongoWriteException e) {
                    logger.info("hook by another bot");
                } catch (Exception e) {
                    transactionReceipt.setCall_times(1);
                    transactionReceipt.setLast_call(System.currentTimeMillis());
                    transactionReceipt.setUrl(beowulfAccount.getUrl());
                    hookPendingRepositoryExtend.save(transactionReceipt);
                    logger.error(beowulfAccount.getAccount_name() + " ====> CAN'T HOOKING: " + transactionReceipt.toString());
                }
            }
        }
    }
}
