/*
 * Copyright (c) 2018.
 * @author TrongCauTa - trongcauhcmus@gmail.com
 * @version 4/16/18 11:19 AM
 */

package com.beowulf.hook.services;

import com.beowulf.config.GeneralConfigProperties;
import com.beowulf.handler.communication.HttpHandler;
import com.beowulf.hook.document.Action;
import com.beowulf.hook.repository.HookActionRepository;
import com.beowulf.hook.repository.extend.HookPendingRepositoryExtend;
import com.beowulf.model.response.HttpResponseObject;
import com.beowulf.utilities.AmazonSESSender;
import com.beowulf.utilities.HttpUtility;
import com.beowulf.utilities.SHAUtils;
import com.mongodb.MongoWriteException;
import org.bson.Document;
import org.bson.json.JsonMode;
import org.bson.json.JsonWriterSettings;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;

/**
 * check every transaction in hook pending collection
 * call hook if it satisfy the call times,
 * if call times is over, it will send an email to admin and ignore.
 * admin have to check and delete
 */
@Component
@Scope("prototype")
public class HookPendingCallback extends Thread {

    private static final Logger logger = LoggerFactory.getLogger(HookPendingCallback.class);

    private static int[] delta = {60000, 60000, 120000, 180000, 300000, 480000, 0}; // {1, 1, 2, 3, 5, 8, 0}
    private static final int MAX_CALL_TIMES = 5;

    @Autowired
    HookPendingRepositoryExtend hookPendingRepositoryExtend;

    @Autowired
    HookActionRepository hookActionRepository;

    // sending callback data
    private static JsonWriterSettings writerSettings = JsonWriterSettings.builder()
            .outputMode(JsonMode.RELAXED)
            .indent(true)
            .objectIdConverter((id, w) -> w.writeString(id.toHexString()))
            .dateTimeConverter((date, w) -> w.writeString(String.valueOf(date)))
            .timestampConverter((t, w) -> w.writeString(t.toString()))
            .build();


    @Override
    public void run() {
        while (true) {
            try {
                List<Document> receipts = hookPendingRepositoryExtend.findValidHookingPending(null, 100);
                if (receipts.size() != 0) {
                    for (Document receipt : receipts) {
                        callWebhook(receipt);
                    }
                }
                sleep(60000);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public static void sendMail(String text) {
        logger.info(String.format("send mail for admin... content: %s", text));
        try {
            AmazonSESSender.sendEmailToAddress("Beowulf Hooking Failed", text, GeneralConfigProperties.getInstance().getCompany_mail_admin());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void callWebhook(Document pending_txn) {

        int call_times = pending_txn.getInteger("call_times");
        long last_call = pending_txn.getLong("last_call");
        String url = pending_txn.getString("url");
        String req = pending_txn.toJson(writerSettings);

        if (verify(call_times, last_call, req, pending_txn.getObjectId("_id"))) return;

        try {
            // add action to avoid duplicate hook pending
            addCallbackAction(req);

            logger.warn("Hook to " + url + " with data: " + req);
            String response = HttpUtility.sendPost(url, req);
            HttpResponseObject responseObject = HttpHandler.getInstance().doPost(req, HttpResponseObject.class, url, null);
            // remove when calling hook success
            logger.warn(String.format("Callback pending data successfully: %s", req));
            hookPendingRepositoryExtend.removePendingTransactionById(pending_txn.getObjectId("_id"));
        } catch (DuplicateKeyException | MongoWriteException e) {
            logger.info("Hook by another worker with data: " + req);
        } catch (Exception e) {
            hookPendingRepositoryExtend.increaseCallTimes(pending_txn.getObjectId("_id"));
            logger.error(String.format("CALLBACK PENDING DATA FAILED: %s", req));
        }
    }

    private boolean verify(int call_times, long last_call, String req, ObjectId id) {
        // do not call recent pending transaction
        if (call_times > MAX_CALL_TIMES || System.currentTimeMillis() < last_call + delta[call_times]) {
            return true;
        }
        // expire after 5 times callback
        if (call_times == MAX_CALL_TIMES) {
            sendMail(req);
            hookPendingRepositoryExtend.increaseCallTimes(id);
            return true;
        }
        return false;
    }

    private void addCallbackAction(String message) throws DuplicateKeyException {
        try {
            Action action = new Action();
            action.setActionId(SHAUtils.sha1(message));
            action.setCreateAt(new Date());
            hookActionRepository.addNewAction(action);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }
}
