package com.beowulf.hook.config;

import com.beowulf.hook.services.BeowulfTransactionDetector;
import com.beowulf.hook.services.HookPendingCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    private final ApplicationContext applicationContext;

    @Autowired
    public AppConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Bean
    public BeowulfTransactionDetector beowulfDetector() {
        try {
            BeowulfTransactionDetector beowulfDetector = (BeowulfTransactionDetector) applicationContext.getBean("beowulfTransactionDetector");
            beowulfDetector.init(BeowulfHookServiceConfig.getInstance().getBeowulf_detected());
            beowulfDetector.start();
            return beowulfDetector;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Bean
    public HookPendingCallback hookPending() {
        try {
            HookPendingCallback hookPendingCallback = (HookPendingCallback) applicationContext.getBean("hookPendingCallback");
            hookPendingCallback.start();
            return hookPendingCallback;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
