package com.beowulf.hook.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class BeowulfHookServiceConfig {
    private static BeowulfHookServiceConfig appContext;

    // Secret declare
    private String crypto_aes_secretkey;
    private String crypto_aes_initVector;

    private String beowulf_node;
    private long beowulf_startblock;
    private int beowulf_detected;
    private long beowulf_highestblock;

    private BeowulfHookServiceConfig() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext();
        Properties properties = new Properties();
        try {

            String configFile = System.getProperty("hook_service");
            if (configFile == null) {
                configFile = "classpath:/hook-service.properties";
            }
            properties.load(appContext.getResource(configFile).getInputStream());

            crypto_aes_secretkey = properties.getProperty("crypto.aes.secretkey");
            crypto_aes_initVector = "1234567812345678";

            beowulf_node = properties.getProperty("beowulf.node");
            beowulf_startblock = Long.parseLong(properties.getProperty("beowulf.startblock"));
            beowulf_detected = Integer.parseInt(properties.getProperty("beowulf.detected"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static BeowulfHookServiceConfig getInstance() {
        if (appContext == null){
            appContext = new BeowulfHookServiceConfig();
        }
        return appContext;
    }

    public String getCrypto_aes_secretkey() {
        return crypto_aes_secretkey;
    }

    public String getCrypto_aes_initVector() {
        return crypto_aes_initVector;
    }

    public static BeowulfHookServiceConfig getAppContext() {
        return appContext;
    }

    public long getBeowulf_startblock() {
        return beowulf_startblock;
    }

    public int getBeowulf_detected() {
        return beowulf_detected;
    }

    public String getBeowulf_node() {
        return beowulf_node;
    }

    public long getBeowulf_highestblock() {
        return beowulf_highestblock;
    }

    public void setBeowulf_highestblock(long beowulf_highestblock) {
        this.beowulf_highestblock = beowulf_highestblock;
    }
}
