package com.beowulf.hook.controller;

import com.beowulf.exception.ServiceException;
import com.beowulf.hook.config.BeowulfHookServiceConfig;
import com.beowulf.hook.document.BeowulfAccountWebhook;
import com.beowulf.hook.document.NodeInfo;
import com.beowulf.hook.document.SmtTokenInfo;
import com.beowulf.hook.repository.BeowulfAccountWebhookRepository;
import com.beowulf.hook.repository.NodeInfoRepository;
import com.beowulf.hook.repository.SmtTokenInfoRepository;
import com.beowulf.model.BlockchainType;
import com.beowulf.model.request.BeowulfCreateWebhookRequest;
import com.beowulf.model.response.HookResponseStatus;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * @author tatrongcau
 * @project beowulf-services
 * @time 2019-09-24
 */
@Controller
@RequestMapping(value = "hook")
public class RestBeowulfWebhookController {
    @Autowired
    private BeowulfAccountWebhookRepository beowulfAccountWebhookRepository;

    @Autowired
    private NodeInfoRepository nodeInfoRepository;

    @Autowired
    private SmtTokenInfoRepository smtTokenInfoRepository;

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public HookResponseStatus addHook(@RequestBody BeowulfCreateWebhookRequest request) throws ServiceException {
        try {
            request.setAccount_name(request.getAccount_name().toLowerCase());
            BeowulfAccountWebhook ethAddress = new BeowulfAccountWebhook(request);
            beowulfAccountWebhookRepository.save(ethAddress);
            LoggerUtil.i(this, "Add new hook listener: " + request.getAccount_name());
            return new HookResponseStatus(true);
        } catch (DuplicateKeyException e) {
            throw ServiceExceptionUtils.accountExisted();
        }
    }

    @RequestMapping(value = "/remove", method = RequestMethod.POST)
    @ResponseBody
    public HookResponseStatus removeHook(@RequestBody BeowulfCreateWebhookRequest request) {
        request.setAccount_name(request.getAccount_name().toLowerCase());
        beowulfAccountWebhookRepository.removeByAccountName(request.getAccount_name());
        LoggerUtil.i("remove hook listener: {}", request.getAccount_name());
        return new HookResponseStatus(true);
    }

    @RequestMapping(value = "/callback/{id}", method = RequestMethod.POST)
    @ResponseBody
    public HookResponseStatus callback(@PathVariable("id") String address) {
        LoggerUtil.i(this, "New callback from: " + address);
        return new HookResponseStatus(true);
    }

    @RequestMapping(value = "/highestblock", method = RequestMethod.GET)
    @ResponseBody
    public String highestBlock() {
        long highestBlock = BeowulfHookServiceConfig.getInstance().getBeowulf_highestblock();
        return "{\"result\":" + highestBlock + "}";
    }

    @RequestMapping(value = "/highestserver", method = RequestMethod.GET)
    @ResponseBody
    public NodeInfo highestServer() {
        NodeInfo nodeInfo = nodeInfoRepository.getHighestNodeByType(BlockchainType.BWF.name());
        return nodeInfo;
    }

    @RequestMapping(value = "smt/add", method = RequestMethod.POST)
    @ResponseBody
    public HookResponseStatus addNewToken(@RequestBody SmtTokenInfo token) {
        token.setToken_symbol(token.getToken_symbol().toLowerCase());
        smtTokenInfoRepository.save(token);
        LoggerUtil.i(this, "Add new token: " + token.getToken_symbol());
        return new HookResponseStatus(true);
    }
}
