package com.beowulf.hook.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "")
public class UpController {

    @RequestMapping(value = "/up", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public Object hello(HttpServletRequest request) {
        return "up";
    }
}
