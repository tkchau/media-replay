package com.beowulf.hook.services;


import com.beowulf.hook.document.SmtTokenInfo;
import com.beowulf.hook.repository.SmtTokenInfoRepository;
import com.beowulf.utilities.LoggerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;

@Service
@Configuration
@EnableScheduling
public class TokenMapping {

    @Autowired
    SmtTokenInfoRepository smtTokenInfoRepository;

    private HashMap<String, Boolean> smt;

    @PostConstruct
    public void onStartup() {
        smt = new HashMap<String, Boolean>();
        updateMap();
        System.out.println("Start get Smt token information");
        try {
            SmtTokenInfo bwf = new SmtTokenInfo();
            bwf.setToken_symbol("BWF");
            bwf.setDecimal(5);
            smtTokenInfoRepository.save(bwf);
            SmtTokenInfo w = new SmtTokenInfo();
            w.setToken_symbol("W");
            w.setDecimal(5);
            smtTokenInfoRepository.save(w);
            LoggerUtil.w(this, "Init token BWF and W to db: Added BWF and W token symbol to database");
        } catch (DuplicateKeyException e) {
            LoggerUtil.w(this, "Init token BWF and W to db: Object already inserted");
        }
    }

    @Scheduled(initialDelay = 30000, fixedDelay = 300000)
    public void updateMap() {
        smt.clear();
        List<SmtTokenInfo> smtTokenInfos = smtTokenInfoRepository.findAll();
        for (SmtTokenInfo smtTokenInfo : smtTokenInfos) {
            smt.put(smtTokenInfo.getToken_symbol(), true);
        }
    }

    public boolean isAllowed(String smt_symbol) {
        try {
            if(smt == null){
                updateMap();
            }
            Boolean isAllow = smt.get(smt_symbol);
            return isAllow != null ? isAllow : false;
        } catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
