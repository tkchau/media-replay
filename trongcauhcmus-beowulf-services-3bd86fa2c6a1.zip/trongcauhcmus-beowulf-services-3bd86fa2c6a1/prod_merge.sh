#!/bin/bash

git checkout dev
git pull origin dev --no-edit
git push origin dev

git checkout staging
git pull origin dev --no-edit
git push origin staging

git checkout prod
git pull origin staging --no-edit
git push origin prod

git checkout dev