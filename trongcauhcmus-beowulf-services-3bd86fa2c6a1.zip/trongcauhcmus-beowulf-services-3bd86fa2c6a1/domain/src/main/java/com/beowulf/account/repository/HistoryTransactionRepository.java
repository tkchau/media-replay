package com.beowulf.account.repository;

import com.beowulf.account.documents.TransactionHistory;
import com.beowulf.account.repository.extend.HistoryTransactionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface HistoryTransactionRepository extends MongoRepository<TransactionHistory, ObjectId>, HistoryTransactionRepositoryExtend {

    @Query(value = "{'hash':?0}")
    TransactionHistory findHistoryTransactionByHash(String hash);
}
