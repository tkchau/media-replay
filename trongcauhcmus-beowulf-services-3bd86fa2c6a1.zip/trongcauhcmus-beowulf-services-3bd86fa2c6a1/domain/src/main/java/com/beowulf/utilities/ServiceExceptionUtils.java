package com.beowulf.utilities;

import com.beowulf.exception.CrawlingException;
import com.beowulf.exception.ServiceException;
import org.springframework.http.HttpStatus;

public class ServiceExceptionUtils {

    /**
     * 400 zone
     */
    // Define error for 400 here
    private static final String error_INVALID_JSON = "400001";
    private static final String desc_INVALID_JSON = "Invalid Json format";

    private static final String error_INVALID_REQUEST_PARAM = "400002";
    private static final String desc_error_INVALID_REQUEST_PARAM = "";

    private static final String error_TOO_MANY_REQUEST_AIRDROP = "400003";
    private static final String desc_error_TOO_MANY_REQUEST_AIRDROP = "try again after 1 day";

    /** End 400 zone **/

    /**
     * 401 zone
     */
    // Define error for 401 here
    private static final String error_UNAUTHORIZTION = "401001";
    private static final String desc_UNAUTHORIZTION = "Invalid authorization";
    /** End 401 zone **/

    /**
     *  403
     */
    private static final String error_ACCESS_DENIED = "403001";
    private static final String desc_ACCESS_DENIED = "access denied";

    /**
     * 404 zone
     */
    // Define error for 404 here
    private static final String error_ADDRESS_NOT_FOUND = "404001";
    private static final String desc_error_ADDRESS_NOT_FOUND = "Address not found";

    private static final String error_WALLET_NOT_FOUND = "404002";
    private static final String desc_error_WALLET_NOT_FOUND = "Wallet not found";

    private static final String error_LEVEL_NOT_FOUND = "404003";
    private static final String desc_error_LEVEL_NOT_FOUND = "Level not found";

    private static final String error_ACCOUNT_NOT_FOUND = "404004";
    private static final String desc_error_ACCOUNT_NOT_FOUND = "Account not found";

    private static final String error_BLOCK_NOT_FOUND = "404005";
    private static final String desc_error_BLOCK_NOT_FOUND = "Block %s not found";

    private static final String error_BLOCK_ID_NOT_FOUND = "404006";
    private static final String desc_error_BLOCK_ID_NOT_FOUND = "Block id %s not found";

    private static final String error_TRANSACTION_NOT_FOUND = "404007";
    private static final String desc_error_TRANSACTION_NOT_FOUND = "transaction %s not found";

    private static final String error_OPERATION_NOT_FOUND = "404008";
    private static final String desc_error_OPERATION_NOT_FOUND = "operation id %s not found";

    private static final String error_SUPERNODE_NOT_FOUND = "404009";
    private static final String desc_error_SUPERNODE_NOT_FOUND = "supernode %s not found";

    private static final String error_CERT_NOT_FOUND = "404010";
    private static final String desc_error_CERT_NOT_FOUND = "Certificate not found";

    /** End 404 zone **/

    /**
     * 406 zone, status: NOT_ACCEPTABLE
     */
    // Define error for 406 here
    private static final String error_NOT_ENOUGH_BALANCE = "406001";
    private static final String desc_error_NOT_ENOUGH_BALANCE = "not enough balance";

    private static final String error_INVALID_ADDRESS = "406002";
    private static final String desc_error_INVALID_ADDRESS = "invalid address";

    private static final String error_INVALID_VALUE = "406003";
    private static final String desc_error_INVALID_VALUE = "invalid value";

    private static final String error_API_KEY_TYPE_NOT_SUPPORTED = "406004";
    private static final String desc_error_API_KEY_TYPE_NOT_SUPPORTED = "Authorization type is not supported";

    private static final String error_API_KEY_IS_DISABLED = "406005";
    private static final String desc_error_API_KEY_IS_DISABLE = "api key is disabled";

    private static final String error_API_KEY_EXCEED_LIMIT= "406006";
    private static final String desc_error_API_KEY_EXCEED_LIMIT = "api key exceed limit";

    private static final String error_ACCOUNT_EXISTED= "406007";
    private static final String desc_error_ACCOUNT_EXISTED = "account already existed";

    private static final String error_ACCOUNT_NOT_EXISTED= "406008";
    private static final String desc_error_ACCOUNT_NOT_EXISTED = "account does not exist";


    /** End 406 zone **/

    /**
     * 409 zone, CONFLICT
     */
    // Define error for 409 here
    private static final String error_CONFLICT_NONCE_WHEN_CREATE_FORWADER = "409000";
    private static final String desc_error_CONFLICT_NONCE_WHEN_CREATE_FORWADER = "Error when create new forwarder because conflict request";

    private static final String error_CONFLICT_NONCE_WHEN_CREATE_WALLET = "409001";
    private static final String desc_error_CONFLICT_NONCE_WHEN_CREATE_WALLET = "Error when create new wallet because conflict request";

    private static final String error_CONFLICT_SEND_OUT_REQUEST = "409002";
    private static final String desc_error_CONFLICT_SEND_OUT_REQUEST = "conflict send out request because using the same sequenceId";

    private static final String error_API_KEY_ALREADY_EXISTED= "409003";
    private static final String desc_error_API_KEY_ALREADY_EXISTED = "apikey already existed";


    /** End 409 zone **/

    /**
     * 429 zone
     */
    // Define error for 429 here
    public static final String error_TOO_MANY_REQUEST = "429000";
    public static final String desc_error_TOO_MANY_REQUEST = "too many requests";

    /** End 429 zone **/

    /**
     * 500 zone, internal server error
     */
    // Define error for 500 here
    private static final String INTERNAL_SERVER_error = "500000";
    private static final String desc_INTERNAL_SERVER_error = "Error while processing request";

    private static final String error_REQUEST_TO_BEOWULF_NETWORK = "500001";
    private static final String desc_error_REQUEST_TO_BEOWULF_NETWORK = "Error while processing request to BEOWULF network: ";

    private static final String error_TRANSACTION_SEND_TO_NETWORK = "500002";
    private static final String desc_error_TRANSACTION_SEND_TO_NETWORK = "Transaction send to network error repsonse";

    /**
     * End 500 zone
     **/

    /** End 406 zone **/


    /**
     * 410 zone, CRAWLER ERROR
     */
    // Define error for 410 here
    private static final String error_EXISTED_ACTION_DOCUMENT = "410000";
    private static final String desc_error_EXISTED_ACTION_DOCUMENT = "Action crawling already existed";

    private static final String error_WHEN_CREATE_BLOCK_DOCUMENT = "410001";
    private static final String desc_error_WHEN_CREATE_BLOCK_DOCUMENT = "Error when create new Block Document because of parsing Data";

    private static final String error_WHEN_CREATE_TRANSACTION_DOCUMENT = "410002";
    private static final String desc_error_WHEN_CREATE_TRANSACTION_DOCUMENT = "Error when create new Transaction Document because of parsing Data";

    private static final String error_WHEN_CREATE_OPERATION_DOCUMENT = "410003";
    private static final String desc_error_WHEN_CREATE_OPERATION_DOCUMENT = "Error when create new Operation Document because of parsing Data";

    private static final String error_WHEN_CREATE_ACCOUNT_DOCUMENT = "410004";
    private static final String desc_error_WHEN_CREATE_ACCOUNT_DOCUMENT = "Error when create new Account Document because of parsing Data";

    private static final String error_EXISTED_BLOCK_DOCUMENT = "410005";
    private static final String desc_error_EXISTED_BLOCK_DOCUMENT = "Block crawling already existed";

    private static final String error_EXISTED_TRANSACTION_DOCUMENT = "410006";
    private static final String desc_error_EXISTED_TRANSACTION_DOCUMENT = "Transaction crawling already existed";

    private static final String error_EXISTED_OPERATION_DOCUMENT = "410007";
    private static final String desc_error_EXISTED_OPERATION_DOCUMENT = "Operation crawling already existed";

    private static final String error_EXISTED_ACCOUNT_DOCUMENT = "410008";
    private static final String desc_error_EXISTED_ACCOUNT_DOCUMENT = "Account crawling already existed";
    /** End 410 zone **/

    public static ServiceException invalidJSON() {
        return new ServiceException(error_INVALID_JSON, desc_INVALID_JSON, HttpStatus.BAD_REQUEST);
    }

    public static ServiceException addressNotFound() {
        return new ServiceException(error_ADDRESS_NOT_FOUND, desc_error_ADDRESS_NOT_FOUND, HttpStatus.NOT_FOUND);
    }


    public static ServiceException accountNotFound() {
        return new ServiceException(error_ACCOUNT_NOT_FOUND, desc_error_ACCOUNT_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    public static ServiceException blockNotFound(long blockNum) {
        return new ServiceException(error_BLOCK_NOT_FOUND, String.format(desc_error_BLOCK_NOT_FOUND, blockNum), HttpStatus.NOT_FOUND);
    }

    public static ServiceException blockNotFound(String blockId) {
        return new ServiceException(error_BLOCK_NOT_FOUND, String.format(desc_error_BLOCK_NOT_FOUND, blockId), HttpStatus.NOT_FOUND);
    }

    public static ServiceException blockIDNotFound(String blockID) {
        return new ServiceException(error_BLOCK_ID_NOT_FOUND, String.format(desc_error_BLOCK_ID_NOT_FOUND, blockID), HttpStatus.NOT_FOUND);
    }

    public static ServiceException transactionNotFound(String transactionId) {
        return new ServiceException(error_TRANSACTION_NOT_FOUND, String.format(desc_error_TRANSACTION_NOT_FOUND, transactionId), HttpStatus.NOT_FOUND);
    }

    public static ServiceException operationNotFound(String operationId) {
        return new ServiceException(error_OPERATION_NOT_FOUND, String.format(desc_error_OPERATION_NOT_FOUND, operationId), HttpStatus.NOT_FOUND);
    }

    public static ServiceException supernodeNotFound(String accountName) {
        return new ServiceException(error_SUPERNODE_NOT_FOUND, String.format(desc_error_SUPERNODE_NOT_FOUND, accountName), HttpStatus.NOT_FOUND);
    }


    public static ServiceException walletNotFound() {
        return new ServiceException(error_WALLET_NOT_FOUND, desc_error_WALLET_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    public static ServiceException certificateNotFound() {
        return new ServiceException(error_CERT_NOT_FOUND, desc_error_CERT_NOT_FOUND, HttpStatus.NOT_FOUND);
    }


    public static ServiceException internalServerError() {
        return new ServiceException(INTERNAL_SERVER_error, desc_INTERNAL_SERVER_error,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public static ServiceException internalServerError(String message) {
        return new ServiceException(INTERNAL_SERVER_error, message,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public static ServiceException unauthorization() {
        return new ServiceException(error_UNAUTHORIZTION, desc_UNAUTHORIZTION, HttpStatus.UNAUTHORIZED);
    }

    public static ServiceException notEnoughBalance() {
        return new ServiceException(error_NOT_ENOUGH_BALANCE, desc_error_NOT_ENOUGH_BALANCE, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException invalidAddress() {
        return new ServiceException(error_INVALID_ADDRESS, desc_error_INVALID_ADDRESS, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException errorRequestToBeowulfNetwork(String message) {
        return new ServiceException(error_REQUEST_TO_BEOWULF_NETWORK, desc_error_REQUEST_TO_BEOWULF_NETWORK + message, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public static ServiceException errorConflictCreateForwarderRequest() {
        return new ServiceException(error_CONFLICT_NONCE_WHEN_CREATE_FORWADER, desc_error_CONFLICT_NONCE_WHEN_CREATE_FORWADER, HttpStatus.CONFLICT);
    }

    public static ServiceException errorConflictCreateWalletRequest() {
        return new ServiceException(error_CONFLICT_NONCE_WHEN_CREATE_WALLET, desc_error_CONFLICT_NONCE_WHEN_CREATE_WALLET, HttpStatus.CONFLICT);
    }

    public static ServiceException errorTransactionSendToNetwork() {
        return new ServiceException(error_TRANSACTION_SEND_TO_NETWORK, desc_error_TRANSACTION_SEND_TO_NETWORK, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public static ServiceException invalidValue() {
        return new ServiceException(error_INVALID_VALUE, desc_error_INVALID_VALUE, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException conflictSendOutRequest() {
        return new ServiceException(error_CONFLICT_SEND_OUT_REQUEST, desc_error_CONFLICT_SEND_OUT_REQUEST, HttpStatus.CONFLICT);
    }

    public static ServiceException invalidRequestParam(String message) {
        return new ServiceException(error_INVALID_REQUEST_PARAM, message, HttpStatus.BAD_REQUEST);
    }

    public static ServiceException apiKeyTypeNotSupported() {
        return new ServiceException(error_API_KEY_TYPE_NOT_SUPPORTED, desc_error_API_KEY_TYPE_NOT_SUPPORTED, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException levelNotFound() {
        return new ServiceException(error_LEVEL_NOT_FOUND, desc_error_LEVEL_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    public static ServiceException apikeyIsDisable() {
        return new ServiceException(error_API_KEY_IS_DISABLED, desc_error_API_KEY_IS_DISABLE, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException apikeyExceedLimit() {
        return new ServiceException(error_API_KEY_EXCEED_LIMIT, desc_error_API_KEY_EXCEED_LIMIT, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException accountExisted() {
        return new ServiceException(error_ACCOUNT_EXISTED, desc_error_ACCOUNT_EXISTED, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException accountNotExisted() {
        return new ServiceException(error_ACCOUNT_NOT_EXISTED, desc_error_ACCOUNT_NOT_EXISTED, HttpStatus.NOT_ACCEPTABLE);
    }

    public static ServiceException apikeyExisted() {
        return new ServiceException(error_API_KEY_ALREADY_EXISTED, desc_error_API_KEY_ALREADY_EXISTED, HttpStatus.CONFLICT);
    }

    public static ServiceException accessDenied() {
        return new ServiceException(error_ACCESS_DENIED, desc_ACCESS_DENIED, HttpStatus.FORBIDDEN);
    }

    public static ServiceException tooManyRequestAirdrop() {
        return new ServiceException(error_TOO_MANY_REQUEST_AIRDROP, desc_error_TOO_MANY_REQUEST_AIRDROP, HttpStatus.TOO_MANY_REQUESTS);
    }

    public static ServiceException tooManyRequest() {
        return new ServiceException(error_TOO_MANY_REQUEST, desc_error_TOO_MANY_REQUEST, HttpStatus.TOO_MANY_REQUESTS);
    }

    public static CrawlingException errorCrawlingExistedAction() {
        return new CrawlingException(error_EXISTED_ACTION_DOCUMENT, desc_error_EXISTED_ACTION_DOCUMENT);
    }

    public static CrawlingException errorCrawlingCreateBlockDocument() {
        return new CrawlingException(error_WHEN_CREATE_BLOCK_DOCUMENT, desc_error_WHEN_CREATE_BLOCK_DOCUMENT);
    }

    public static CrawlingException errorCrawlingCreateTxDocument() {
        return new CrawlingException(error_WHEN_CREATE_TRANSACTION_DOCUMENT, desc_error_WHEN_CREATE_TRANSACTION_DOCUMENT);
    }

    public static CrawlingException errorCrawlingCreateOpDocument() {
        return new CrawlingException(error_WHEN_CREATE_OPERATION_DOCUMENT, desc_error_WHEN_CREATE_OPERATION_DOCUMENT);
    }

    public static CrawlingException errorCrawlingCreateAccountDocument() {
        return new CrawlingException(error_WHEN_CREATE_ACCOUNT_DOCUMENT, desc_error_WHEN_CREATE_ACCOUNT_DOCUMENT);
    }

    public static CrawlingException errorCrawlingExistedBlock() {
        return new CrawlingException(error_EXISTED_BLOCK_DOCUMENT, desc_error_EXISTED_BLOCK_DOCUMENT);
    }

    public static CrawlingException errorCrawlingExistedTx() {
        return new CrawlingException(error_EXISTED_TRANSACTION_DOCUMENT, desc_error_EXISTED_TRANSACTION_DOCUMENT);
    }

    public static CrawlingException errorCrawlingExistedOp() {
        return new CrawlingException(error_EXISTED_OPERATION_DOCUMENT, desc_error_EXISTED_OPERATION_DOCUMENT);
    }

    public static CrawlingException errorCrawlingExistedAccount() {
        return new CrawlingException(error_EXISTED_ACCOUNT_DOCUMENT, desc_error_EXISTED_ACCOUNT_DOCUMENT);
    }
}
