package com.beowulf.account.repository.impl;

import com.beowulf.account.repository.extend.ApiKeyLevelRepositoryExtend;
import org.springframework.stereotype.Repository;

@Repository
public class ApiKeyLevelRepositoryImpl implements ApiKeyLevelRepositoryExtend {
}
