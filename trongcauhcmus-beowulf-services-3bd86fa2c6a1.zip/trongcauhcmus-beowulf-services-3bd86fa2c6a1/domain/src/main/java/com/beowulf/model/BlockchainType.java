package com.beowulf.model;

public enum BlockchainType {
    BWF,
    ETH,
    EOS,
    BTC,
    NEM,
    XRP,
    XLM
}
