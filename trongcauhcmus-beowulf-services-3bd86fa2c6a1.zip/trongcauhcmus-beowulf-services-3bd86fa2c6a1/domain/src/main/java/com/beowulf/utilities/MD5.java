package com.beowulf.utilities;

import java.security.MessageDigest;

/**
 * This class provides APIs to interact with MD5 hash function
 * 
 * @author Khoa Mac Tu - khoavtvn1991@yahoo.com.vn
 * @version 11/24/2015
 */

public class MD5 {

	/**
	 * Hash a message string with MD5 hash algorithm
	 * 
	 * @param sign
	 *            : message will be hashed
	 * @return A hash string if success or null if error occurred
	 */
	public static String hash(String sign) {
		String result = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(sign.getBytes());
			byte[] hash = md.digest();
			StringBuilder hexString = new StringBuilder();

			for (byte b : hash) {
				if ((0xff & b) < 0x10)
					hexString.append("0").append(Integer.toHexString((0xFF & b)));
				else
					hexString.append(Integer.toHexString(0xFF & b));
			}
			result = hexString.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
}