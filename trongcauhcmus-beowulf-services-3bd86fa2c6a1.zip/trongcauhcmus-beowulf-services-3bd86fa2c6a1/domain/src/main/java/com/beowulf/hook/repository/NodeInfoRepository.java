package com.beowulf.hook.repository;

import com.beowulf.hook.document.NodeInfo;
import com.beowulf.hook.repository.extend.NodeInfoRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface NodeInfoRepository extends MongoRepository<NodeInfo, ObjectId>, NodeInfoRepositoryExtend {
    @Query(value = "{'node_url' : ?0}")
    NodeInfo findNodeInfoByNode_url(String node_url);
}
