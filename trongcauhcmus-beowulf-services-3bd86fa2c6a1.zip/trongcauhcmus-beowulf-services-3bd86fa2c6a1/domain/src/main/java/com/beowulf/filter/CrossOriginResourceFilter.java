package com.beowulf.filter;

import com.beowulf.utilities.LoggerUtil;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;

/**
 * Servlet Filter implementation class CrossOriginResourceFilter
 */
public abstract class CrossOriginResourceFilter implements Filter {
    private static final String TAG = CrossOriginResourceFilter.class.getName();

    public CrossOriginResourceFilter() {

    }

    public void destroy() {

    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        String ORIGIN = "Origin";
        String REFERER = "Referer";

        HttpServletResponse servletResponse = (HttpServletResponse) response;
        HttpServletRequest servletRequest = (HttpServletRequest) request;

        String originDomain = "null";

        if (servletRequest.getHeader(ORIGIN) != null && !servletRequest.getHeader(ORIGIN).equals("null"))
            originDomain = servletRequest.getHeader(ORIGIN);

        if ("null".equals(originDomain) || "".equals(originDomain))
            if (servletRequest.getHeader(REFERER) != null && !servletRequest.getHeader(REFERER).equals("null"))
                originDomain = servletRequest.getHeader(REFERER);

        URI uri = URI.create(originDomain);

        originDomain = uri.getScheme() + "://" + uri.getHost();
        if (uri.getPort() > 0)
            originDomain = originDomain + ":" + uri.getPort();

        servletResponse.addHeader("Access-Control-Allow-Methods", "POST, GET, HEAD, OPTIONS, DELETE, PUT");
        servletResponse.setHeader("Access-Control-Allow-Credentials", "true");
        servletResponse.setHeader("Access-Control-Allow-Headers",
                "X-Requested-With, X-Auth-Token, Content-Type, "
                        + "Access-Control-Allow-Origin, g-recaptcha-response, Authorization, captcha");

        if (validateOrigin(originDomain)) {
            servletResponse.setHeader("Access-Control-Allow-Origin", originDomain);
        }

        if (servletRequest.getMethod().equals("OPTIONS")) {
            try {
                response.getWriter().print("OK");
                response.getWriter().flush();
            } catch (IOException e) {
                LoggerUtil.e(TAG, e.getMessage());
            }
        } else {
            chain.doFilter(request, response);
        }
    }

    public void init(FilterConfig fConfig) throws ServletException {
    }

    protected abstract boolean validateOrigin(String origin);

}
