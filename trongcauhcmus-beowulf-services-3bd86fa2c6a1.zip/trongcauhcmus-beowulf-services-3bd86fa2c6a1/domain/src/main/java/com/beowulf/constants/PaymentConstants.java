package com.beowulf.constants;

public class PaymentConstants {
    public static final String URI_ADD_HOOK = "https://bw-hook.beowulfchain.com/hook/eth/addhook";

    public static final String URI_REMOVE_HOOK = "https://bw-hook.beowulfchain.com/hook/eth/removehook";

    public static final String URI_ETHER_VALUE = "https://api.etherscan.io/api?module=stats&action=ethprice&apikey=YourApiKeyToken";

    public static final String URI_WEB_HOOK = "https://webhook.site/006c26a0-bc75-4773-bc23-49e138e0f28c";

    public static final int EXPIRED_TIME = 600000;

    public static final String MIN_FEE_ACCOUNT_PAYMENT = "5.00";

    public static final String KEY_HASH = "tJsVXouhCPkUmJWG";

    public static final String INIT_VECTOR = "1122334455667788";

    public static final String ADDRESS_COLLECT_MONEY = "0x37066d497c58D6A84798dcC1a016B3e2Cb6d3232";
}

