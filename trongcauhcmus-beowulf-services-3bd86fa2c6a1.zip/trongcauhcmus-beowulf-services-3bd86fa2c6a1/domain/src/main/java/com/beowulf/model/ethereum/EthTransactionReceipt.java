/*
 * Copyright (c) 2018.
 * @author TrongCauTa - trongcauhcmus@gmail.com
 * @version 4/16/18 10:11 AM
 */

package com.beowulf.model.ethereum;

import com.beowulf.model.TransactionReceipt;
import com.beowulf.model.ethereum.contract.ERC20;
import com.beowulf.utilities.GsonSingleton;
import org.web3j.protocol.parity.methods.response.Trace;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class EthTransactionReceipt extends TransactionReceipt {
    private String hash;
    private String blockHash;
    private String address;
    private long blockNumber;
    private int confirmations;
    private String coinType;
    private String transactionIndex;
    private boolean erc20;
    private BigInteger in_value;
    private BigInteger out_value;
    private BigInteger total_value;
    private List<CallAction> trace_actions;

    public EthTransactionReceipt() {
        this.in_value = BigInteger.ZERO;
        this.out_value = BigInteger.ZERO;
        this.total_value = BigInteger.ZERO;
        this.trace_actions = new ArrayList<>();
    }

    public EthTransactionReceipt mergeEtherAction(Trace.CallAction callAction, String transactionHash) throws NullPointerException {
        // must be in one transaction
        if (!this.getHash().equals(transactionHash))
            throw new NullPointerException("invalid call confirmations, this call confirmations must be the same hash");

        if (this.getAddress().equals(callAction.getFrom())) {
            this.setOut_value(this.getOut_value().add(callAction.getValue()));
            this.setTotal_value(this.getTotal_value().subtract(callAction.getValue()));

            return this;
        } else if (this.getAddress().equals(callAction.getTo())) {
            this.setIn_value(this.getIn_value().add(callAction.getValue()));
            this.setTotal_value(this.getTotal_value().add(callAction.getValue()));
            return this;
        }

        // must be valid address
        throw new NullPointerException("invalid call confirmations, can not find any address map with this confirmations");
    }

    public EthTransactionReceipt mergeErc20Action(ERC20.TransferEventResponse eventResponse) throws NullPointerException {
        // must be in one transaction
        if (!this.getHash().equals(eventResponse.log.getTransactionHash()))
            throw new NullPointerException("invalid call confirmations, this call confirmations must be the same hash");

        if (this.getAddress().equals(eventResponse._from)) {
            this.setOut_value(this.getOut_value().add(eventResponse._value));
            this.setTotal_value(this.getTotal_value().subtract(eventResponse._value));

            return this;
        } else if (this.getAddress().equals(eventResponse._to)) {
            this.setIn_value(this.getIn_value().add(eventResponse._value));
            this.setTotal_value(this.getTotal_value().add(eventResponse._value));
            return this;
        }

        // must be valid address
        throw new NullPointerException("invalid call confirmations, can not find any address map with this confirmations");
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public int getConfirmations() {
        return confirmations;
    }

    public void setConfirmations(int confirmations) {
        this.confirmations = confirmations;
    }

    public String getCoinType() {
        return coinType;
    }

    public void setCoinType(String coinType) {
        this.coinType = coinType;
    }

    public String getTransactionIndex() {
        return transactionIndex;
    }

    public void setTransactionIndex(String transactionIndex) {
        this.transactionIndex = transactionIndex;
    }

    public boolean isErc20() {
        return erc20;
    }

    public void setErc20(boolean erc20) {
        this.erc20 = erc20;
    }

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(String blockHash) {
        this.blockHash = blockHash;
    }

    public BigInteger getIn_value() {
        return in_value;
    }

    public void setIn_value(BigInteger in_value) {
        this.in_value = in_value;
    }

    public BigInteger getOut_value() {
        return out_value;
    }

    public void setOut_value(BigInteger out_value) {
        this.out_value = out_value;
    }

    public List<CallAction> getTrace_actions() {
        return trace_actions;
    }

    public void setTrace_actions(List<CallAction> trace_actions) {
        this.trace_actions = trace_actions;
    }

    public BigInteger getTotal_value() {
        return total_value;
    }

    public void setTotal_value(BigInteger total_value) {
        this.total_value = total_value;
    }

    @Override
    public String toString() {

//        JsonObject txn = new JsonObject();
//        txn.addProperty("hash", getHash());
//        txn.addProperty("address", getAddress());
//        txn.addProperty("value", getValue());
//        txn.addProperty("blockNumber", getBlock_number());
//        txn.addProperty("confirmations", getConfirmations());
//        txn.addProperty("coinType", getCoinType());
//        txn.addProperty("erc20", isErc20());
//        txn.addProperty("blockHash", getBlockHash());
//        txn.addProperty("in_value", getIn_value().toString());
//        txn.addProperty("out_value", getOut_value());
//        txn.addProperty("total_value", getTotal_value().toString());
//        txn.("trace_actions", getTrace_actions());
        return GsonSingleton.getInstance().toJson(this);
//        return txn.toString();
    }
}
