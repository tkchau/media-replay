package com.beowulf.account.repository.extend;

public interface HistoryTransactionRepositoryExtend {
}
