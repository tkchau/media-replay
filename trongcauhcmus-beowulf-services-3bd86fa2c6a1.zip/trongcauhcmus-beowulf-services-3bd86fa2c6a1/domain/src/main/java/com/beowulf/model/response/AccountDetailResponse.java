package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulfchain.beowulfj.plugins.apis.condenser.models.ExtendedAccount;
import com.beowulfchain.beowulfj.protocol.Asset;

import java.util.ArrayList;
import java.util.List;

public class AccountDetailResponse {

    private long id;
    private String name;
    private AuthorityData permissions;
    private boolean multisig;
    private String json_metadata;
    private long last_owner_update;
    private long created_at;
    private long created_block;
    private String creator;
    private String bwf_balance;
    private String w_balance;
    private String vs_balance;
    private String vs_shares;
    private List<String> tokens = new ArrayList<>();
    private String transaction_id;
    private List<String> supernode_votes = new ArrayList<>();

    public AccountDetailResponse() {

    }

    public AccountDetailResponse(BeowulfAccount beowulfAccount, ExtendedAccount accountDetail) {
        this.id = accountDetail.getId();
        this.name = beowulfAccount.getName();
        this.permissions = beowulfAccount.getPermissions();
        this.multisig = beowulfAccount.isMultisig();
        this.created_at = beowulfAccount.getCreated_at();
        this.created_block = beowulfAccount.getCreated_block();
        this.creator = beowulfAccount.getCreator();
        this.last_owner_update = accountDetail.getLastOwnerUpdate().getDateTimeAsTimestamp();
        this.json_metadata = accountDetail.getJsonMetadata();
        this.bwf_balance = accountDetail.getBalance().toString();
        this.w_balance = accountDetail.getWdBalance().toString();
        this.vs_balance = accountDetail.getVestingBalance().toString();
        this.vs_shares = accountDetail.getVestingShares().toString();
        for (Asset token : accountDetail.getTokenList()) {
            this.tokens.add(token.toString());
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public AuthorityData getPermissions() {
        return permissions;
    }

    public void setPermissions(AuthorityData permissions) {
        this.permissions = permissions;
    }

	public String getJson_metadata() {
		return json_metadata;
	}

    public boolean isMultisig() {
        return multisig;
    }

    public void setMultisig(boolean multisig) {
        this.multisig = multisig;
    }

    public void setJson_metadata(String json_metadata) {
        this.json_metadata = json_metadata;
    }

    public long getLast_owner_update() {
        return last_owner_update;
    }

    public void setLast_owner_update(long last_owner_update) {
        this.last_owner_update = last_owner_update;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }

    public String getBwf_balance() {
        return bwf_balance;
    }

    public void setBwf_balance(String bwf_balance) {
        this.bwf_balance = bwf_balance;
    }

    public String getW_balance() {
        return w_balance;
    }

    public void setW_balance(String w_balance) {
        this.w_balance = w_balance;
    }

    public String getVs_balance() {
        return vs_balance;
    }

    public void setVs_balance(String vs_balance) {
        this.vs_balance = vs_balance;
    }

    public List<String> getTokens() {
        return tokens;
    }

    public void setTokens(List<String> tokens) {
        this.tokens = tokens;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public List<String> getSupernode_votes() {
        return supernode_votes;
    }

    public void setSupernode_votes(List<String> supernode_votes) {
        this.supernode_votes = supernode_votes;
    }

    public long getCreated_block() {
        return created_block;
    }

    public void setCreated_block(long created_block) {
        this.created_block = created_block;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getVs_shares() {
        return vs_shares;
    }

    public void setVs_shares(String vs_shares) {
        this.vs_shares = vs_shares;
    }
}
