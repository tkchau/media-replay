package com.beowulf.constants;

public class EthereumConstant {

    public static final String EVENT_TRANSFER_TOKEN_HASH = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

    public static final long ETHEREUM_TRANSACTION_SUCCESS_STATUS = 1;

    public static final long ETHEREUM_TRANSACTION_FAILED_STATUS = 0;

    public static final long ETHEREUM_TRANSACTION_PENDING_STATUS = 2;

    public static final String ROPSTEN_ETHERSCAN_BLOCKNUM = "https://api-ropsten.etherscan.io/api?module=proxy&action=eth_blockNumber";
    public static final String ROPSTEN_INFURA_BLOCKNUM = "https://api.infura.io/v1/jsonrpc/ropsten/eth_blockNumber";

    public static final String ETHERSCAN_BLOCKNUM = "https://api.etherscan.io/api?module=proxy&action=eth_blockNumber";
    public static final String INFURA_BLOCKNUM = "https://api.infura.io/v1/jsonrpc/mainnet/eth_blockNumber";
}
