package com.beowulf.handler.communication.apache;

import com.google.api.client.util.Preconditions;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;

import java.net.URI;

final class HttpMethodExtend extends HttpEntityEnclosingRequestBase {
    private final String methodName;

    public HttpMethodExtend(String methodName, URI uri) {
        this.methodName = Preconditions.checkNotNull(methodName);
        this.setURI(uri);
    }

    public String getMethod() {
        return this.methodName;
    }
}
