package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = CollectionName.AIRDROP_HISTORY)
public class AirdropHistory {
    @Indexed(unique = true)
    private String account_name;
    @Indexed(expireAfterSeconds = 87000)
    private Date last_query;

    public AirdropHistory(String account_name, Date last_query) {
        this.account_name = account_name;
        this.last_query = last_query;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public Date getLast_query() {
        return last_query;
    }

    public void setLast_query(Date last_query) {
        this.last_query = last_query;
    }
}
