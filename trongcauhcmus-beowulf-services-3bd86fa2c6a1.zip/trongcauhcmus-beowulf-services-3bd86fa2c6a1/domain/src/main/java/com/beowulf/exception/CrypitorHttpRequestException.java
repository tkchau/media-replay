package com.beowulf.exception;

/**
 * @author tatrongcau
 * @project crypitor-services
 * @time 2019-06-16
 */
public class CrypitorHttpRequestException extends CrypitorCommunicationException {
    private static final long serialVersionUID = -3389735550453652556L;

    public CrypitorHttpRequestException(String s) {
        super(s);
    }
}
