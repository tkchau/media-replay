package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulfchain.beowulfj.base.models.Block;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.BLOCKS)
public class BeowulfBlock {

    @Id
    private ObjectId id;

    @Indexed(unique = true)
    private ObjectId bc_id;

    @Indexed(unique = true)
    private String block_id;

    // TODO: 26/12/2019 Consider remove index and using block_id instead
    @Indexed(unique = true)
    private long block_number;

    private String previous;

    private String transaction_merkle_root;

    private long timestamp;

    @Indexed
    private String supernode;

    private String supernode_signature;

    private String signing_key;

    private long block_reward;

    private String block_reward_currency;

    private long total_fee;

    private int number_transaction;

    public BeowulfBlock() {
    }

    public BeowulfBlock(Block block) {
        this.block_id = block.getBlockId().toString();
        this.previous = block.getPrevious().toString();
        this.transaction_merkle_root = block.getTransactionMerkleRoot().toString();
        this.timestamp = block.getTimestamp().getDateTimeAsTimestamp();
        this.supernode = block.getSupernode().getName();
        this.supernode_signature = block.getSupernodeSignature();
        this.signing_key = block.getSigningKey().getAddressFromPublicKey();
        this.block_reward = block.getBlockReward().getAmount();
        this.block_reward_currency = block.getBlockReward().getName();
        this.number_transaction = block.getTransactionIds().size();
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getBlock_id() {
        return block_id;
    }

    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public long getBlock_number() {
        return block_number;
    }

    public void setBlock_number(long block_number) {
        this.block_number = block_number;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getSigning_key() {
        return signing_key;
    }

    public void setSigning_key(String signing_key) {
        this.signing_key = signing_key;
    }

    public long getBlock_reward() {
        return block_reward;
    }

    public void setBlock_reward(long block_reward) {
        this.block_reward = block_reward;
    }

    public String getSupernode() {
        return supernode;
    }

    public void setSupernode(String supernode) {
        this.supernode = supernode;
    }

    public String getSupernode_signature() {
        return supernode_signature;
    }

    public void setSupernode_signature(String supernode_signature) {
        this.supernode_signature = supernode_signature;
    }

    public String getBlock_reward_currency() {
        return block_reward_currency;
    }

    public void setBlock_reward_currency(String block_reward_currency) {
        this.block_reward_currency = block_reward_currency;
    }

    public long getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(long total_fee) {
        this.total_fee = total_fee;
    }

    public int getNumber_transaction() {
        return number_transaction;
    }

    public void setNumber_transaction(int number_transaction) {
        this.number_transaction = number_transaction;
    }

    public String getPrevious() {
        return previous;
    }

    public void setPrevious(String previous) {
        this.previous = previous;
    }

    public String getTransaction_merkle_root() {
        return transaction_merkle_root;
    }

    public void setTransaction_merkle_root(String transaction_merkle_root) {
        this.transaction_merkle_root = transaction_merkle_root;
    }

    public ObjectId getBc_id() {
        return bc_id;
    }

    public void setBc_id(ObjectId bc_id) {
        this.bc_id = bc_id;
    }
}
