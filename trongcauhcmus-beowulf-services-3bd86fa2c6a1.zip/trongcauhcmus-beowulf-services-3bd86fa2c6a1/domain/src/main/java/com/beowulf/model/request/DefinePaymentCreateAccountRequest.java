package com.beowulf.model.request;

public class DefinePaymentCreateAccountRequest {
    private int expired_time;


    public DefinePaymentCreateAccountRequest() {
    }

    public DefinePaymentCreateAccountRequest(int expired_time) {
        this.expired_time = expired_time;
    }

    public int getExpired_time() {
        return expired_time;
    }

    public void setExpired_time(int expired_time) {
        this.expired_time = expired_time;
    }

}
