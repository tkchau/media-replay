package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.NodeInfo;

public interface NodeCrawlingInfoRepositoryExtend {
    void updateLastCrawl(String nodeUrl, long blockNum);

    boolean updateLastCrawlOnDestroy(String nodeUrl, long blockNum);

    void updateLastIrreversibleCrawl(String nodeUrl, long blockNum);

    boolean updateLastIrreversibleCrawlOnDestroy(String nodeUrl, long blockNum);

    long getLastCrawlingBlock(long startBlock, String nodeUrl);

    long getLastCrawlingIrreversibleBlock(long startBlock, String nodeUrl);

    NodeInfo findNodeInfoByNode_url(String node_url);

    boolean updateSegment(String nodeUrl, int segment);

    int getLastSegment(String nodeUrl);

    boolean turnOn(String nodeUrl);

    boolean turnOff(String nodeUrl);

    boolean isTurnedOff(String nodeUrl);
}
