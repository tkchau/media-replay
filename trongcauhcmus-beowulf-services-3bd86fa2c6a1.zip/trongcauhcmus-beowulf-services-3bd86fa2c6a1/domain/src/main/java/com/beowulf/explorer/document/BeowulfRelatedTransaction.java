package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = CollectionName.RELATED_TRANSACTION)
public class BeowulfRelatedTransaction {
    @Id
    private ObjectId id;
    @Indexed
    private String transaction_id;
    private List<String> related_transaction;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public List<String> getRelated_transaction() {
        return related_transaction;
    }

    public void setRelated_transaction(List<String> related_transaction) {
        this.related_transaction = related_transaction;
    }
}
