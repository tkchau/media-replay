package com.beowulf.handler;

public interface RedisKeyExpiredHandlerCallback {
    public void onKeyExpired(String key);
}
