package com.beowulf.config.repository;

import com.beowulf.config.document.Configuration;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ConfigurationRepository extends MongoRepository<Configuration, ObjectId>,
        ConfigurationRepositoryExtend {
}
