package com.beowulf.utilities;

import com.beowulf.constants.EthereumConstant;
import com.beowulf.model.CustomizeGasProvider;
import com.beowulf.model.ethereum.*;
import com.beowulf.model.ethereum.contract.ERC20;
import com.beowulf.model.ethereum.contract.WalletSimple;
import com.beowulf.model.ethereum.multisig.EtherTxnInfo;
import com.beowulf.model.ethereum.multisig.TxnInfo;
import org.bitcoinj.core.ECKey;
import org.web3j.abi.EventValues;
import org.web3j.abi.datatypes.Address;
import org.web3j.crypto.*;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.Web3jService;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.DefaultBlockParameterNumber;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.Request;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.*;
import org.web3j.protocol.http.HttpService;
import org.web3j.protocol.parity.Parity;
import org.web3j.protocol.parity.methods.response.ParityTracesResponse;
import org.web3j.protocol.parity.methods.response.Trace;
import org.web3j.rlp.RlpEncoder;
import org.web3j.rlp.RlpList;
import org.web3j.rlp.RlpString;
import org.web3j.tx.*;
import org.web3j.tx.gas.ContractGasProvider;
import org.web3j.tx.gas.DefaultGasProvider;
import org.web3j.tx.gas.StaticGasProvider;
import org.web3j.tx.response.Callback;
import org.web3j.tx.response.QueuingTransactionReceiptProcessor;
import org.web3j.tx.response.TransactionReceiptProcessor;
import org.web3j.utils.Numeric;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.web3j.tx.TransactionManager.DEFAULT_POLLING_ATTEMPTS_PER_TX_HASH;

public class Web3JClient {
    private static String TAG = Web3JClient.class.getName();
    private static String url = "http://localhost:8545";
    private static Web3jService service;
    private static Web3j web3j;
    private static Parity parity;
    private static CustomizeGasProvider customizeGasProvider;
    private static byte chainId;

    private static final int COUNT = 10;  // don't set too high if using a real Ethereum network
    private static final long POLLING_FREQUENCY = 15000;

    public static ConcurrentLinkedQueue<TransactionReceipt> transactionReceipts =
            new ConcurrentLinkedQueue<>();

    public static TransactionReceiptProcessor transactionReceiptProcessor;

    public static void init(String host) throws IOException {
        LoggerUtil.i(Web3JClient.class, "Start init Web3J Client");
        url = host;
        service = new HttpService(url);
        web3j = Web3j.build(service);
        parity = Parity.build(service);
        customizeGasProvider = new CustomizeGasProvider();
        int netversion = getNetVersion();
        if (netversion == 1) {
            chainId = ChainId.MAINNET;
        } else {
            chainId = ChainId.ROPSTEN;
        }

        transactionReceiptProcessor = new QueuingTransactionReceiptProcessor(web3j, new Callback() {
            @Override
            public void accept(TransactionReceipt transactionReceipt) {
                transactionReceipts.add(transactionReceipt);
                System.out.println("Receive new receipt for transaction: " + transactionReceipt.getTransactionHash());
            }

            @Override
            public void exception(Exception exception) {
                System.out.println("Transaction has failed while recording receipt");
                exception.printStackTrace();
                throw ServiceExceptionUtils.internalServerError();
            }
        }, DEFAULT_POLLING_ATTEMPTS_PER_TX_HASH, POLLING_FREQUENCY);
    }

    public static Transaction getTransactionByTransactionHash(String transactionHash) {
        try {
            EthTransaction transaction = getWeb3Client().ethGetTransactionByHash(transactionHash).send();
            return transaction.getResult();
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return null;
    }

    public static TransactionReceipt getTransactionReceiptByHash(String hash) throws IOException {
        EthGetTransactionReceipt response = getWeb3Client().ethGetTransactionReceipt(hash).send();
        if (response.hasError()) {
            throw ServiceExceptionUtils.transactionNotFound(hash);
        }
        return response.getResult();
    }

    public static int getNetVersion() throws IOException {
        Request<?, NetVersion> request = web3j.netVersion();
        return Integer.valueOf(request.send().getNetVersion());
    }

    public static Parity getParityClient() throws NullPointerException {
        if (parity == null) {
            throw new NullPointerException("Init web3j client before using...");
        }
        return parity;
    }

    public static Web3j getWeb3Client() {
        if (web3j == null) {
            throw new NullPointerException("Init web3j client before using...");
        }
        return web3j;
    }

    public static List<Trace> getCallActionsInBlock(long blockNum) throws Exception {
        DefaultBlockParameterNumber number = new DefaultBlockParameterNumber(blockNum);
        Request<?, ParityTracesResponse> request = getParityClient().traceBlock(number);
        ParityTracesResponse response = request.send();
        return response.getTraces();
    }

    public static BigInteger getBalance(String address) throws IOException {
        DefaultBlockParameterNumber number = new DefaultBlockParameterNumber(blockNumber());
        Request<?, EthGetBalance> request = getWeb3Client().ethGetBalance(address, number);
        return request.send().getBalance();
    }

    public static BigInteger getErc20Balance(String address, String tokenAddress) throws Exception {
        ContractGasProvider provider = new DefaultGasProvider();
        ERC20 token = ERC20.load(tokenAddress,
                getWeb3Client(),
                new ReadonlyTransactionManager(getWeb3Client(), "0xa107483c8a16a58871182a48d4ba1fbbb6a64c71"),
                provider);
        RemoteCall<BigInteger> request = token.balanceOf(address);
        BigInteger balance = request.send();
        return balance;
    }

    public static long blockNumber() {
        try {
            Request<?, EthBlockNumber> request = getWeb3Client().ethBlockNumber();
            EthBlockNumber blockNumber = request.send();
            return blockNumber.getBlockNumber().longValueExact();
        } catch (IOException e) {
            System.out.println("can not get block count from server: " + url);
        }
        return 0;
    }

    public static EthLog getErc20EventInBlock(long blockNum) throws Exception {
        DefaultBlockParameter blockParameter = DefaultBlockParameter.valueOf(BigInteger.valueOf(blockNum));
        EthFilter req = new EthFilter(blockParameter, blockParameter, Collections.emptyList());
        req.addSingleTopic("0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef");
        req.addNullTopic();
        req.addNullTopic();
        Request<?, EthLog> request = getWeb3Client().ethGetLogs(req);
        return request.send();
    }

    public static List<Trace> getCallAction(String hash) throws Exception {
        Request<?, ParityTracesResponse> request = getParityClient().traceTransaction(hash);
        ParityTracesResponse response = request.send();
        return response.getTraces();
    }

    public static ERC20.TransferEventResponse getTransferEventWithLog(Log log) throws Exception {
        try {
            EventValues eventValues = Contract.staticExtractEventParameters(ERC20.TRANSFER_EVENT, log);
            ERC20.TransferEventResponse typedResponse = new ERC20.TransferEventResponse();
            typedResponse.log = log;
            typedResponse._from = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._to = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse._value = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            return typedResponse;
        } catch (IndexOutOfBoundsException e) {
            throw new IndexOutOfBoundsException("transaction is invalid because it does not map with format of Erc20 event");
        }
    }

    public static ParityGetBlockHeaderByNumber parityGetBlockHeaderByNumber(long blockNumber) throws Exception {
        try {
            Request<?, ParityGetBlockHeaderByNumberResponse> request = new Request<>("parity_getBlockHeaderByNumber",
                    Collections.singletonList(Numeric.toHexStringWithPrefix(BigInteger.valueOf(blockNumber))),
                    service,
                    ParityGetBlockHeaderByNumberResponse.class);
            ParityGetBlockHeaderByNumberResponse response = request.send();
            return response.getResult();
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(String.format("parity_getBlockHeaderByNumber request for %s throw Exception", e.getCause()));
        }
    }

    public static long getBlockTimestamp(ParityGetBlockHeaderByNumber blockHeader) {
        if (blockHeader != null)
            return CurrencyUnitConverter.getLongValueFromHexString(blockHeader.getTimestamp()) * 1000L;
        return -1L;
    }

    public static long getBlockTimestamp(long blockNumber) {
        try {
            ParityGetBlockHeaderByNumber blockHeader = parityGetBlockHeaderByNumber(blockNumber);
            if (blockHeader != null)
                return CurrencyUnitConverter.getLongValueFromHexString(blockHeader.getTimestamp()) * 1000L;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1L;
    }

    public static BigInteger nextNonce(String address) throws Exception {
        try {
            Request<?, ParityNextNonceResponse> request = new Request<>("parity_nextNonce",
                    Collections.singletonList(address),
                    service,
                    ParityNextNonceResponse.class);
            return request.sendAsync().get().nonceValueExact();
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(String.format("parity_nextNonce request for %s throw Exception", address));
        }
    }

    public static String calculateContractAddress(String address, long nonce) {
        byte[] addressAsBytes = Numeric.hexStringToByteArray(address);

        byte[] calculatedAddressAsBytes =
                Hash.sha3(RlpEncoder.encode(
                        new RlpList(
                                RlpString.create(addressAsBytes),
                                RlpString.create((nonce)))));

        calculatedAddressAsBytes = Arrays.copyOfRange(calculatedAddressAsBytes,
                12, calculatedAddressAsBytes.length);
        String calculatedAddressAsHex = Numeric.toHexString(calculatedAddressAsBytes);
        return calculatedAddressAsHex;
    }

    public static EthAddressInfo createNewAddress() {
        // create new address from secure random
        ECKey ecKey = new ECKey(new SecureRandom());
        ECKeyPair ecKeyPair = ECKeyPair.create(ecKey.getPrivKey());
        Credentials credentials = Credentials.create(ecKeyPair);

        // new ether address object
        EthAddressInfo ethAddressInfo = new EthAddressInfo();
        ethAddressInfo.setAddress(credentials.getAddress().toLowerCase());
        ethAddressInfo.setPrivkey(credentials.getEcKeyPair().getPrivateKey().toString(16));
        return ethAddressInfo;
    }

    public static BigInteger txnCount(String address) {
        try {
            Request<?, ParityNextNonceResponse> request = new Request<>("eth_getTransactionCount",
                    Arrays.asList(address, "latest"),
                    service,
                    ParityNextNonceResponse.class);
            CompletableFuture<ParityNextNonceResponse> completableFuture = request.sendAsync();
            ParityNextNonceResponse nextNonceResponse = completableFuture.get(60, TimeUnit.SECONDS);
            return nextNonceResponse.nonceValueExact();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean checkValidAddress(String requestAddress) {
        return WalletUtils.isValidAddress(requestAddress);
    }

    public static BigInteger getNextSequenceId(String address, String wallet_address) throws Exception {
        TransactionManager txManager = new ReadonlyTransactionManager(web3j, address);
        WalletSimple walletSimple = WalletSimple.load(wallet_address, getWeb3Client(), txManager, customizeGasProvider);
        RemoteCall<BigInteger> remoteCall = walletSimple.getNextSequenceId();
        BigInteger nextSequenceId = remoteCall.send();
        return nextSequenceId;
    }

    public static LinkedHashMap<String, Trace> getTraceActionAsMap(List<Trace> traceList) {
        LinkedHashMap<String, Trace> traceLinkedHashMap = new LinkedHashMap<>();
        for (Trace trace : traceList) {
            String key = String.join("_", trace.getTraceAddress().stream().map(BigInteger::toString).collect(Collectors.toList()));
            if (StringUtils.isEmpty(key))
                key = "root";
            traceLinkedHashMap.put(key, trace);
        }
        return traceLinkedHashMap;
    }

    public static LinkedHashMap<String, Trace> getTraceActionAsMap(String hash) throws Exception {
        List<Trace> traces = getCallAction(hash);
        return getTraceActionAsMap(traces);
    }

    private static boolean isValidTraceAction(LinkedHashMap<String, Trace> traceMap, Trace trace, boolean endAction) {
        try {
            if (traceMap == null || trace == null)
                return false;

            // check error
            if (StringUtils.hasText(trace.getError()))
                throw new Exception("Transaction has error: " + trace.getError());

            // check type
            if (!"call".equals(trace.getType()))
                throw new Exception("Trace type is not 'call'");

            if (endAction) {
                Trace.CallAction callAction = (Trace.CallAction) trace.getAction();
                if (!"call".equals(callAction.getCallType()))
                    return false;
            }

            String parentKey = null;
            if (trace.getTraceAddress() == null || trace.getTraceAddress().size() <= 0)
                return true;
            if (trace.getTraceAddress().size() == 1)
                parentKey = "root";
            else {
                parentKey = String.join("_", trace.getTraceAddress()
                        .subList(0, trace.getTraceAddress().size() - 1)
                        .stream()
                        .map(BigInteger::toString)
                        .collect(Collectors.toList()));
            }

            Trace parentTrace = traceMap.get(parentKey);
            return isValidTraceAction(traceMap, parentTrace, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static ParsedAmountResponse getTotalEtherAmountInTxn(String hash, String address) {
        BigInteger inValue = BigInteger.ZERO;
        BigInteger outValue = BigInteger.ZERO;
        try {
            LinkedHashMap<String, Trace> traceLinkedHashMap = getTraceActionAsMap(hash);
            if (traceLinkedHashMap != null) {
                for (String key : traceLinkedHashMap.keySet()) {
                    Trace trace = traceLinkedHashMap.get(key);
                    Trace.Action action = trace.getAction();
                    if (action instanceof Trace.CallAction) {
                        String fromAddress = ((Trace.CallAction) action).getFrom();
                        String toAddress = ((Trace.CallAction) action).getTo();
                        BigInteger value = ((Trace.CallAction) action).getValue();
                        if (value != null && value.compareTo(BigInteger.ZERO) > 0) {
                            if (address.equals(fromAddress) || address.equals(toAddress)) {
                                if (isValidTraceAction(traceLinkedHashMap, trace, true)) {
                                    if (address.equals(toAddress))
                                        inValue = inValue.add(value);
                                    if (address.equals(fromAddress))
                                        outValue = outValue.add(value);
                                }
                            }
                        }
                    }
                }
            }
            BigInteger total = inValue.subtract(outValue);
            return new ParsedAmountResponse(inValue, outValue, total);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ParsedAmountResponse getTotalErc20AmountInTnx(TransactionReceipt receipt, String address, String coinType) throws IOException {
        BigInteger inValue = BigInteger.ZERO;
        BigInteger outValue = BigInteger.ZERO;

        List<Log> logs = receipt.getLogs();
        for (Log log : logs) {
            // check only coin want to get value
            if (!log.getAddress().equals(coinType))
                continue;

            // transfer erc20 topic always have size = 3
            if (log.getTopics().size() != 3)
                continue;

            List<String> topics = log.getTopics();
            if (EthereumConstant.EVENT_TRANSFER_TOKEN_HASH.equals(topics.get(0))) {

                BigInteger value = Numeric.decodeQuantity(log.getData());

                Address from = new Address(topics.get(1));
                Address to = new Address(topics.get(2));

                if (from.toString().equals(address))
                    outValue = outValue.add(value);

                if (to.toString().equals(address))
                    inValue = inValue.add(value);
            }
        }
        BigInteger total = inValue.subtract(outValue);
        return new ParsedAmountResponse(inValue, outValue, total);
    }

    public static long getTransactionStatus(String transactionHash) {
        try {
            TransactionReceipt receipt = getTransactionReceiptByHash(transactionHash);
            return getTransactionStatus(receipt);
        } catch (Exception e) {
            LoggerUtil.exception(Web3JClient.class, e, true);
        }
        return EthereumConstant.ETHEREUM_TRANSACTION_FAILED_STATUS;
    }

    public static long getTransactionStatus(TransactionReceipt receipt) {
        try {
            if (receipt != null)
                return CurrencyUnitConverter.getLongValueFromHexString(receipt.getStatus());
            else return EthereumConstant.ETHEREUM_TRANSACTION_PENDING_STATUS;
        } catch (Exception e) {
            LoggerUtil.exception(Web3JClient.class, e, true);
        }
        return EthereumConstant.ETHEREUM_TRANSACTION_FAILED_STATUS;
    }

    public static String getNextContractAddress(String address) throws Exception {
        BigInteger nn = nextNonce(address);
        return calculateContractAddress(address, nn.longValueExact());
    }

    public static String adminSendOutFund(String cosigner1, String cosigner2, String multisigWallet, String receiver, String amount, String gasPrice, String gasLimit) throws Exception {
        BigInteger signPrivkey1 = new BigInteger(cosigner1, 16);
        ECKeyPair wallet1 = ECKeyPair.create(signPrivkey1);

        BigInteger value = new BigDecimal(amount).multiply(new BigDecimal("1000000000000000000")).toBigIntegerExact();
        byte[] data = new byte[]{};

        BigInteger expireTime = new BigInteger(String.valueOf(System.currentTimeMillis() / 1000 + 60));

        BigInteger signPrivkey2 = new BigInteger(cosigner2, 16);
        ECKeyPair wallet2 = ECKeyPair.create(signPrivkey2);
        Credentials credentials = Credentials.create(wallet2);

        TransactionManager txManager = new FastRawTransactionManager(getWeb3Client(), credentials);
        WalletSimple walletEth = WalletSimple.load(
                multisigWallet,
                getWeb3Client(),
                txManager,
                new StaticGasProvider(
                        new BigInteger(gasPrice),
                        new BigInteger(gasLimit)));

        // GET NEXT SEQUENCEID
        BigInteger sequenceId = walletEth.getNextSequenceId().send();
        EtherTxnInfo etherTxnInfo = new EtherTxnInfo(receiver, value, data, expireTime, sequenceId);

        // create signature
        byte[] signature = createSignature(wallet1, etherTxnInfo);

        RemoteCall<TransactionReceipt> receiptRemoteCall = walletEth.sendMultiSig(receiver, value, data, expireTime, sequenceId, signature);
        CompletableFuture<TransactionReceipt> receiptCompletableFuture = receiptRemoteCall.sendAsync();
        TransactionReceipt receipt = receiptCompletableFuture.get();
        return receipt.getTransactionHash();
    }

    private static byte[] createSignature(ECKeyPair ecKeyPair, TxnInfo txnInfo) {
        byte[] serializedData = txnInfo.serialize();
        byte[] operationHash = Hash.sha3(serializedData);
        Sign.SignatureData signatureData = Sign.signMessage(operationHash, ecKeyPair, false);
        return concat(signatureData.getR(), signatureData.getS(), new byte[]{signatureData.getV()});
    }

    public static long getTokenDecimal(String token) throws Exception {
        ERC20 erc20 = ERC20.load(
                token,
                getWeb3Client(),
                new ReadonlyTransactionManager(getWeb3Client(), "0xa107483c8a16a58871182a48d4ba1fbbb6a64c71"),
                new DefaultGasProvider());
        return erc20.decimals().send().longValueExact();
    }

    public static String getTokenName(String token) throws Exception {
        ERC20 erc20 = ERC20.load(
                token,
                getWeb3Client(),
                new ReadonlyTransactionManager(getWeb3Client(), "0xa107483c8a16a58871182a48d4ba1fbbb6a64c71"),
                new DefaultGasProvider());
        return erc20.name().send();
    }

    public static String getTokenSymbol(String token) throws Exception {
        ERC20 erc20 = ERC20.load(
                token,
                getWeb3Client(),
                new ReadonlyTransactionManager(getWeb3Client(), "0xa107483c8a16a58871182a48d4ba1fbbb6a64c71"),
                new DefaultGasProvider());
        return erc20.symbol().send();
    }

    /**
     * concat byte array to sign for ether bitgo multisig
     *
     * @param arrays
     * @return
     */
    public static byte[] concat(byte[]... arrays) {
        // Determine the length of the result array
        int totalLength = 0;
        for (int i = 0; i < arrays.length; i++) {
            totalLength += arrays[i].length;
        }

        // create the result array
        byte[] result = new byte[totalLength];

        // copy the source arrays into the result array
        int currentIndex = 0;
        for (int i = 0; i < arrays.length; i++) {
            System.arraycopy(arrays[i], 0, result, currentIndex, arrays[i].length);
            currentIndex += arrays[i].length;
        }

        return result;
    }

    public static void main(String[] args) throws Exception {
        init("http://localhost:8546");
        System.out.println(getTokenDecimal("0xdac17f958d2ee523a2206206994597c13d831ec7"));
        System.out.println(getTokenName("0xdac17f958d2ee523a2206206994597c13d831ec7"));
        System.out.println(getTokenSymbol("0xdac17f958d2ee523a2206206994597c13d831ec7"));
    }
}
