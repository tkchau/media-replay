
package com.beowulf.utilities;

import com.beowulf.constants.CurrencyConstant;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.text.DecimalFormat;

/**
 * This class contain utility functions for converting amount to cryptocurrency
 * unit
 * 
 * @author Mac Tu Khoa - khoavtvn1991@yahoo.com.vn
 * @version 08/08/2017
 */
public class CurrencyUnitConverter {

	/**
	 * Format balance value to desired format before return to client
	 * 
	 * @param balanceValue
	 *            : Value of the balance before format
	 * @param format
	 *            : String represents pattern of the output
	 * @return {@link String} represents value of the balance after formatted or
	 *         empty if error occurred
	 */
	public static String formatValue(long balanceValue, String format) {
		DecimalFormat decimalFormat = new DecimalFormat(format);
		double balanceFormatted = new BigDecimal(balanceValue).divide(CurrencyConstant.DEFAULT_SYSTEM_UNIT)
				.doubleValue();
		return decimalFormat.format(balanceFormatted);
	}

	public static long convertStringAmountToSystemUnit(String amount) {
		return new BigDecimal(amount, MathContext.DECIMAL128).multiply(CurrencyConstant.DEFAULT_SYSTEM_UNIT)
				.toBigInteger().longValueExact();
	}

	/**
	 * Convert hex string represents value to long value
	 *
	 * @param hexValue : {@link String} represents value
	 * @return A long number represents hex value or -1 if error occurred
	 */
	public static long getLongValueFromHexString(String hexValue) {
		if (hexValue.startsWith("0x")) {
			hexValue = hexValue.substring(2);
		}
		if (StringUtils.hasText(hexValue)) {
			long amount = new BigInteger(hexValue, 16).longValueExact();
			return amount;
		}
		return -1;
	}

}
