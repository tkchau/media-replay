package com.beowulf.certificate.document.certdata;

public abstract class CertificateData {
}
