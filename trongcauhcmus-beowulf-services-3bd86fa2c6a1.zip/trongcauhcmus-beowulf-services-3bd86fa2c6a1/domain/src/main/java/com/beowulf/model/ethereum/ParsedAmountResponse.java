package com.beowulf.model.ethereum;

import java.math.BigInteger;

public class ParsedAmountResponse {
    private BigInteger in_value;
    private BigInteger out_value;
    private BigInteger total_value;

    public ParsedAmountResponse() {
    }

    public ParsedAmountResponse(BigInteger in_value, BigInteger out_value, BigInteger total_value) {
        this.in_value = in_value;
        this.out_value = out_value;
        this.total_value = total_value;
    }

    public BigInteger getIn_value() {
        return in_value;
    }

    public void setIn_value(BigInteger in_value) {
        this.in_value = in_value;
    }

    public BigInteger getOut_value() {
        return out_value;
    }

    public void setOut_value(BigInteger out_value) {
        this.out_value = out_value;
    }

    public BigInteger getTotal_value() {
        return total_value;
    }

    public void setTotal_value(BigInteger total_value) {
        this.total_value = total_value;
    }
}
