package com.beowulf.model.response;

import com.beowulfchain.beowulfj.plugins.apis.database.models.Supernode;
import com.beowulfchain.beowulfj.protocol.Asset;

public class SupernodeDetailResponse {

    private long id;
    private String owner;
    private long total_missed;
    private long last_confirmed_block;
    private String signing_key;
    private String running_version;
    private String hardfork_version_vote;
    private long hardfork_time_vote;

    private long total_voters;
    private int rank;
    private long total_confirmed_blocks;
    private Asset total_block_rewards;
    private Asset total_fee_mined;
    private long total_confirmed_operations;

    public SupernodeDetailResponse() {
    }

    public SupernodeDetailResponse(Supernode supernode) {
        this.id = supernode.getId();
        this.owner = supernode.getOwner().getName();
        this.total_voters = supernode.getVotes();
        this.total_missed = supernode.getTotalMissed();
        this.last_confirmed_block = supernode.getLastConfirmedBlockNum().longValue();
        this.signing_key = supernode.getSigningKey().getAddressFromPublicKey();
        this.running_version = supernode.getRunningVersion().toString();
        this.hardfork_version_vote = supernode.getHardforkVersionVote().toString();
        this.hardfork_time_vote = supernode.getHardforkTimeVote().getDateTimeAsTimestamp();
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public long getTotal_missed() {
        return total_missed;
    }

    public void setTotal_missed(long total_missed) {
        this.total_missed = total_missed;
    }

    public long getLast_confirmed_block() {
        return last_confirmed_block;
    }

    public void setLast_confirmed_block(long last_confirmed_block) {
        this.last_confirmed_block = last_confirmed_block;
    }

    public String getSigning_key() {
        return signing_key;
    }

    public void setSigning_key(String signing_key) {
        this.signing_key = signing_key;
    }

    public String getRunning_version() {
        return running_version;
    }

    public void setRunning_version(String running_version) {
        this.running_version = running_version;
    }

    public String getHardfork_version_vote() {
        return hardfork_version_vote;
    }

    public void setHardfork_version_vote(String hardfork_version_vote) {
        this.hardfork_version_vote = hardfork_version_vote;
    }

    public long getHardfork_time_vote() {
        return hardfork_time_vote;
    }

    public void setHardfork_time_vote(long hardfork_time_vote) {
        this.hardfork_time_vote = hardfork_time_vote;
    }

    public long getTotal_voters() {
        return total_voters;
    }

    public void setTotal_voters(long total_voters) {
        this.total_voters = total_voters;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public long getTotal_confirmed_blocks() {
        return total_confirmed_blocks;
    }

    public void setTotal_confirmed_blocks(long total_confirmed_blocks) {
        this.total_confirmed_blocks = total_confirmed_blocks;
    }

    public Asset getTotal_block_rewards() {
        return total_block_rewards;
    }

    public void setTotal_block_rewards(Asset total_block_rewards) {
        this.total_block_rewards = total_block_rewards;
    }

    public Asset getTotal_fee_mined() {
        return total_fee_mined;
    }

    public void setTotal_fee_mined(Asset total_fee_mined) {
        this.total_fee_mined = total_fee_mined;
    }

    public long getTotal_confirmed_operations() {
        return total_confirmed_operations;
    }

    public void setTotal_confirmed_operations(long total_confirmed_operations) {
        this.total_confirmed_operations = total_confirmed_operations;
    }
}
