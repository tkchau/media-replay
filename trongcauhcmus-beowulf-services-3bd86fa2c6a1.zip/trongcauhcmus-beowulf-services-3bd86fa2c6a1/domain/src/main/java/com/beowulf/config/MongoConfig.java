/*
 * Copyright (c) 2018.
 * @author TrongCauTa - trongcauhcmus@gmail.com
 * @version 4/16/18 10:03 AM
 */

package com.beowulf.config;

import com.beowulf.utilities.AESEncryptor;
import com.mongodb.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.SessionSynchronization;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

import javax.net.ssl.SSLSocketFactory;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class MongoConfig.
 */

@Configuration
public class MongoConfig {
    private static final String AES_SECRET = "LZthygDCTCCwUmyN";
    private static final String AES_INIT_VECTOR = "ICnZrDxMYBuIUFzk";

    private static String DEFAULT_CONNECTION_POOL = "25";

    private String dbUserName;

    private String dbPassword;

    private String dbName;

    private String host;

    @Bean
    public MongoClient mongoClient(){
        this.dbName = GeneralConfigProperties.getInstance().getMongo_databaseName();
        this.dbUserName = GeneralConfigProperties.getInstance().getMongo_username();
        this.dbPassword = GeneralConfigProperties.getInstance().getMongo_password();
        this.host = GeneralConfigProperties.getInstance().getMongo_host();
        int connectionPool = Integer.parseInt(DEFAULT_CONNECTION_POOL);
        MongoClientOptions options = getOptions(connectionPool);
        MongoCredential credential = MongoCredential.createCredential(this.dbUserName, this.dbName,
                AESEncryptor.decrypt(AES_SECRET, AES_INIT_VECTOR, this.dbPassword).toCharArray());

        List<ServerAddress> servers = new ArrayList<ServerAddress>();
        String[] hosts = this.host.split(",");
        for (int i = 0; i < hosts.length; i++) {
            String host = hosts[i].trim();
            servers.add(new ServerAddress(host));
        }

        return new MongoClient(servers, credential, options);
    }

    @Bean
    MongoDbFactory mongoDbFactory() {
        return new SimpleMongoDbFactory(mongoClient(), this.dbName);
    }

    @Bean(name = "mongoTemplate")
    MongoTemplate mongoTemplate() {
        DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory());
        MappingMongoConverter mappingMongoConverter = new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
        // Don't save _class to mongo
//        mappingMongoConverter.setTypeMapper(new DefaultMongoTypeMapper(null));
        MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory(),mappingMongoConverter);
        mongoTemplate.setSessionSynchronization(SessionSynchronization.ON_ACTUAL_TRANSACTION);
        System.out.println("Connected to DB : " +  this.host + " " + this.dbName);

        return mongoTemplate;
    }

    @Bean(name = "transactionManager")
    MongoTransactionManager transactionManager() throws Exception {
        return new MongoTransactionManager(mongoDbFactory());
    }

    @SuppressWarnings("deprecation")
    MongoTemplate createMongoTemplate(String hosts, int connectionPool) throws UnknownHostException {

        MongoDbFactory mongoDbFactory = mongoDbFactory();
        MappingMongoConverter converter = new MappingMongoConverter(mongoDbFactory, new MongoMappingContext());
//        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory, converter);
        System.out.println("Connected to DB : " + hosts);
        return mongoTemplate;
    }

    public MongoTemplate fetchMongoTemplate(int projectId) {
        DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory());
        MappingMongoConverter mappingMongoConverter = new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
        // Don't save _class to mongo
//        mappingMongoConverter.setTypeMapper(new DefaultMongoTypeMapper(null));
        MongoDbFactory customizedDBFactory = new SimpleMongoDbFactory(mongoClient(), dbName+"_"+projectId);
        MongoTemplate mongoTemplate = new MongoTemplate(customizedDBFactory,mappingMongoConverter);
        MongoTransactionManager mongoTransactionManager = new MongoTransactionManager(customizedDBFactory);
        return mongoTemplate;
    }

    private MongoClientOptions getOptions(int connectionPool) {
        MongoClientOptions options;
        boolean sslEnable = GeneralConfigProperties.getInstance().isMongo_ssl();
        if (sslEnable) {
            options = new MongoClientOptions.Builder().cursorFinalizerEnabled(false)
                    .maxConnectionIdleTime(20000)
                    .connectionsPerHost(connectionPool)
                    .threadsAllowedToBlockForConnectionMultiplier(1000)
                    .connectTimeout(1800000)
                    .socketTimeout(1800000)
                    .sslEnabled(true)
                    .socketFactory(SSLSocketFactory.getDefault())
                    .sslInvalidHostNameAllowed(true).readPreference(ReadPreference.nearest()).build();
        } else {
            options = new MongoClientOptions.Builder().cursorFinalizerEnabled(false)
                    .maxConnectionIdleTime(20000)
                    .connectionsPerHost(connectionPool)
                    .threadsAllowedToBlockForConnectionMultiplier(1000)
                    .connectTimeout(1800000)
                    .socketTimeout(1800000)
                    .sslEnabled(false)
                    .sslInvalidHostNameAllowed(true).readPreference(ReadPreference.nearest()).build();
        }
        return options;
    }

    public static void main(String[] args) {
        System.out.println(AESEncryptor.encrypt(AES_SECRET, AES_INIT_VECTOR, ""));
    }
}
