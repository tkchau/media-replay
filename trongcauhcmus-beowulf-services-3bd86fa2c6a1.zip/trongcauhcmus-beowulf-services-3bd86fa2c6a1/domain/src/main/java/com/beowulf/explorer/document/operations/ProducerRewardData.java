package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.virtual.ProducerRewardOperation;

public class ProducerRewardData extends OperationData{
    private String producer;
    private Asset vestingShares;

    public ProducerRewardData() {
    }

    public ProducerRewardData(ProducerRewardOperation producerRewardOperation) {
        this.producer = producerRewardOperation.getProducer().getName();
        this.vestingShares = producerRewardOperation.getVestingShares();
    }

    public String getProducer() {
        return producer;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public Asset getVestingShares() {
        return vestingShares;
    }

    public void setVestingShares(Asset vestingShares) {
        this.vestingShares = vestingShares;
    }
}
