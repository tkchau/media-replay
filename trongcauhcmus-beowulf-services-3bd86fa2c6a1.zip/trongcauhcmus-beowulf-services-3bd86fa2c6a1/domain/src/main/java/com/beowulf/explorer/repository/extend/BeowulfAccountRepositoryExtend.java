package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.operations.AccountUpdateData;
import org.bson.types.ObjectId;

import java.util.List;

public interface BeowulfAccountRepositoryExtend {

    boolean increaseDataOfSupernode(String supernodeName, long blockReward, long totalFee, long totalOperations);

    List<BeowulfAccount> findCreatedAccount(ObjectId startId, int limit, String creator, String direction);

    boolean increaseAccountId(ObjectId id, long accountId);

    List<BeowulfAccount> findValidAccounts(ObjectId startId, int limit);

    List<BeowulfAccount> findAccountID(int accountId, int limit);

    void updateAccountId(String name, long accountId);

    boolean removeAccountByAccountName(String accountName);

    List<BeowulfAccount> getBeowulfAccountByPaging(ObjectId start_id, int limit, String direction);

    List<BeowulfAccount> getAccountMultisigByPaging(ObjectId start_id, int limit, String direction, String multisig);

    boolean decreaseDataOfSupernode(String supernodeName, long blockReward, long totalFee, long totalOperations);

    boolean updateAccountInfo(AccountUpdateData accountUpdateOperation);
}
