package com.beowulf.utilities;

import com.beowulf.model.chart.record.ChartDailyRecord;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;

public class CSVUtil {

    private static String TAG = CSVUtil.class.getName();

    private static final char DEFAULT_SEPARATOR = '\n';

    private static final String CSV_EXTENSION = ".csv";

    public static void validateCSVHeaders(CSVParser parser, String filePath, String[] expectedHeaders) throws IllegalArgumentException {

        String[] headers = getHeaderMapAsArray(parser);

        if (headers.length != expectedHeaders.length) {
            throw new IllegalArgumentException("Mismatch in number of CSV columns in " + filePath + " expected " + expectedHeaders.length + " but found " + headers.length);
        }

        for (int i = 0; i < expectedHeaders.length; i++) {
            String expectedHeader = expectedHeaders[i];
            String actualHeader = headers[i];

            if (!expectedHeader.equals(actualHeader)) {
                throw new IllegalArgumentException("Column mismatch at column " + i + ": expected [" + expectedHeader + "] but found [" + actualHeader + "]");
            }
        }
    }

    public static String[] getHeaderMapAsArray(CSVParser parser) {

        Map<String, Integer> headerMap = parser.getHeaderMap();

        if (headerMap == null) {
            throw new RuntimeException("Null header map returned from CSV file");
        }

        String[] ret = new String[headerMap.size()];

        for (String col : headerMap.keySet()) {
            Integer colIndex = headerMap.get(col);
            ret[colIndex] = col;
        }

        return ret;
    }

    /**
     * Generate new file CSV with Headers if not exist
     *
     * @param filePath Absolute file csv path.
     * @param headers  Headers of csv file.
     */
    public static void generateCSVFile(String filePath, String[] headers) {

        if (!filePath.endsWith(CSV_EXTENSION)) {
            filePath = filePath + CSV_EXTENSION;
        }

        File csvFile = new File(filePath);
        CSVPrinter csvPrinter = null;

        try {
            if (csvFile.createNewFile()) {
                csvPrinter = CSVFormat.DEFAULT.withHeader(headers).print(new FileWriter(csvFile));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (csvPrinter != null) {
                    csvPrinter.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Update new record into file CSV.
     *
     * @param filePath         Absolute file csv path.
     * @param dailyRecord      Chart daily record.
     * @param firstRowIsHeader If first line of csv file is header?
     * @return Successful handle append or not?
     */
    public static boolean appendCSV(String filePath, ChartDailyRecord dailyRecord, boolean firstRowIsHeader) {

        CSVFormat csvFormat;
        if (firstRowIsHeader) {
            csvFormat = CSVFormat.DEFAULT
                    .withRecordSeparator(DEFAULT_SEPARATOR)
                    .withIgnoreHeaderCase();
        } else {
            csvFormat = CSVFormat.DEFAULT
                    .withRecordSeparator(DEFAULT_SEPARATOR);
        }

        BufferedWriter fWriter = null;
        CSVPrinter csvPrinter = null;

        try {
            // Create file writer.
            fWriter = Files.newBufferedWriter(
                    Paths.get(filePath),
                    StandardOpenOption.APPEND);
            // Create CSVPrinter
            csvPrinter = new CSVPrinter(fWriter, csvFormat);
            // Update new record
            csvPrinter.printRecord(dailyRecord.valueAsList());

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (fWriter != null) {
                    fWriter.flush();
                    fWriter.close();
                }
                if (csvPrinter != null) {
                    csvPrinter.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
