package com.beowulf.account.repository.extend;

import com.beowulf.account.documents.ApiKey;
import com.mongodb.client.ClientSession;

public interface ApiKeyRepositoryExtend {
    boolean decreaseCounting(ClientSession session, ApiKey apiKey) throws Exception;

    boolean increaseCounting(ClientSession session, ApiKey apiKey) throws Exception;

    boolean saveOrOverWrite(ClientSession session, ApiKey apiKey) throws Exception;
}
