package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfAuthReferences;
import com.beowulf.explorer.repository.extend.BeowulfAuthReferencesRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface BeowulfAuthReferencesRepository extends MongoRepository<BeowulfAuthReferences, ObjectId>, BeowulfAuthReferencesRepositoryExtend {

    @Query(value = "{'name' : ?0}")
    List<BeowulfAuthReferences> findBeowulfAccountReferencesByName(String name);

}
