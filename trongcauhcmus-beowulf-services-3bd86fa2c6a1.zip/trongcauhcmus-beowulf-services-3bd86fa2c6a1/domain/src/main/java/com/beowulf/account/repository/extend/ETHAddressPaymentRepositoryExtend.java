package com.beowulf.account.repository.extend;

public interface ETHAddressPaymentRepositoryExtend {

    void updateStatus(String address, int status_address);

}
