package com.beowulf.annotations;

import com.beowulf.validator.RequestThrottlingValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

@Target({ElementType.METHOD, ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = RequestThrottlingValidator.class)
@Documented
public @interface RequestThottlingValidated {
    String message() default "too many requests";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    int rate() default 5;

    TimeUnit timeUnit() default TimeUnit.SECONDS;
}
