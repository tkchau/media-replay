package com.beowulf.model.ethereum.multisig;


import com.beowulf.utilities.Numeric;
import org.spongycastle.pqc.math.linearalgebra.ByteUtils;

import java.math.BigInteger;

public class Erc20TxnInfo extends TxnInfo {
    private String tokenAddress;

    public Erc20TxnInfo() {
    }

    public Erc20TxnInfo(String receiver, BigInteger value, String tokenAddress, BigInteger expireTime, BigInteger sequenceId) {
        super(receiver, value, expireTime, sequenceId);
        setTokenAddress(tokenAddress);
    }

    public byte[] serialize() {
        byte[] prefix = "ERC20".getBytes();
        if (receiver.startsWith("0x")) {
            receiver = receiver.substring(2);
        }
        if (tokenAddress.startsWith("0x")) {
            tokenAddress = tokenAddress.substring(2);
        }
        // decode address to 20 bytes
        byte[] receiverByte = ByteUtils.fromHexString(receiver);
        byte[] tokenAddressByte = ByteUtils.fromHexString(tokenAddress);
        // uint need to padding data enough 32 bytes
        return Numeric.concat(prefix,
                receiverByte,
                Numeric.paddingUint256(value.toByteArray()),
                tokenAddressByte,
                Numeric.paddingUint256(expireTime.toByteArray()),
                Numeric.paddingUint256(sequenceId.toByteArray()));
    }

    public String getTokenAddress() {
        return tokenAddress;
    }

    public void setTokenAddress(String tokenAddress) {
        this.tokenAddress = tokenAddress;
    }
}
