package com.beowulf.hook.repository.extend;

public interface BeowulfAccountWebhookRepositoryExtend {
    void removeByAccountName(String account_name);
}
