package com.beowulf.certificate.repository.extend;

import com.beowulf.certificate.document.CertNodeInfo;

public interface CertNodeCrawlingInfoRepositoryExtend {
    void updateLastCrawl(String nodeUrl, long blockNum);

    boolean updateLastCrawlOnDestroy(String nodeUrl, long blockNum);

    void updateLastIrrversibleCrawl(String nodeUrl, long blockNum);

    boolean updateLastIrreversibleCrawlOnDestroy(String nodeUrl, long blockNum);

    long getLastCrawlingBlock(long startBlock, String nodeUrl);

    long getLastCrawlingIrreversibleBlock(long startBlock, String nodeUrl);

    CertNodeInfo findNodeInfoByNode_url(String node_url);
}
