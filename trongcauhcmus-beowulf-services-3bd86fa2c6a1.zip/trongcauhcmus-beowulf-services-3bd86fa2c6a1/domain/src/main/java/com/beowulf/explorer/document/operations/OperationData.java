package com.beowulf.explorer.document.operations;

public abstract class OperationData {

}
