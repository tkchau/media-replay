package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.operations.*;
import com.beowulfchain.beowulfj.enums.OperationType;
import com.beowulfchain.beowulfj.protocol.operations.*;
import com.beowulfchain.beowulfj.protocol.operations.virtual.FillVestingWithdrawOperation;
import com.beowulfchain.beowulfj.protocol.operations.virtual.HardforkOperation;
import com.beowulfchain.beowulfj.protocol.operations.virtual.ProducerRewardOperation;
import com.beowulfchain.beowulfj.protocol.operations.virtual.ShutdownSupernodeOperation;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.OPERATIONS)
@CompoundIndexes({
        @CompoundIndex(name = "transfer_asset", def = "{'operation.amount.name': 1}")
})
public class BeowulfOperation {
    @Id
    private ObjectId id;

    @Indexed(unique = true)
    private ObjectId bc_id;

    // TODO: 26/12/2019 Consider define operation_id = block_hex + tx_id + operation_index
    @Indexed(unique = true)
    private String operation_id;

    @Indexed
    private OperationType type;

    private String transaction_id;
    private int index;
    private OperationData operation;

    @Indexed
    private String relate_account_1;

    @Indexed
    private String relate_account_2;

    public BeowulfOperation() {

    }

    public BeowulfOperation(String transaction_id, int index, OperationType type, OperationData operation, String relate_account_1, String relate_account_2) {
        this.operation_id = String.format("%s:%s", transaction_id, index);
        this.type = type;
        this.transaction_id = transaction_id;
        this.index = index;
        this.operation = operation;
        if (relate_account_1 != null) {
            this.setRelate_account_1(relate_account_1);
            if (relate_account_2 != null && !relate_account_2.equals(relate_account_1)) {
                this.setRelate_account_2(relate_account_2);
            }
        }
    }

    /**
     * Parsing data of operation in Beowulf Block-chain into Crawling Operation document.
     *
     * @param operation     The Operation in Transaction.
     * @param transactionId The transaction id of Operation.
     * @param index         The order of Operation in Transaction.
     * @return The document of Operation.
     * @throws IllegalArgumentException if invalid input operation type.
     */
    public static BeowulfOperation parseOperation(Operation operation, String transactionId, int index) {
        OperationData operationData;
        OperationType operationType;
        String relateAccount1 = null, relateAccount2 = null;

        if (operation instanceof AccountCreateOperation) {
            AccountCreateOperation accountCreateOperation = (AccountCreateOperation) operation;
            operationData = new AccountCreateData(accountCreateOperation);
            operationType = OperationType.ACCOUNT_CREATE_OPERATION;
            relateAccount1 = accountCreateOperation.getCreator().getName();
            relateAccount2 = accountCreateOperation.getNewAccountName().getName();
        } else if (operation instanceof TransferOperation) {
            TransferOperation transferOperation = (TransferOperation) operation;
            operationData = new TransferData(transferOperation);
            operationType = OperationType.TRANSFER_OPERATION;
            relateAccount1 = transferOperation.getFrom().getName();
            relateAccount2 = transferOperation.getTo().getName();
        } else if (operation instanceof TransferToVestingOperation) {
            TransferToVestingOperation transferToVestingOperation = (TransferToVestingOperation) operation;
            operationData = new TransferToVestingData(transferToVestingOperation);
            operationType = OperationType.TRANSFER_TO_VESTING_OPERATION;
            relateAccount1 = transferToVestingOperation.getFrom().getName();
            relateAccount2 = transferToVestingOperation.getTo().getName();
        } else if (operation instanceof WithdrawVestingOperation) {
            WithdrawVestingOperation withdrawVestingOperation = (WithdrawVestingOperation) operation;
            operationData = new WithdrawVestingData(withdrawVestingOperation);
            operationType = OperationType.WITHDRAW_VESTING_OPERATION;
            relateAccount1 = withdrawVestingOperation.getAccount().getName();
        } else if (operation instanceof AccountUpdateOperation) {
            AccountUpdateOperation accountUpdateOperation = (AccountUpdateOperation) operation;
            operationData = new AccountUpdateData(accountUpdateOperation);
            operationType = OperationType.ACCOUNT_UPDATE_OPERATION;
            relateAccount1 = accountUpdateOperation.getAccount().getName();
        } else if (operation instanceof SupernodeUpdateOperation) {
            SupernodeUpdateOperation supernodeUpdateOperation = (SupernodeUpdateOperation) operation;
            operationData = new SupernodeUpdateData(supernodeUpdateOperation);
            operationType = OperationType.SUPERNODE_UPDATE_OPERATION;
            relateAccount1 = supernodeUpdateOperation.getOwner().getName();
        } else if (operation instanceof AccountSupernodeVoteOperation) {
            AccountSupernodeVoteOperation accountSupernodeVoteOperation = (AccountSupernodeVoteOperation) operation;
            operationData = new AccountSupernodeVoteData(accountSupernodeVoteOperation);
            operationType = OperationType.ACCOUNT_SUPERNODE_VOTE_OPERATION;
            relateAccount1 = accountSupernodeVoteOperation.getAccount().getName();
            relateAccount2 = accountSupernodeVoteOperation.getSupernode().getName();
        } else if (operation instanceof SmtCreateOperation) {
            SmtCreateOperation smtCreateOperation = (SmtCreateOperation) operation;
            operationData = new SmtCreateData(smtCreateOperation);
            operationType = OperationType.SMT_CREATE_OPERATION;
            relateAccount1 = smtCreateOperation.getCreator().getName();
            relateAccount2 = smtCreateOperation.getControlAccount().getName();
        } else if (operation instanceof FillVestingWithdrawOperation) {
            FillVestingWithdrawOperation fillVestingWithdrawOperation = (FillVestingWithdrawOperation) operation;
            operationData = new FillVestingWithdrawData(fillVestingWithdrawOperation);
            operationType = OperationType.FILL_VESTING_WITHDRAW_OPERATION;
            relateAccount1 = fillVestingWithdrawOperation.getFromAccount().getName();
            relateAccount2 = fillVestingWithdrawOperation.getToAccount().getName();
        } else if (operation instanceof ShutdownSupernodeOperation) {
            ShutdownSupernodeOperation shutdownSupernodeOperation = (ShutdownSupernodeOperation) operation;
            operationData = new ShutdownSupernodeData(shutdownSupernodeOperation);
            operationType = OperationType.SHUTDOWN_SUPERNODE_OPERATION;
            relateAccount1 = shutdownSupernodeOperation.getOwner().getName();
        } else if (operation instanceof HardforkOperation) {
            HardforkOperation hardforkOperation = (HardforkOperation) operation;
            operationData = new HardforkData(hardforkOperation);
            operationType = OperationType.HARDFORK_OPERATION;
        } else if (operation instanceof ProducerRewardOperation) {
            ProducerRewardOperation producerRewardOperation = (ProducerRewardOperation) operation;
            operationData = new ProducerRewardData(producerRewardOperation);
            operationType = OperationType.PRODUCER_REWARD_OPERATION;
            relateAccount1 = producerRewardOperation.getProducer().getName();
        } else {
            throw new IllegalArgumentException("Invalid Operation type!");
        }

        return new BeowulfOperation(transactionId, index, operationType, operationData, relateAccount1, relateAccount2);
    }

    public String getOperation_id() {
        return operation_id;
    }

    public void setOperation_id(String operation_id) {
        this.operation_id = operation_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public OperationType getType() {
        return type;
    }

    public void setType(OperationType type) {
        this.type = type;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public OperationData getOperation() {
        return operation;
    }

    public void setOperation(OperationData operation) {
        this.operation = operation;
    }

    public String getRelate_account_1() {
        return relate_account_1;
    }

    public void setRelate_account_1(String relate_account_1) {
        this.relate_account_1 = relate_account_1;
    }

    public String getRelate_account_2() {
        return relate_account_2;
    }

    public void setRelate_account_2(String relate_account_2) {
        this.relate_account_2 = relate_account_2;
    }

    public ObjectId getBc_id() {
        return bc_id;
    }

    public void setBc_id(ObjectId bc_id) {
        this.bc_id = bc_id;
    }
}
