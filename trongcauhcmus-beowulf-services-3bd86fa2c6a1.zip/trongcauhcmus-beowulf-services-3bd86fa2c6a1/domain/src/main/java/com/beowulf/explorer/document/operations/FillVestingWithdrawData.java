package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.virtual.FillVestingWithdrawOperation;

public class FillVestingWithdrawData extends OperationData{
    private String fromAccount;
    private String toAccount;
    private Asset withdrawn;
    private Asset deposited;

    public FillVestingWithdrawData() {
    }

    public FillVestingWithdrawData(FillVestingWithdrawOperation fillVestingWithdrawOperation) {
        this.fromAccount = fillVestingWithdrawOperation.getFromAccount().getName();
        this.toAccount = fillVestingWithdrawOperation.getToAccount().getName();
        this.withdrawn = fillVestingWithdrawOperation.getWithdrawn();
        this.deposited = fillVestingWithdrawOperation.getDeposited();
    }

    public String getFromAccount() {
        return fromAccount;
    }

    public void setFromAccount(String fromAccount) {
        this.fromAccount = fromAccount;
    }

    public String getToAccount() {
        return toAccount;
    }

    public void setToAccount(String toAccount) {
        this.toAccount = toAccount;
    }

    public Asset getWithdrawn() {
        return withdrawn;
    }

    public void setWithdrawn(Asset withdrawn) {
        this.withdrawn = withdrawn;
    }

    public Asset getDeposited() {
        return deposited;
    }

    public void setDeposited(Asset deposited) {
        this.deposited = deposited;
    }
}
