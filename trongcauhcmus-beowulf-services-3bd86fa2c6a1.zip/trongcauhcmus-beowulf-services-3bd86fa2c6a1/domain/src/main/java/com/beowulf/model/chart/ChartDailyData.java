package com.beowulf.model.chart;

public class ChartDailyData {

    private Long date;

    private Integer data;

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }
}
