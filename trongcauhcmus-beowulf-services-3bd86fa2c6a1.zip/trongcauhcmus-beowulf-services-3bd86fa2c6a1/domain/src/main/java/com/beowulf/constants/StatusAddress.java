package com.beowulf.constants;

public enum StatusAddress {
    FREE(0),
    WAITING_PAYMENT(1),
    CHECKING_PAYMENT(2),
    MOVING_FUND(3);
    private int status_address;

    StatusAddress(int status_address) {
        this.status_address = status_address;
    }

    public int getStatus_address() {
        return status_address;
    }

}
