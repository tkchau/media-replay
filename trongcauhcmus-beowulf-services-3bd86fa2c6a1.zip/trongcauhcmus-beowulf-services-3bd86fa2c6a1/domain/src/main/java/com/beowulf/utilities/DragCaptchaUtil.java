/**
 * Copyright 2018 by Krypto Inc. (http://kryptono.exchange)
 */
package com.beowulf.utilities;

import com.beowulf.constants.DragVerify;
import com.beowulf.model.DragToken;
import com.beowulf.model.response.DragResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class DragCaptchaUtil {
    private static final String TAG = DragCaptchaUtil.class.getName();

    static {
        try {
            ImageIO.scanForPlugins();
        } catch (Exception e) {
            LoggerUtil.exception("DragCaptchaUtil", e, true);
        }
    }

    private static CustomExpiringMap<String, DragToken> dragTokenStore = new CustomExpiringMap<>(100, 30, TimeUnit.SECONDS);

    public static DragResponse generateDragResponse() {
        try {
            ApplicationContext appContext = new ClassPathXmlApplicationContext();
            Random rand = new Random();

            int backGroundNo = rand.nextInt(DragVerify.MAX_BACKGROUND_NO - 1) + 1;
            BufferedImage puzzle = ImageIO.read(appContext.getResource(DragVerify.PUZZLE_PATH).getInputStream());
            // using for svg
//            InputStream path = appContext.getResource(DragVerify.PUZZLE_PATH).getInputStream();
//            String puzzle = IOUtils.toString(path);
            BufferedImage background = ImageIO.read(appContext.getResource(DragVerify.BACKGROUND_PREFIX_PATH + backGroundNo + ".png").getInputStream());
            BufferedImage overlay = ImageIO.read(appContext.getResource(DragVerify.PUZZLE_HIDE_PATH).getInputStream());

            BufferedImage combined = new BufferedImage(background.getWidth(), background.getHeight(), BufferedImage.TYPE_INT_ARGB);
            DragResponse dragResponse = new DragResponse();

            int randY = rand.nextInt(background.getHeight() - overlay.getHeight() - 2 * DragVerify.MARGIN_Y) + DragVerify.MARGIN_Y;

            dragResponse.setWidth(background.getWidth());
            dragResponse.setHeight(background.getHeight());
            dragResponse.setY(randY);
            dragResponse.setPuzzle_width(puzzle.getWidth());
            dragResponse.setPuzzle_height(puzzle.getHeight());
            dragResponse.setPuzzle_data(Common.encodeToString(puzzle, "PNG"));

            // using for svg
//            dragResponse.setPuzzle_width(DragVerify.PUZZLE_BACKGROUND_WIDTH);
//            dragResponse.setPuzzle_height(DragVerify.PUZZLE_BACKGROUND_HEIGHT);
//            dragResponse.setPuzzle_data(puzzle);
            int x = rand.nextInt(background.getWidth() - overlay.getWidth() - 2 * DragVerify.MARGIN_X) + DragVerify.MARGIN_X;
            System.out.println(x);
            Graphics g = combined.getGraphics();
            g.drawImage(background, 0, 0, null);
            g.drawImage(overlay, x, dragResponse.getY(), null);
            String imageData = Common.encodeToString(combined, "PNG");
            dragResponse.setBackground_data(imageData);
            dragResponse.setToken(UUID.randomUUID().toString());
            System.out.println("print token and x: ");
            System.out.println(dragResponse.getToken() + "\t" + x);

            dragTokenStore.put(dragResponse.getToken(), new DragToken(x, false));
            return dragResponse;
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return null;
    }

    public static boolean activateDragToken(String token, int x) {
        try {
            DragToken dragToken = dragTokenStore.get(token, null);
            if (dragToken != null) {
                if (Math.abs(x - dragToken.getX()) <= DragVerify.VALID_RANGE) {
                    dragToken.setIs_valid(true);
                    dragTokenStore.put(token, dragToken);
                    return true;
                } else {
                    dragTokenStore.remove(token);
                }
            }
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return false;
    }

    public static boolean verifyDragToken(String token) {
        try {
            DragToken dragToken = dragTokenStore.get(token, null);
            if (dragToken != null) {
                if (dragToken.isIs_valid())
                    dragTokenStore.remove(token);
                return dragToken.isIs_valid();
            }
        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return false;
    }
}
