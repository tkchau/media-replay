package com.beowulf.account.repository;

import com.beowulf.account.documents.ApiKeyLevel;
import com.beowulf.account.repository.extend.ApiKeyLevelRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface ApiKeyLevelRepository extends MongoRepository<ApiKeyLevel, ObjectId>,
        ApiKeyLevelRepositoryExtend {
    @Query(value = "{'api_key_level' : ?0}")
    public ApiKeyLevel findApiKeyLevelByApiKeyLevel(String apiKeyLevel);
}
