package com.beowulf.validator;

import com.beowulf.annotations.DragCaptchaValidated;
import com.beowulf.utilities.DragCaptchaUtil;
import com.beowulf.utilities.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DragCaptchaValidator implements ConstraintValidator<DragCaptchaValidated, Object> {

    private String headerName;
    private String bypass;

    @Override
    public void initialize(DragCaptchaValidated dragCaptchaValidated) {
        headerName = dragCaptchaValidated.name();
        bypass = dragCaptchaValidated.bypass();
    }

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext constraintValidatorContext) {
        if (target == null) {
            return false;
        }
        if (target instanceof HttpServletRequest) {
            String captcha = ((HttpServletRequest) target).getHeader(headerName);
            return this.isValid(captcha, constraintValidatorContext);
        } else if (!(target instanceof String))
            return false;
        else {
            String captcha = (String) target;
            if (StringUtils.isEmpty(captcha))
                return false;

            if (captcha.equals(bypass)) {
                return true;
            }

            return DragCaptchaUtil.verifyDragToken((String) target);
        }
    }
}
