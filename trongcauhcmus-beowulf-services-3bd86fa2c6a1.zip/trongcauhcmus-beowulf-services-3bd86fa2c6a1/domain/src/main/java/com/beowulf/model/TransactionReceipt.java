package com.beowulf.model;

import com.beowulf.model.request.HttpRequestObject;
import com.beowulf.utilities.GsonSingleton;
import org.bson.types.ObjectId;
import org.spongycastle.pqc.math.linearalgebra.ByteUtils;

import java.security.MessageDigest;

public class TransactionReceipt extends HttpRequestObject {
    protected ObjectId id;
    protected String url;
    protected int call_times;
    protected long last_call;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getCall_times() {
        return call_times;
    }

    public void setCall_times(int call_times) {
        this.call_times = call_times;
    }

    public long getLast_call() {
        return last_call;
    }

    public void setLast_call(long last_call) {
        this.last_call = last_call;
    }

    public String getActionId(){
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(this.toString().getBytes());
            return ByteUtils.toHexString(messageDigest.digest());
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String toString() {
        return GsonSingleton.getInstance().toJson(this);
    }
}
