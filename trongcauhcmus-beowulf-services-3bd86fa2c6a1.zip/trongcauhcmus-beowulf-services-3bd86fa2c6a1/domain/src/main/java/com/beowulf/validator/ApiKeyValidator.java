package com.beowulf.validator;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.annotations.ApiKeyValidated;
import com.beowulf.constants.ApiKeyStatus;
import com.beowulf.exception.ServiceException;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.springframework.lang.Nullable;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ApiKeyValidator implements ConstraintValidator<ApiKeyValidated, Object> {
    private ServiceException exception;

    @Override
    public void initialize(ApiKeyValidated apiKeyValidated) {
        exception = ServiceExceptionUtils.unauthorization();
    }

    @Override
    public boolean isValid(@Nullable Object target, ConstraintValidatorContext constraintValidatorContext) {
        try {
            //disable existing violation message
            constraintValidatorContext.disableDefaultConstraintViolation();

            if (target == null) {
                return false;
            }

            if (!(target instanceof ApiKey)) {
                return false;
            }

            ApiKey apikey = ((ApiKey) target);
            if (!ApiKeyStatus.ENABLE.equals(apikey.getStatus())) {
                exception = ServiceExceptionUtils.apikeyIsDisable();
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            String message = GsonSingleton.getInstance().toJson(exception.generateResponse());
            constraintValidatorContext.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        }
    }
}
