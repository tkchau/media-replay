package com.beowulf.hook.repository.impl;

import com.beowulf.hook.document.BeowulfAccountWebhook;
import com.beowulf.hook.repository.extend.BeowulfAccountWebhookRepositoryExtend;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.mongodb.client.result.DeleteResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class BeowulfAccountWebhookRepositoryImpl implements BeowulfAccountWebhookRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void removeByAccountName(String account_name) {
        Query query = new Query();
        query.addCriteria(Criteria.where("account_name").is(account_name));
        DeleteResult result = mongoTemplate.remove(query, BeowulfAccountWebhook.class);
        if (result.getDeletedCount() == 0) {
            throw ServiceExceptionUtils.accountNotFound();
        }
    }
}
