package com.beowulf.model.request;

public class ListBeowulfAccountPagingRequest extends ListObjectsPagingRequest {
    private String multisig;

    public String getMultisig() {
        return multisig;
    }

    public void setMultisig(String multisig) {
        this.multisig = multisig;
    }
}
