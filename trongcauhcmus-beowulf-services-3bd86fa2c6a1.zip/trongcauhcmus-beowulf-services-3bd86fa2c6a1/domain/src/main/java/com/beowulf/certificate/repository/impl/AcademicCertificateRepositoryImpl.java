package com.beowulf.certificate.repository.impl;

import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.document.certdata.CertificateType;
import com.beowulf.certificate.repository.extend.AcademicCertificateRepositoryExtend;
import com.beowulf.constants.CollectionName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;

import java.util.List;


public class AcademicCertificateRepositoryImpl implements AcademicCertificateRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public BeowulfAcademicCertificate findAcademicCertificateBySerialNum(String serialNum) {
        Pair<String, Object> filterSerialNum = Pair.of(CertificateType.ACADEMIC_CERT_KEY_ID, serialNum);
        return findCertificateBy(filterSerialNum);
    }

    @Override
    public List<BeowulfAcademicCertificate> findAcademicCertificateByStudentId(String studentId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(CertificateType.ACADEMIC_CERT_KEY_STUDENT_ID).is(studentId));
        return mongoTemplate.find(query, BeowulfAcademicCertificate.class, CollectionName.ACADEMIC_CERTIFICATES);
    }

    private BeowulfAcademicCertificate findCertificateBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        return mongoTemplate.findOne(query, BeowulfAcademicCertificate.class, CollectionName.ACADEMIC_CERTIFICATES);
    }

}
