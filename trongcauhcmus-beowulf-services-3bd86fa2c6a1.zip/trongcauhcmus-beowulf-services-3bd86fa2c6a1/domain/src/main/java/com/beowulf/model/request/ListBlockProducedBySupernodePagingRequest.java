package com.beowulf.model.request;

public class ListBlockProducedBySupernodePagingRequest extends ListObjectsPagingRequest {

	private String supernode_name;

	public String getSupernode_name() {
		return supernode_name;
	}

	public void setSupernode_name(String supernode_name) {
		this.supernode_name = supernode_name;
	}
}
