package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.extensions.ExtensionData;
import com.beowulf.explorer.document.extensions.JsonExtensionData;
import com.beowulfchain.beowulfj.base.models.FutureExtensions;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.protocol.extensions.JsonExtension;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = CollectionName.TRANSACTIONS)
public class BeowulfTransaction {

    @Id
    private ObjectId id;

	@Indexed(unique = true)
	private ObjectId bc_id;

	@Indexed
	private String block_id;

    @Indexed(unique = true)
    private String transaction_id;

    private long ref_block_num;
    private long ref_block_prefix;
    private String expiration;
    private List<ExtensionData> extensions = new ArrayList<>();
    private long created_time;
    private List<String> signatures = new ArrayList<>();
    private long transaction_num;
    private long transaction_fee;
    private String status;

	public BeowulfTransaction() {
	}

	public BeowulfTransaction(CompletedTransaction transaction, String block_id, long transaction_fee) {
		this.id = new ObjectId();
		this.transaction_id = transaction.getTransactionId().toString();
		this.block_id = block_id;
		this.ref_block_num = transaction.getRefBlockNum().longValue();
		this.expiration = transaction.getExpirationDate().getDateTime();
        this.created_time = transaction.getCreatedTimeAsMillis();
		this.signatures = transaction.getSignatures();
		this.transaction_num = transaction.getTransactionNum();
		this.transaction_fee = transaction_fee;
		this.status = transaction.getStatus();
        for (FutureExtensions extension : transaction.getExtensions()) {
            if (extension instanceof JsonExtension) {
                JsonExtensionData data = new JsonExtensionData((JsonExtension) extension);
                this.extensions.add(data);
            }
        }
	}

    public String getBlock_id() {
        return block_id;
    }

    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public long getRef_block_num() {
		return ref_block_num;
	}

	public void setRef_block_num(long ref_block_num) {
		this.ref_block_num = ref_block_num;
	}

	public long getRef_block_prefix() {
		return ref_block_prefix;
	}

	public void setRef_block_prefix(long ref_block_prefix) {
		this.ref_block_prefix = ref_block_prefix;
	}

	public String getExpiration() {
		return expiration;
	}

	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}

	public List<ExtensionData> getExtensions() {
		return extensions;
	}

	public void setExtensions(List<ExtensionData> extensions) {
		this.extensions = extensions;
	}

	public long getCreated_time() {
		return created_time;
	}

	public void setCreated_time(long created_time) {
		this.created_time = created_time;
	}

	public List<String> getSignatures() {
		return signatures;
	}

	public void setSignatures(ArrayList<String> signatures) {
		this.signatures = signatures;
	}

	public void setSignatures(List<String> signatures) {
		this.signatures = signatures;
	}

	public long getTransaction_num() {
		return transaction_num;
	}

	public void setTransaction_num(long transaction_num) {
		this.transaction_num = transaction_num;
	}

	public long getTransaction_fee() {
		return transaction_fee;
	}

	public void setTransaction_fee(long transaction_fee) {
		this.transaction_fee = transaction_fee;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ObjectId getBc_id() {
		return bc_id;
	}

	public void setBc_id(ObjectId bc_id) {
		this.bc_id = bc_id;
	}
}
