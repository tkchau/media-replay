package com.beowulf.config;

import com.beowulf.config.document.RedisServerConfig;
import com.beowulf.config.repository.ConfigurationRepository;
import com.beowulf.constants.RedisConstant;
import com.beowulf.handler.RedisKeyExpireHandler;
import com.beowulf.utilities.LoggerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.PreDestroy;
import java.util.Collections;

@Component
public class RedisClient {
    private static final String TAG = RedisClient.class.getName();
    private static final String REDIS_CONFIG_KEY = "redis_config";

    private RedisServerConfig config;
    private JedisPoolConfig poolConfig;
    private JedisPool jedisPool;

    private static RedisClient instance;
    private static ConfigurationRepository configurationRepository;

    @Autowired
    public RedisClient(ConfigurationRepository configurationRepository) {
        instance = this;
        RedisClient.configurationRepository = configurationRepository;
        init();
    }

    @PreDestroy
    public void onDestroy() {
        try {
            if (instance != null && instance.jedisPool != null)
                instance.jedisPool.destroy();
        } catch (Exception e) {
        }
    }

    private JedisPoolConfig buildConfig() {
        final JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(this.config.getMax_pool());
        config.setMaxIdle(10);
        config.setMinIdle(1);
        config.setMaxWaitMillis(10000);
        return config;
    }

    private void init() {
        try {
            LoggerUtil.i(this, "Init RedisClient");
            config = configurationRepository.findConfigByKey(REDIS_CONFIG_KEY, RedisServerConfig.class);

            if (config == null) {
                config = new RedisServerConfig();
                configurationRepository.save(config);
            }
            poolConfig = buildConfig();
            jedisPool = new JedisPool(poolConfig, config.getHost(), config.getPort(), 10000);
            LoggerUtil.i(this, "Init RedisClient successfully with host=" + config.getHost() + " and port=" + config.getPort());

        } catch (Exception e) {
            LoggerUtil.e(this, "Init RedisClient failed with host=" + config.getHost() + " and port=" + config.getPort());
            e.printStackTrace();
        }
    }

    public static Jedis getClient() {
        try {
            if (instance != null && instance.jedisPool != null)
                return instance.jedisPool.getResource();
        } catch (Exception e) {
            LoggerUtil.e(TAG, "Could not get resource from the pool - " + e.getMessage() + "\n");
        }
        return null;
    }

    @Bean(name = "jedisConnectionFactory")
    public JedisConnectionFactory jedisConnectionFactory() {
        JedisConnectionFactory connectionFactory = new JedisConnectionFactory();
        connectionFactory.setHostName(config.getHost());
        connectionFactory.setPort(config.getPort());
        connectionFactory.setTimeout(10000);
        connectionFactory.setPoolConfig(buildConfig());
        return connectionFactory;
    }

    @Bean(name = "redisMessageListener")
    public MessageListenerAdapter redisMessageListener(RedisKeyExpireHandler redisKeyExpireHandler) {
        return new MessageListenerAdapter(redisKeyExpireHandler);
    }

    @Bean(name = "redisMessageListenerContainer")
    public RedisMessageListenerContainer redisMessageListenerContainer(JedisConnectionFactory jedisConnectionFactory, MessageListenerAdapter redisMessageListener) {
        LoggerUtil.i(TAG, "create bean: redisMessageListenerContainer");
        RedisMessageListenerContainer listenerContainer = new RedisMessageListenerContainer();
        listenerContainer.setConnectionFactory(jedisConnectionFactory);
        listenerContainer.setMessageListeners(Collections.singletonMap(redisMessageListener, Collections.singletonList(new PatternTopic(RedisConstant.TOPIC_KEY_EXPIRED))));
        return listenerContainer;
    }
}
