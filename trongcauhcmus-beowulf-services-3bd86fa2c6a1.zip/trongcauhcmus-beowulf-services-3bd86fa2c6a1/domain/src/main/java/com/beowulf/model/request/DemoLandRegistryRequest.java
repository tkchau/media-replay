package com.beowulf.model.request;

import com.beowulf.annotations.DateTimeValidated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class DemoLandRegistryRequest {
    @NotNull
    @NotEmpty(message = "Please provide an id")
    @Size(max = 10, message = "length of id must less than equal 10")
    private String cert_id;

    @NotNull
    @NotEmpty(message = "Please provide land owner name")
    @Size(max = 32, message = "length of owner name must less than equal 32")
    private List<String> owners;

    @NotNull
    @NotEmpty(message = "Please provide land id")
    @Size(max = 16, message = "length of land id must less than equal 16")
    private String land_id;

    @NotNull
    @NotEmpty(message = "Please provide map id")
    @Size(max = 16, message = "length of map id must less than equal 16")
    private String map_id;

    @NotNull
    @DateTimeValidated
    private String issue_date;

    @NotNull
    @NotEmpty(message = "Please provide address")
    @Size(max = 50, message = "length of address id must less than equal 50")
    private String address;

    @NotNull
    @NotEmpty(message = "Please provide area")
    @Size(max = 50, message = "length of area id must less than equal 50")
    private String area;

    @NotNull
    @NotEmpty(message = "Please provide form of use")
    @Size(max = 20, message = "length of form of use must less than equal 20")
    private String form_of_use;

    @NotNull
    @NotEmpty(message = "Please provide purpose of use")
    @Size(max = 20, message = "length of purpose of use must less than equal 20")
    private String purpose_of_use;

    @NotNull
    @NotEmpty(message = "Please provide time of use")
    @Size(max = 20, message = "length of time of use must less than 20")
    private String time_of_use;

    @NotNull
    @NotEmpty(message = "Please provide origin of use")
    @Size(max = 20, message = "length of origin of use must less than 20")
    private String origin_of_use;

    @NotNull
    @NotEmpty(message = "Please provide signer ")
    @Size(max = 16, message = "length of signer of use must less than 16")
    private String signer;

    @NotNull
    @DateTimeValidated
    private String date_of_signed;

    private String type;

    public String getSigner() {
        return signer;
    }

    public void setSigner(String signer) {
        this.signer = signer;
    }

    public String getDate_of_signed() {
        return date_of_signed;
    }

    public void setDate_of_signed(String date_of_signed) {
        this.date_of_signed = date_of_signed;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getForm_of_use() {
        return form_of_use;
    }

    public void setForm_of_use(String form_of_use) {
        this.form_of_use = form_of_use;
    }

    public String getPurpose_of_use() {
        return purpose_of_use;
    }

    public void setPurpose_of_use(String purpose_of_use) {
        this.purpose_of_use = purpose_of_use;
    }

    public String getTime_of_use() {
        return time_of_use;
    }

    public void setTime_of_use(String time_of_use) {
        this.time_of_use = time_of_use;
    }

    public String getOrigin_of_use() {
        return origin_of_use;
    }

    public void setOrigin_of_use(String origin_of_use) {
        this.origin_of_use = origin_of_use;
    }

    public String getCert_id() {
        return cert_id;
    }

    public void setCert_id(String cert_id) {
        this.cert_id = cert_id;
    }

    public List<String> getOwners() {
        return owners;
    }

    public void setOwners(List<String> owners) {
        this.owners = owners;
    }

    public String getLand_id() {
        return land_id;
    }

    public void setLand_id(String land_id) {
        this.land_id = land_id;
    }

    public String getMap_id() {
        return map_id;
    }

    public void setMap_id(String map_id) {
        this.map_id = map_id;
    }

    public String getIssue_date() {
        return issue_date;
    }

    public void setIssue_date(String issue_date) {
        this.issue_date = issue_date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
