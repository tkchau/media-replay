package com.beowulf.model.request;

public class ListCreatedAccountPagingRequest extends ListObjectsPagingRequest {
    private String creator;

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

}
