package com.beowulf.model.aggregate;

public class AggregateAmountTransferItem {

    private String _id;

    private long daily_transfer_amount;

    public AggregateAmountTransferItem() {
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public long getDaily_transfer_amount() {
        return daily_transfer_amount;
    }

    public void setDaily_transfer_amount(long daily_transfer_amount) {
        this.daily_transfer_amount = daily_transfer_amount;
    }
}
