package com.beowulf.model.request;

import javax.validation.constraints.*;

public class DemoCertificateRequest {
    @NotNull
    @NotEmpty(message = "Please provide serial number")
    @Size(max = 8, message = "length of serial number must less than 8 characters")
    private String serial_num;

    @NotNull
    @NotEmpty(message = "Please provide reference number")
    @Size(max = 8, message = "length of reference number must less than 8 characters")
    private String ref_num;

    @NotNull
    @NotEmpty(message = "Please provide student id")
    @Size(max = 8, message = "length of student id must less than 8 characters")
    private String student_id;

    @NotNull
    @NotEmpty(message = "Please provide ranking of student")
    @Size(max = 20, message = "length of ranking must less than 20 characters")
    private String ranking;

    @NotNull
    @NotEmpty(message = "Please provide degree")
    @Size(max = 10, message = "length of degree must less than 10 characters")
    private String degree;

    @NotNull
    @Min(value = 2000, message = "issue year out of range, 2000 < year < 3000")
    @Max(value = 3000, message = "issue year out of range, 2000 < year < 3000")
    private int year;

    private String type;

    public DemoCertificateRequest() {
    }

    public DemoCertificateRequest(String serial_num, String ref_num, String student_id, String ranking, String degree, int year) {
        this.serial_num = serial_num;
        this.ref_num = ref_num;
        this.student_id = student_id;
        this.ranking = ranking;
        this.degree = degree;
        this.year = year;
    }

    public String getSerial_num() {
        return serial_num;
    }

    public void setSerial_num(String serial_num) {
        this.serial_num = serial_num;
    }

    public String getRef_num() {
        return ref_num;
    }

    public void setRef_num(String ref_num) {
        this.ref_num = ref_num;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getRanking() {
        return ranking;
    }

    public void setRanking(String ranking) {
        this.ranking = ranking;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
