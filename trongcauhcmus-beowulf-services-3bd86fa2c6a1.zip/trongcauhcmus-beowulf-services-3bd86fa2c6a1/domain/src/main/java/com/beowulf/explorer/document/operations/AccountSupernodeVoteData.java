package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.AccountSupernodeVoteOperation;

public class AccountSupernodeVoteData extends OperationData{
    private String account;
    private String supernode;
    private boolean approve;
    private Asset fee;
    private long votes;

    public AccountSupernodeVoteData() {
    }

    public AccountSupernodeVoteData(AccountSupernodeVoteOperation accountSupernodeVoteOperation) {
        this.account = accountSupernodeVoteOperation.getAccount().getName();
        this.supernode = accountSupernodeVoteOperation.getSupernode().getName();
        this.approve = accountSupernodeVoteOperation.getApprove();
        this.fee = accountSupernodeVoteOperation.getFee();
        this.votes = accountSupernodeVoteOperation.getVotes();
    }

    public long getVotes() {
        return votes;
    }

    public void setVotes(long votes) {
        this.votes = votes;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getSupernode() {
        return supernode;
    }

    public void setSupernode(String supernode) {
        this.supernode = supernode;
    }

    public boolean isApprove() {
        return approve;
    }

    public void setApprove(boolean approve) {
        this.approve = approve;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }
}
