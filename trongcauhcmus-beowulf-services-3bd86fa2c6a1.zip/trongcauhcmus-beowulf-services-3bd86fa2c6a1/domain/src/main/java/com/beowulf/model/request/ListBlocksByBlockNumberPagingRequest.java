package com.beowulf.model.request;

public class ListBlocksByBlockNumberPagingRequest {
    private long start_block;
    private int limit;
    private String direction;

    public long getStart_block() {
        return start_block;
    }

    public void setStart_block(long start_block) {
        this.start_block = start_block;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
}
