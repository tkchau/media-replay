package com.beowulf.model.ethereum.multisig;

import com.beowulf.utilities.GsonSingleton;

import java.math.BigInteger;

public abstract class TxnInfo {
    protected String receiver;
    protected BigInteger value;
    protected BigInteger expireTime;
    protected BigInteger sequenceId;
    protected String signature;

    public TxnInfo() {
    }

    public TxnInfo(String receiver, BigInteger value, BigInteger expireTime, BigInteger sequenceId) {
        setReceiver(receiver);
        setValue(value);
        setExpireTime(expireTime);
        setSequenceId(sequenceId);
    }

    public abstract byte[] serialize();

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public BigInteger getValue() {
        return value;
    }

    public void setValue(BigInteger value) {
        this.value = value;
    }

    public BigInteger getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(BigInteger expireTime) {
        this.expireTime = expireTime;
    }

    public BigInteger getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(BigInteger sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    @Override
    public String toString() {
        return GsonSingleton.getInstance().toJson(this);
    }
}
