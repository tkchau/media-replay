package com.beowulf.explorer.document.operations.typeData;

import com.beowulfchain.beowulfj.protocol.AssetInfo;

public class AssetData {
    private int decimals;
    private String name;

    public AssetData() {
    }

    public AssetData(AssetInfo assetInfo) {
        this.name = assetInfo.getName();
        this.decimals = assetInfo.getDecimals().intValue();
    }

    public int getDecimals() {
        return decimals;
    }

    public void setDecimals(int decimals) {
        this.decimals = decimals;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
