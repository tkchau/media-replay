package com.beowulf.hook.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.hook.repository.extend.HookPendingRepositoryExtend;
import com.beowulf.model.TransactionReceipt;
import com.beowulf.utilities.StringUtils;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class HookPendingRepositoryImp implements HookPendingRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    private static int MAX_CALLBACK_TIMES = 5;

    @Override
    public List<Document> findValidHookingPending(ObjectId fromId, int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where("call_times").lte(MAX_CALLBACK_TIMES));
        if (fromId != null && StringUtils.hasText(fromId.toString()))
            query.addCriteria(Criteria.where("_id").gt(fromId));
        query.with(Sort.by(Sort.Direction.ASC, "_id"));
        query.limit(limit);

        return mongoTemplate.find(query, Document.class, CollectionName.COL_HOOK_PENDING);
    }

    @Override
    public boolean removePendingTransactionById(ObjectId id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        DeleteResult result = mongoTemplate.remove(query, CollectionName.COL_HOOK_PENDING);
        return result.getDeletedCount() != 0;
    }

    @Override
    public boolean increaseCallTimes(ObjectId id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        Update update = new Update();
        update.inc("call_times", 1);
        update.set("last_call", System.currentTimeMillis());
        UpdateResult result = mongoTemplate.updateFirst(query, update, CollectionName.COL_HOOK_PENDING);
        return result.getModifiedCount() != 0;
    }

    @Override
    public void save(TransactionReceipt receipt) {
        mongoTemplate.save(receipt, CollectionName.COL_HOOK_PENDING);
    }
}
