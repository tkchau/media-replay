package com.beowulf.annotations;

import com.beowulf.validator.ApiKeyValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ApiKeyValidator.class)
@Documented
public @interface ApiKeyValidated {
    String message() default "Api key is invalid";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    String name() default "apikey";

    @Target({ElementType.FIELD, ElementType.PARAMETER})
    @Retention(RetentionPolicy.RUNTIME)
    @Documented
    public @interface List {
        ApiKeyValidated[] value();
    }
}
