package com.beowulf.model;

public class DragToken {
    private int x;
    private boolean is_valid;

    public DragToken() {
    }

    public DragToken(int x, boolean is_valid) {
        this.x = x;
        this.is_valid = is_valid;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public boolean isIs_valid() {
        return is_valid;
    }

    public void setIs_valid(boolean is_valid) {
        this.is_valid = is_valid;
    }
}
