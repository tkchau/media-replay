package com.beowulf.account.repository;

import com.beowulf.account.documents.AirdropHistory;
import com.beowulf.account.repository.extend.AirdropHistoryRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AirdropHistoryRepository extends MongoRepository<AirdropHistory, ObjectId>, AirdropHistoryRepositoryExtend {
    @DeleteQuery(value = "{'account_name' : ?0}")
    public void deleteAirdropHistoriesByAccount_name(String account_name);
}
