package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.repository.extend.BeowulfOperationRepositoryExtend;
import com.beowulf.model.aggregate.AggregateAccountItem;
import com.beowulf.model.aggregate.AggregateAmountTransferItem;
import com.beowulf.utilities.Common;
import com.beowulfchain.beowulfj.enums.OperationType;
import com.mongodb.client.result.DeleteResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Repository
public class BeowulfOperationRepositoryImpl implements BeowulfOperationRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean addNewOperation(BeowulfOperation newOperation) {
        mongoTemplate.save(newOperation);
        return true;
    }

    @Override
    public BeowulfOperation findBeowulfOperationByTransaction_idAndIndex(String transactionId, int indexOp) {
        String querystr = transactionId + ":" + indexOp;
        Query query = new Query();
        query.addCriteria(Criteria.where("operation_id").is(querystr));
        BeowulfOperation beowulfOperations = mongoTemplate.findOne(query, BeowulfOperation.class, CollectionName.OPERATIONS);
        return beowulfOperations;
    }

    @Override
    public List<BeowulfOperation> findBeowulfOperationByTransactionId(String transactionId) {
        // length of transaction id must equal 40
        if (transactionId.length() != 40) {
            return Collections.emptyList();
        }
        Query query = new Query();
        // find with operation id start with transactionId
        query.addCriteria(Criteria.where("operation_id").regex("^" + transactionId));
        List<BeowulfOperation> beowulfOperations = mongoTemplate.find(query, BeowulfOperation.class, CollectionName.OPERATIONS);
        return beowulfOperations;
    }

    @Override
    public List<BeowulfOperation> getListOperation(ObjectId startId, int limit, String direction, String type) {
        if (type != null) {
            Pair<String, Object> typeFilter = Pair.of("type", type);
            return listOperationPaging(Constant.PAGING_KEY, startId, limit, direction, typeFilter);
        }
        return listOperationPaging(Constant.PAGING_KEY, startId, limit, direction, null);
    }

    @Override
    public long countOperationByAccount(String accountName) {
        Query query = new Query();
        query.addCriteria(new Criteria().orOperator(Criteria.where("relate_account_1").is(accountName), Criteria.where("relate_account_2").is(accountName)));
        return mongoTemplate.count(query, BeowulfOperation.class);
    }

    @Override
    public List<BeowulfOperation> getOperationByTransferAsset(ObjectId startId, int limit, String direction, String transfer_asset) {
        Pair<String, Object> assetFilter = Pair.of("operation.amount.name", transfer_asset);
        return listOperationPaging(Constant.PAGING_KEY, startId, limit, direction, assetFilter);
    }

    @Override
    public List<BeowulfOperation> findBeowulfOperationByRelateAccount(ObjectId startId, String account, String direction, int limit, String type) {
        Query query = Common.buildPagingQuery(Constant.PAGING_KEY, startId, limit, direction, null);
        query.addCriteria(new Criteria().orOperator(Criteria.where("relate_account_1").is(account), Criteria.where("relate_account_2").is(account)));
        if (type != null) {
            query.addCriteria(Criteria.where("type").is(type));
        }
        return mongoTemplate.find(query, BeowulfOperation.class, CollectionName.OPERATIONS);
    }

    private boolean removeOperationBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        DeleteResult result = mongoTemplate.remove(query, BeowulfOperation.class, CollectionName.OPERATIONS);
        return result.getDeletedCount() != 0;
    }

    @Override
    public boolean removeOperationById(ObjectId id) {
        Pair<String, Object> filterId = Pair.of("_id", id);
        return removeOperationBy(filterId);
    }

    @Override
    public boolean removeOperationByOperationId(String operationId) {
        Pair<String, Object> filterOperationId = Pair.of("operation_id", operationId);
        return removeOperationBy(filterOperationId);
    }

    @Override
    public AggregateAccountItem getTotalIncAccountDaily(ObjectId startId, ObjectId endId) {
        AggregateAccountItem chartItems = new AggregateAccountItem();
        MatchOperation matchOperation = Aggregation
                .match(new Criteria().andOperator(
                        Criteria.where(Constant.PAGING_KEY).gt(startId),
                        Criteria.where(Constant.PAGING_KEY).lte(endId),
                        Criteria.where("type").is(OperationType.ACCOUNT_CREATE_OPERATION)
                        )
                );
        SortOperation sortByBcId = Aggregation.sort(new Sort(Sort.Direction.ASC, Constant.PAGING_KEY));
        GroupOperation groupOperation = Aggregation.group()
                .sum(ArithmeticOperators.Abs.absoluteValueOf(1)).as("daily_inc_account");
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, sortByBcId, groupOperation);
        AggregationResults<AggregateAccountItem> result = mongoTemplate.aggregate(aggregation,
                CollectionName.OPERATIONS, AggregateAccountItem.class);
        if (result.iterator().hasNext()) {
            chartItems = result.getMappedResults().get(0);
        }
        return chartItems;
    }

    @Override
    public List<AggregateAmountTransferItem> getTotalAmountTransferDaily(ObjectId startId, ObjectId endId) {
        List<AggregateAmountTransferItem> chartItems = new ArrayList<>();
        MatchOperation matchOperation = Aggregation
                .match(new Criteria().andOperator(
                        Criteria.where(Constant.PAGING_KEY).gt(startId),
                        Criteria.where(Constant.PAGING_KEY).lte(endId),
                        Criteria.where("type").is(OperationType.TRANSFER_OPERATION)
                        )
                );
        SortOperation sortByBcId = Aggregation.sort(new Sort(Sort.Direction.ASC, Constant.PAGING_KEY));
        GroupOperation groupOperation = Aggregation.group("operation.amount.name")
                .sum("operation.amount.amount").as("daily_transfer_amount");
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, sortByBcId, groupOperation);
        AggregationResults<AggregateAmountTransferItem> result = mongoTemplate.aggregate(aggregation,
                CollectionName.OPERATIONS, AggregateAmountTransferItem.class);
        if (result.iterator().hasNext()) {
            chartItems = result.getMappedResults();
        }
        return chartItems;
    }

    private List<BeowulfOperation> listOperationPaging(String key, Object value, int limit, String direction, @Nullable Pair<String, Object> filter) {
        Query query = Common.buildPagingQuery(key, value, limit, direction, filter);
        return mongoTemplate.find(query, BeowulfOperation.class);
    }
}
