package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.model.aggregate.AggregateBlockAndTxItem;
import org.bson.types.ObjectId;

import java.util.List;

public interface BeowulfBlockRepositoryExtend {

    List<BeowulfBlock> getLastNBlocks(int limit);

    List<BeowulfBlock> getListBlockByBlockNum(long startBlock, int limit, String direction);

    long getTotalBlockProducedBySupernode(String supernodeName);

    List<BeowulfBlock> getBlockPaging(ObjectId startId, int limit, String direction);

    List<BeowulfBlock> getBlockPagingProduceBySupernode(ObjectId startId, int limit, String direction, String supernodeName);

    boolean removeBlockById(ObjectId id);

    AggregateBlockAndTxItem getTotalIncBlockAndTxDaily(ObjectId startId, ObjectId endId);
}
