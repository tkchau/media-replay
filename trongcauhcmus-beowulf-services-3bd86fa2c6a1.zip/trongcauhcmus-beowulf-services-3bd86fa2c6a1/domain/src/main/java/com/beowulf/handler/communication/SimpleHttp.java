package com.beowulf.handler.communication;

import com.beowulf.exception.CrypitorCommunicationException;
import com.beowulf.exception.CrypitorResponseException;
import com.beowulf.handler.communication.apache.CustomHttpHeaders;
import com.beowulf.handler.communication.apache.HttpClientRequestInitializer;
import com.beowulf.handler.communication.apache.HttpRequestFactory;
import com.beowulf.model.request.HttpRequestObject;
import com.beowulf.model.response.HttpResponseObject;
import com.beowulf.utilities.LoggerUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.entity.mime.MIME;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.concurrent.Future;

class SimpleHttp {
    private CloseableHttpClient client;
    private CloseableHttpAsyncClient asyncClient;
    private static ObjectMapper objectMapper = new ObjectMapper();

    public SimpleHttp(CloseableHttpClient client, CloseableHttpAsyncClient asyncClient) {
        this.client = client;
        this.asyncClient = asyncClient;
    }

    @Deprecated
    public HttpResponseObject sendRequest(String requestMethod,
                                          HttpRequestObject requestObject,
                                          URI endpointUri,
                                          List<Header> headers)
            throws CrypitorCommunicationException, CrypitorResponseException {
        return sendRequest(requestMethod, requestObject.toJson(), endpointUri, headers);
    }

    public HttpResponseObject sendRequest(String requestMethod,
                                          String requestPayload,
                                          URI endpointUri,
                                          List<Header> headers)
            throws CrypitorCommunicationException, CrypitorResponseException {
        try {
            HttpRequestBase httpRequestBase = buildRequest(requestMethod, requestPayload, endpointUri, headers);

            CloseableHttpResponse response = client.execute(httpRequestBase);
            return handleResponse(response);

        } catch (HttpResponseException e) {
            LoggerUtil.e(this, e.getMessage());
            throw new CrypitorResponseException(e.getStatusCode(), e.getMessage());
        } catch (NoHttpResponseException e) {
            LoggerUtil.e(this, e.getMessage());
            throw new CrypitorResponseException(HttpStatus.REQUEST_TIMEOUT.value(), e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new CrypitorCommunicationException("A problem occured while processing the request.", e);
        }
    }

    public Future<HttpResponse> sendRequestAsync(String requestMethod,
                                                 String requestPayload,
                                                 URI endpointUri,
                                                 List<Header> headers,
                                                 final FutureCallback<HttpResponseObject> futureCallback)
            throws CrypitorCommunicationException, CrypitorResponseException {
        try {
            HttpRequestBase httpRequestBase = buildRequest(requestMethod, requestPayload, endpointUri, headers);

            return asyncClient.execute(httpRequestBase, new FutureCallback<HttpResponse>() {
                @Override
                public void completed(HttpResponse httpResponse) {
                    try {
                        HttpResponseObject responseObject = handleResponse(httpResponse);
                        futureCallback.completed(responseObject);
                    } catch (HttpResponseException e) {
                        futureCallback.failed(new CrypitorResponseException(e.getStatusCode(), e.getMessage()));
                    } catch (IOException e) {
                        futureCallback.failed(new CrypitorCommunicationException("A problem occured while processing the request.", e));
                    } catch (Exception e) {
                        futureCallback.failed(e);
                    }
                }

                @Override
                public void failed(Exception e) {
                    futureCallback.failed(e);
                }

                @Override
                public void cancelled() {
                    futureCallback.cancelled();
                }
            });

        } catch (HttpResponseException e) {
            LoggerUtil.e(this, e.getMessage());
            throw new CrypitorResponseException(e.getStatusCode(), e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new CrypitorCommunicationException("A problem occured while processing the request.", e);
        }
    }

    @Deprecated
    public Future<HttpResponse> sendRequestAsync(String requestMethod,
                                                 HttpRequestObject requestObject,
                                                 URI endpointUri,
                                                 List<Header> headers,
                                                 final FutureCallback<HttpResponseObject> futureCallback)
            throws CrypitorCommunicationException, CrypitorResponseException {
        return sendRequestAsync(requestMethod, requestObject.toJson(), endpointUri, headers, futureCallback);
    }

    @Deprecated
    public static HttpRequestBase buildRequest(String requestMethod, HttpRequestObject requestObject, URI endpointUri, List<Header> headers) throws IOException {
        String requestPayload = "";
        if (requestObject != null) {
            requestPayload = objectMapper.writeValueAsString(requestObject);
        }
        return buildRequest(requestMethod, requestPayload, endpointUri, headers);
    }

    public static HttpRequestBase buildRequest(String requestMethod, String requestPayload, URI endpointUri, List<Header> headers) throws IOException {
        HttpRequestBase httpRequestBase = HttpRequestFactory.buildRequest(requestMethod, endpointUri, requestPayload);
        if (headers == null) {
            headers = CustomHttpHeaders.custom().build();
        }
        for (Header header : headers) {
            httpRequestBase.setHeader(header);
        }
        HttpClientRequestInitializer.initialize(httpRequestBase);
        return httpRequestBase;
    }

    public static HttpResponseObject handleResponse(HttpResponse response) throws IOException {
        int status = response.getStatusLine().getStatusCode();
        String responseJSON = EntityUtils.toString(response.getEntity(), MIME.UTF8_CHARSET);

        if (status >= 200 && status < 300 && responseJSON != null) {
            HttpResponseObject responseObject = new HttpResponseObject(HttpHandler.getObjectMapper().readTree(responseJSON));
            responseObject.setStatus(status);
            return responseObject;
        } else {
            throw new HttpResponseException(status, responseJSON);
        }
    }
}
