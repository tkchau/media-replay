package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.repository.extend.BeowulfBlockRepositoryExtend;
import com.beowulf.model.aggregate.AggregateBlockAndTxItem;
import com.beowulf.utilities.Common;
import com.mongodb.client.result.DeleteResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import java.util.List;

@Repository
public class BeowulfBlockRepositoryImpl implements BeowulfBlockRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public List<BeowulfBlock> getLastNBlocks(int limit) {
        Query query = new Query();
        query.limit(limit);
        query.with(Sort.by(Sort.Direction.DESC, Constant.PAGING_KEY));
        return mongoTemplate.find(query, BeowulfBlock.class);
    }

    @Override
    public List<BeowulfBlock> getListBlockByBlockNum(long startBlock, int limit, String direction) {
        return listBlockPaging("block_number", startBlock, limit, direction, null);
    }

    @Override
    public long getTotalBlockProducedBySupernode(String supernodeName) {
        Query query = new Query();
        query.addCriteria(Criteria.where("supernode").is(supernodeName));
        List<BeowulfBlock> blockList = mongoTemplate.find(query, BeowulfBlock.class);
        return !blockList.isEmpty() ? blockList.size() : 0L;
    }

    @Override
    public List<BeowulfBlock> getBlockPagingProduceBySupernode(ObjectId startId, int limit, String direction, String supernodeName) {
        Pair<String, Object> supernodeFilter = Pair.of("supernode", supernodeName);
        return listBlockPaging(Constant.PAGING_KEY, startId, limit, direction, supernodeFilter);
    }

    private boolean removeBlockBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        DeleteResult result = mongoTemplate.remove(query, BeowulfBlock.class, CollectionName.BLOCKS);
        return result.getDeletedCount() != 0;
    }

    @Override
    public boolean removeBlockById(ObjectId id) {
        Pair<String, Object> filterId = Pair.of("_id", id);
        return removeBlockBy(filterId);
    }

    @Override
    public List<BeowulfBlock> getBlockPaging(ObjectId startId, int limit, String direction) {
        return listBlockPaging(Constant.PAGING_KEY, startId, limit, direction, null);
    }

    @Override
    public AggregateBlockAndTxItem getTotalIncBlockAndTxDaily(ObjectId startId, ObjectId endId) {
        AggregateBlockAndTxItem chartItems = new AggregateBlockAndTxItem();
        MatchOperation matchOperation = Aggregation
                .match(new Criteria().andOperator(
                        Criteria.where(Constant.PAGING_KEY).gt(startId),
                        Criteria.where(Constant.PAGING_KEY).lte(endId)
                ));
        SortOperation sortByBcId = Aggregation.sort(new Sort(Sort.Direction.ASC, Constant.PAGING_KEY));
        GroupOperation groupOperation = Aggregation.group()
                .sum(ArithmeticOperators.Abs.absoluteValueOf(1)).as("daily_inc_block")
                .sum("number_transaction").as("daily_inc_tx");
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, sortByBcId, groupOperation);
        AggregationResults<AggregateBlockAndTxItem> result = mongoTemplate.aggregate(aggregation,
                CollectionName.BLOCKS, AggregateBlockAndTxItem.class);
        if (result.iterator().hasNext()) {
            chartItems = result.getMappedResults().get(0);
        }
        return chartItems;
    }

    private List<BeowulfBlock> listBlockPaging(String key, Object value, int limit, String direction, @Nullable Pair<String, Object> filter) {
        Query query = Common.buildPagingQuery(key, value, limit, direction, filter);
        return mongoTemplate.find(query, BeowulfBlock.class);
    }
}
