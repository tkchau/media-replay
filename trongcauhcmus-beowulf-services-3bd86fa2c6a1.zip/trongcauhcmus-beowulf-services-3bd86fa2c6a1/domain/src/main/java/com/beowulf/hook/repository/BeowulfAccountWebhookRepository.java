package com.beowulf.hook.repository;

import com.beowulf.hook.document.BeowulfAccountWebhook;
import com.beowulf.hook.repository.extend.BeowulfAccountWebhookRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface BeowulfAccountWebhookRepository extends MongoRepository<BeowulfAccountWebhook, ObjectId>, BeowulfAccountWebhookRepositoryExtend {
    @Query(value = "{'account_name' : ?0}")
    BeowulfAccountWebhook findBeowulfAccountWebhooksByAccount_name(String account_name);
}
