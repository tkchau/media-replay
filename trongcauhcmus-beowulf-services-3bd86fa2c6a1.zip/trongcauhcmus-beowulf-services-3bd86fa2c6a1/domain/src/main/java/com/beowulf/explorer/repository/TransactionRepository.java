package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.extend.TransactionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface TransactionRepository extends MongoRepository<BeowulfTransaction, ObjectId>, TransactionRepositoryExtend {

	@Query(value = "{'transaction_id' : ?0}")
	public BeowulfTransaction findByTransactionId(String transactionId);
	
	@Query(value = "{'block_number' : ?0}")
	public List<BeowulfTransaction> findByBlockNumber(long blockNumber);
	
}
