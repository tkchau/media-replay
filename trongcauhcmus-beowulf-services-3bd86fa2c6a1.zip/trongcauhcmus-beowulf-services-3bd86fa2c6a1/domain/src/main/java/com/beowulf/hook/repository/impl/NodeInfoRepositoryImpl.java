package com.beowulf.hook.repository.impl;

import com.beowulf.hook.document.NodeInfo;
import com.beowulf.hook.repository.extend.NodeInfoRepositoryExtend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class NodeInfoRepositoryImpl implements NodeInfoRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void updateLastSync(String node_url, long blocknum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(node_url));

        Update update = new Update();
        update.set("last_sync", blocknum);
        mongoTemplate.findAndModify(query, update, NodeInfo.class);
    }

    @Override
    public NodeInfo getHighestNodeByType(String type) {
        Query query = new Query();
        query.addCriteria(Criteria.where("type").is(type));
        List<NodeInfo> nodeInfos = mongoTemplate.find(query, NodeInfo.class);
        NodeInfo highestNode = nodeInfos.get(0);

        long var1 = highestNode.getLast_sync();
        for (NodeInfo nodeInfo: nodeInfos) {
            long var2 = nodeInfo.getLast_sync();
            if (var1 < var2) {
                highestNode = nodeInfo;
                var1 = var2;
            }
        }
        return highestNode;
    }
}
