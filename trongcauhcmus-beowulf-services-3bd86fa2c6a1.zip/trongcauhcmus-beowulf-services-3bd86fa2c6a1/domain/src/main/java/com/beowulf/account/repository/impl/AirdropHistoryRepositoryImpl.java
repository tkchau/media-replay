package com.beowulf.account.repository.impl;

import com.beowulf.account.documents.AirdropHistory;
import com.beowulf.account.repository.extend.AirdropHistoryRepositoryExtend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

public class AirdropHistoryRepositoryImpl implements AirdropHistoryRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void removeByAccountName(String account_name) {
        Query query = new Query();
        query.addCriteria(Criteria.where("account_name").is(account_name));
        mongoTemplate.remove(query, AirdropHistory.class);
    }
}
