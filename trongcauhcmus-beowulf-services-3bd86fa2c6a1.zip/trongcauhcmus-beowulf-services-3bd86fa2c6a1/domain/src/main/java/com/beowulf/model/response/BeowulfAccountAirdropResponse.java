package com.beowulf.model.response;

/**
 * @author trongcauta
 * @time 11:16 AM
 * @data 6/3/19
 */
public class BeowulfAccountAirdropResponse {
    private String transferBWF_txid;
    private String transferW_txid;
    private boolean result;

    public BeowulfAccountAirdropResponse(boolean result, String transferBWF_txid, String transferW_txid) {
        this.transferBWF_txid = transferBWF_txid;
        this.transferW_txid = transferW_txid;
        this.result = result;
    }

    public String getTransferBWF_txid() {
        return transferBWF_txid;
    }

    public void setTransferBWF_txid(String transferBWF_txid) {
        this.transferBWF_txid = transferBWF_txid;
    }

    public String getTransferW_txid() {
        return transferW_txid;
    }

    public void setTransferW_txid(String transferW_txid) {
        this.transferW_txid = transferW_txid;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }
}
