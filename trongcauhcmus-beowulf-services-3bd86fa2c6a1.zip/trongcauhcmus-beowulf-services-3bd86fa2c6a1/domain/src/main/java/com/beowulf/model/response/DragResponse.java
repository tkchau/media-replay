package com.beowulf.model.response;

public class DragResponse {
    private int width;
    private int height;
    private int y;
    private int puzzle_width;
    private int puzzle_height;
    private String puzzle_data;
    private String background_data;
    private String token;


    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getPuzzle_width() {
        return puzzle_width;
    }

    public void setPuzzle_width(int puzzle_width) {
        this.puzzle_width = puzzle_width;
    }

    public int getPuzzle_height() {
        return puzzle_height;
    }

    public void setPuzzle_height(int puzzle_height) {
        this.puzzle_height = puzzle_height;
    }

    public String getPuzzle_data() {

        return puzzle_data;
    }

    public void setPuzzle_data(String puzzle_data) {
        this.puzzle_data = puzzle_data;
    }

    public String getBackground_data() {
        return background_data;
    }

    public void setBackground_data(String background_data) {
        this.background_data = background_data;
    }
    

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
