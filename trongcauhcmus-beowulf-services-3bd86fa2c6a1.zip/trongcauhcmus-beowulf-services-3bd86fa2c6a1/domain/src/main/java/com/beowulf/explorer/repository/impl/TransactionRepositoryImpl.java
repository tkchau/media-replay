package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.constants.TransactionConstant;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.extend.TransactionRepositoryExtend;
import com.beowulf.model.aggregate.AggregateFeeReceived;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class TransactionRepositoryImpl implements TransactionRepositoryExtend {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<BeowulfTransaction> getTransactionBelongToAccount(String name, ObjectId fromId, long startTime, long endTime,
                                                                  int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("created_at").gt(startTime));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("created_at").lt(endTime));
			} else {
				query.addCriteria(Criteria.where("created_at").gt(startTime).and("created_at").lt(endTime));
			}
		}
		query.addCriteria(new Criteria().orOperator(Criteria.where("from").is(name), Criteria.where("to").is(name),
				Criteria.where("supernode").is(name), Criteria.where("creator").is(name)));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransactionConfirmedByAccount(String name, ObjectId fromId, long startTime,
                                                                     long endTime, int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("created_at").gt(startTime));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("created_at").lt(endTime));
			} else {
				query.addCriteria(Criteria.where("created_at").gt(startTime).and("created_at").lt(endTime));
			}
		}
		query.addCriteria(Criteria.where("supernode").is(name));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransferTransactionByAccountName(String name, ObjectId fromId, long startTime,
                                                                        long endTime, int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("created_at").gt(startTime));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("created_at").lt(endTime));
			} else {
				query.addCriteria(Criteria.where("created_at").gt(startTime).and("created_at").lt(endTime));
			}
		}
		query.addCriteria(new Criteria().orOperator(Criteria.where("from").is(name), Criteria.where("to").is(name)));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getCreateAccountTransactionByAccountName(String name, ObjectId fromId, long startTime,
                                                                             long endTime, int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("created_at").gt(startTime));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("created_at").lt(endTime));
			} else {
				query.addCriteria(Criteria.where("created_at").gt(startTime).and("created_at").lt(endTime));
			}
		}
		query.addCriteria(new Criteria().orOperator(Criteria.where("creator").is(name),
				Criteria.where("new_account_name").is(name)));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<AggregateFeeReceived> getTotalFeeSupernodeReceived(String name, long startTime, long endTime) {
		List<AggregateFeeReceived> aggregateFeeReceiveds = new ArrayList<AggregateFeeReceived>();
		try {
			MatchOperation matchOperation = null;
			if (startTime > 0 || endTime > 0) {
				if (startTime > 0 && endTime == 0) {
					matchOperation = Aggregation
							.match(Criteria.where("supernode").is(name).and("created_at").gt(startTime));
				} else if (startTime == 0 && endTime > 0) {
					matchOperation = Aggregation
							.match(Criteria.where("supernode").is(name).and("created_at").lt(endTime));
				} else {
					matchOperation = Aggregation.match(Criteria.where("supernode").is(name).and("created_at")
							.gt(startTime).and("created_at").lt(endTime));
				}
			} else {
				matchOperation = Aggregation.match(Criteria.where("supernode").is(name));
			}
			ProjectionOperation projectionOperation = Aggregation.project("supernode", "fee");
			GroupOperation groupOperation = Aggregation.group("supernode").sum("fee").as("totalFee")
					.sum(ArithmeticOperators.Abs.absoluteValueOf(1)).as("numberTransaction");
			Aggregation aggregation = Aggregation.newAggregation(matchOperation, projectionOperation, groupOperation);
			AggregationResults<AggregateFeeReceived> result = mongoTemplate.aggregate(aggregation,
					CollectionName.TRANSACTIONS, AggregateFeeReceived.class);
			aggregateFeeReceiveds = result.getMappedResults();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return aggregateFeeReceiveds;
	}

	@Override
	public List<BeowulfTransaction> getLastestTransactions(int limit) {
		Query query = new Query();
		query.limit(limit);
		query.with(Sort.by(Sort.Direction.DESC, "_id"));
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransaction(ObjectId fromId, long startTime, long endTime, int limit,
                                                   String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("_id").gt(new ObjectId(new Date(startTime))));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("_id").lt(new ObjectId(new Date(endTime))));
			} else {
				query.addCriteria(Criteria.where("_id").gt(new ObjectId(new Date(startTime))).and("_id")
						.lt(new ObjectId(new Date(endTime))));
			}
		}
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransactionBelongToBlock(List<Long> blockNumbers) {
		Query query = new Query();
		query.addCriteria(Criteria.where("block_number").in(blockNumbers));
		query.with(Sort.by(Sort.Direction.DESC, "_id"));
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransactionByBlockNumber(long blockNumber, ObjectId fromId, long startTime,
                                                                long endTime, int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("_id").gt(new ObjectId(new Date(startTime))));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("_id").lt(new ObjectId(new Date(endTime))));
			} else {
				query.addCriteria(Criteria.where("_id").gt(new ObjectId(new Date(startTime))).and("_id")
						.lt(new ObjectId(new Date(endTime))));
			}
		}
		query.addCriteria(Criteria.where("block_number").is(blockNumber));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getListTransactionById(List<String> transactionIds) {
		Query query = new Query();
		query.addCriteria(Criteria.where("transaction_id").in(transactionIds));
		query.with(Sort.by(Sort.Direction.DESC, "_id"));
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

	@Override
	public List<BeowulfTransaction> getTransferTransactionByCurrencyCode(String currencyCode, ObjectId fromId, long startTime,
                                                                         long endTime, int limit, String direction) {
		Query query = new Query();
		if (fromId != null) {
			if (TransactionConstant.LIST_TRANSACTION_DIRECTION_PREVIOUS.equals(direction)) {
				query.addCriteria(Criteria.where("_id").gt(fromId));
				query.with(Sort.by(Sort.Direction.ASC, "_id"));
			} else {
				query.addCriteria(Criteria.where("_id").lt(fromId));
				query.with(Sort.by(Sort.Direction.DESC, "_id"));
			}
		} else {
			query.with(Sort.by(Sort.Direction.DESC, "_id"));
		}
		if (startTime > 0 || endTime > 0) {
			if (startTime > 0 && endTime == 0) {
				query.addCriteria(Criteria.where("created_at").gt(startTime));
			} else if (startTime == 0 && endTime > 0) {
				query.addCriteria(Criteria.where("created_at").lt(endTime));
			} else {
				query.addCriteria(Criteria.where("created_at").gt(startTime).and("created_at").lt(endTime));
			}
		}
		query.addCriteria(Criteria.where("amount_currency").is(currencyCode));
		query.limit(limit);
		return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
	}

}
