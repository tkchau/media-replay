package com.beowulf.model.chart.record;

import com.beowulf.utilities.DateTimeUtils;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class ChartDailyRecord {

    private Integer year;

    private Integer month;

    private Integer day;

    private Long unixTimeStamp;

    private Integer daily_inc_block;

    private Integer daily_inc_tx;

    private Integer daily_inc_account;

    private Long daily_transfer_bwf;

    private Long daily_transfer_w;

    private Long time_cursor;

    private boolean written;

    public ChartDailyRecord() {
    }

    public ChartDailyRecord(Date date) {
        LocalDateTime localDateTime = DateTimeUtils.dateToLocalDateTime(date);
        this.year = localDateTime.getYear();
        this.month = localDateTime.getMonthValue();
        this.day = localDateTime.getDayOfMonth();
        this.unixTimeStamp = date.getTime();
        this.daily_inc_block = this.daily_inc_tx = this.daily_inc_account = 0;
        this.daily_transfer_bwf = this.daily_transfer_w = 0L;
        this.written = false;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Long getUnixTimeStamp() {
        return unixTimeStamp;
    }

    public void setUnixTimeStamp(Long unixTimeStamp) {
        this.unixTimeStamp = unixTimeStamp;
    }

    public Integer getDaily_inc_block() {
        return daily_inc_block;
    }

    public void setDaily_inc_block(Integer daily_inc_block) {
        this.daily_inc_block = daily_inc_block;
    }

    public Integer getDaily_inc_tx() {
        return daily_inc_tx;
    }

    public void setDaily_inc_tx(Integer daily_inc_tx) {
        this.daily_inc_tx = daily_inc_tx;
    }

    public Integer getDaily_inc_account() {
        return daily_inc_account;
    }

    public void setDaily_inc_account(Integer daily_inc_account) {
        this.daily_inc_account = daily_inc_account;
    }

    public Long getDaily_transfer_bwf() {
        return daily_transfer_bwf;
    }

    public void setDaily_transfer_bwf(Long daily_transfer_bwf) {
        this.daily_transfer_bwf = daily_transfer_bwf;
    }

    public Long getDaily_transfer_w() {
        return daily_transfer_w;
    }

    public void setDaily_transfer_w(Long daily_transfer_w) {
        this.daily_transfer_w = daily_transfer_w;
    }

    public Long getTime_cursor() {
        return time_cursor;
    }

    public void setTime_cursor(Long time_cursor) {
        this.time_cursor = time_cursor;
    }

    public List<Object> valueAsList() {
        return Arrays.asList(year, month, day, unixTimeStamp, daily_inc_block, daily_inc_tx, daily_inc_account, daily_transfer_bwf, daily_transfer_w);
    }

    public boolean isWritten() {
        return written;
    }

    public void setWritten(boolean written) {
        this.written = written;
    }
}
