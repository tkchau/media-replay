package com.beowulf.certificate.document.certdata;

import com.beowulf.utilities.GsonSingleton;
import org.springframework.data.mongodb.core.index.Indexed;

public class AcademicCertificateData extends CertificateData {
    @Indexed(unique = true)
    private String serial_num;

    private String ref_num;

    @Indexed
    private String student_id;

    private String ranking;
    private String degree;
    private int year;

    public AcademicCertificateData() {
    }

    public static AcademicCertificateData parseAcademicCert(String jsonExtensionValue) throws IllegalArgumentException {
        try {
            return GsonSingleton.getInstance().fromJson(jsonExtensionValue, AcademicCertificateData.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid properties of Academic certificate");
        }
    }

    public String getSerial_num() {
        return serial_num;
    }

    public void setSerial_num(String serial_num) {
        this.serial_num = serial_num;
    }

    public String getRef_num() {
        return ref_num;
    }

    public void setRef_num(String ref_num) {
        this.ref_num = ref_num;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getRanking() {
        return ranking;
    }

    public void setRanking(String ranking) {
        this.ranking = ranking;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
