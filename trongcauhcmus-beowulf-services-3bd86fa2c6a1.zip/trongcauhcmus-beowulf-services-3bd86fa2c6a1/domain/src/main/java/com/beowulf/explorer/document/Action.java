package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = CollectionName.ACTIONS)
@CompoundIndex(def = "{\"name\": 1, \"action\": 1}", unique = true)
public class Action {
	@Id
	private ObjectId id;
	private String name;
	private String action;

	@Indexed(expireAfterSeconds = 3600)
	private Date createTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Action(String name, String action) {
		this.name = name;
		this.action = action;
		createTime = new Date();
	}

	public Action(String name, String action, long ttl) {
		this.name = name;
		this.action = action;
		this.createTime = new Date(new Date().getTime() - 3600 * 1000 + ttl * 1000);
	}
}
