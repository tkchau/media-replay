package com.beowulf.validator;

import com.beowulf.annotations.RequestThottlingValidated;
import com.beowulf.exception.ServiceException;
import com.beowulf.utilities.HttpServletUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.ServiceExceptionUtils;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.concurrent.TimeUnit;

public class RequestThrottlingValidator implements ConstraintValidator<RequestThottlingValidated, Object> {

    private int rate;
    private TimeUnit timeUnit;

    @Override
    public void initialize(RequestThottlingValidated constraintAnnotation) {
        rate = constraintAnnotation.rate();
        timeUnit = constraintAnnotation.timeUnit();
    }

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext constraintValidatorContext) {
        ServiceException exception = ServiceExceptionUtils.tooManyRequest();
        try {
            if (target == null) {
                return false;
            }
            if (target instanceof HttpServletRequest) {
                HttpServletRequest httpServletRequest = (HttpServletRequest) target;
                HttpServletUtils.doFilter(httpServletRequest, rate, timeUnit);
            } else {
                return false;
            }
            return true;
        } catch (ServiceException e) {
            LoggerUtil.i(this, e.getDescription());
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            String message = exception.generateStringResponse();
            constraintValidatorContext.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        }
    }
}