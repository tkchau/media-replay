package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.BeowulfTokenHolder;
import com.beowulf.explorer.repository.extend.BeowulfTokenHolderRepositoryExtend;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.List;

public class BeowulfTokenHolderRepositoryImpl implements BeowulfTokenHolderRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public boolean updateBalanceTokenHolder(String holder, Asset balance) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("account").is(holder).andOperator(
                        Criteria.where("balance.name").is(balance.getName()))
        );
        Update update = new Update();
        update.set("balance.amount", balance.getAmount());
        UpdateResult result = mongoTemplate.upsert(query, update, BeowulfTokenHolder.class, CollectionName.TOKEN_HOLDERS);
        return result.getModifiedCount() != 0;
    }

    @Override
    public List<BeowulfTokenHolder> getTopTokenHoldersByTokenName(String token, int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where("balance.name").is(token).andOperator(Criteria.where("balance.amount").gt(0)));
        query.with(Sort.by(Sort.Direction.DESC, "balance.amount"));
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfTokenHolder.class, CollectionName.TOKEN_HOLDERS);
    }

    @Override
    public long getTotalHolders(String token) {
        Query query = new Query();
        query.addCriteria(new Criteria().andOperator(
                Criteria.where("balance.name").is(token),
                Criteria.where("balance.amount").gt(0))
        );
        return mongoTemplate.count(query, BeowulfTokenHolder.class, CollectionName.TOKEN_HOLDERS);
    }

    @Override
    public BeowulfTokenHolder findBeowulfTokenHolderByTokenAndAccount(String token, String holder) {
        Query query = new Query();
        query.addCriteria(Criteria.where("account").is(holder).andOperator(Criteria.where("balance.name").is(token)));
        return mongoTemplate.findOne(query, BeowulfTokenHolder.class, CollectionName.TOKEN_HOLDERS);
    }
}