package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfToken;
import com.beowulfchain.beowulfj.protocol.Asset;
import org.bson.types.ObjectId;

import java.util.List;

public interface BeowulfTokenRepositoryExtend {
    boolean removeTokenByName(String tokenName);

    List<BeowulfToken> getTokenPaging(ObjectId start_id, int limit, String direction);

    boolean updateNativeSupply(String asset, Asset currentSupply);
}
