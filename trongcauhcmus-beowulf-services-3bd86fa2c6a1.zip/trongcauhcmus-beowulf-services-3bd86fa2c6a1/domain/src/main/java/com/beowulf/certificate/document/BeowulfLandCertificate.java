package com.beowulf.certificate.document;

import com.beowulf.certificate.document.certdata.LandCertificateData;
import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Stack;

@Document(collection = CollectionName.LAND_CERTIFICATES)
public class BeowulfLandCertificate {
    @Id
    private ObjectId id;

    @Indexed(unique = true)
    private String transaction_id;

    private LandCertificateData data;

    private Stack<String> tx_histories = new Stack<>();

    public BeowulfLandCertificate() {
    }

    public BeowulfLandCertificate(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public Stack<String> getTx_histories() {
        return tx_histories;
    }

    public void setTx_histories(Stack<String> tx_histories) {
        this.tx_histories = tx_histories;
    }

    public void pushTx_histories(String transaction_id) {
        this.tx_histories.push(transaction_id);
    }

    public LandCertificateData getData() {
        return data;
    }

    public void setData(LandCertificateData data) {
        this.data = data;
    }
}
