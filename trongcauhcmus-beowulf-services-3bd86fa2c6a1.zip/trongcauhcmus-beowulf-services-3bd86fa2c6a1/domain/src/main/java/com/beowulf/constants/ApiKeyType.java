package com.beowulf.constants;

public class ApiKeyType {
    public static final String BASIC = "Basic";
}
