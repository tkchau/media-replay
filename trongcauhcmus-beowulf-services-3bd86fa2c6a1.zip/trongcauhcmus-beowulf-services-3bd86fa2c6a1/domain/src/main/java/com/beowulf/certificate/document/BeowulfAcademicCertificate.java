package com.beowulf.certificate.document;

import com.beowulf.certificate.document.certdata.AcademicCertificateData;
import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.ACADEMIC_CERTIFICATES)
public class BeowulfAcademicCertificate {
    @Id
    private ObjectId id;

    @Indexed(unique = true)
    private String transaction_id;

    private AcademicCertificateData data;

    public BeowulfAcademicCertificate() {
    }

    public BeowulfAcademicCertificate(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public AcademicCertificateData getData() {
        return data;
    }

    public void setData(AcademicCertificateData data) {
        this.data = data;
    }
}
