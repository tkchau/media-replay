package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.operations.AccountUpdateData;
import com.beowulf.explorer.repository.extend.BeowulfAccountRepositoryExtend;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.StringUtils;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BeowulfAccountRepositoryImpl implements BeowulfAccountRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean increaseDataOfSupernode(String supernodeName, long blockReward, long totalFee, long totalOperations) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").is(supernodeName));
        Update update = new Update();
        update.inc("total_mined_block", 1);
        update.inc("total_mined_reward.amount", blockReward);
        update.inc("total_mined_fee.amount", totalFee);
        update.inc("total_confirmed_operation", totalOperations);
        UpdateResult result = mongoTemplate.updateFirst(query, update, CollectionName.ACCOUNTS);
        return result.getModifiedCount() != 0;
    }

    @Override
    public List<BeowulfAccount> findCreatedAccount(ObjectId startId, int limit, String creator, String direction) {
        Pair<String, Object> creatorFilter = Pair.of("creator", creator);
        Query query = Common.buildPagingQuery(Constant.ID_KEY, startId, limit, direction, creatorFilter);
        return mongoTemplate.find(query, BeowulfAccount.class);
    }

    @Override
    public void updateAccountId(String name, long accountId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").is(name));
        Update update = new Update();
        update.set("accountId", accountId);
        mongoTemplate.findAndModify(query, update, BeowulfAccount.class);
    }

    @Override
    public boolean increaseAccountId(ObjectId id, long accountId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        Update update = new Update();
        update.inc("accountId", accountId);
        UpdateResult result = mongoTemplate.updateFirst(query, update, CollectionName.ACCOUNTS);
        return result.getModifiedCount() != 0;
    }

    @Override
    public List<BeowulfAccount> findValidAccounts(ObjectId startId, int limit) {
        Query query = new Query();
        if (startId != null && StringUtils.hasText(startId.toString())) {
            query.addCriteria(Criteria.where("_id").gt(startId));
        }
        query.with(Sort.by(Sort.Direction.ASC, "_id"));
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfAccount.class, CollectionName.ACCOUNTS);
    }

    @Override
    public List<BeowulfAccount> findAccountID(int accountId, int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where("accountId").is(0).and("name").ne("null"));
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfAccount.class, CollectionName.ACCOUNTS);
    }

    @Override
    public List<BeowulfAccount> getBeowulfAccountByPaging(ObjectId start_id, int limit, String direction) {
        Query query = Common.buildPagingQuery(Constant.ID_KEY, start_id, limit, direction, null);
        return mongoTemplate.find(query, BeowulfAccount.class);
    }

    @Override
    public List<BeowulfAccount> getAccountMultisigByPaging(ObjectId start_id, int limit, String direction, String multisig) {
        Query query = new Query();
        if (start_id != null) {
            if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction)) {
                query.addCriteria(Criteria.where("_id").gt(start_id));
                query.with(Sort.by(Sort.Direction.ASC, "_id"));
            } else if (Constant.LIST_DIRECTION_NEXT.equals(direction)) {
                query.addCriteria(Criteria.where("_id").lt(start_id));
                query.with(Sort.by(Sort.Direction.DESC, "_id"));
            }
        } else {
            query.with(Sort.by(Sort.Direction.DESC, "_id"));
        }
        if (multisig != null && !multisig.isEmpty()) {
            if (multisig.equals("true")) {
                query.addCriteria(Criteria.where("multisig").is(true));
            } else if (multisig.equals("false")) {
                query.addCriteria(Criteria.where("multisig").is(false));
            }
        }
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfAccount.class);
    }

    private boolean removeAccountBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        DeleteResult result = mongoTemplate.remove(query, BeowulfAccount.class, CollectionName.ACCOUNTS);
        return result.getDeletedCount() != 0;
    }

    @Override
    public boolean removeAccountByAccountName(String accountName) {
        Pair<String, Object> filterName = Pair.of("name", accountName);
        return removeAccountBy(filterName);
    }

    @Override
    public boolean decreaseDataOfSupernode(String supernodeName, long blockReward, long totalFee, long totalOperations) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").is(supernodeName));
        Update update = new Update();
        update.inc("total_mined_block", -1);
        update.inc("total_mined_reward.amount", -blockReward);
        update.inc("total_mined_fee.amount", -totalFee);
        update.inc("total_confirmed_operation", -totalOperations);
        UpdateResult result = mongoTemplate.updateFirst(query, update, CollectionName.ACCOUNTS);
        return result.getModifiedCount() != 0;
    }

    @Override
    public boolean updateAccountInfo(AccountUpdateData operation) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").is(operation.getAccount()));
        Update update = new Update();
        update.set("permissions", operation.getOwner());
        update.set("multisig", Common.isMultisigAccount(operation.getOwner()));
        UpdateResult result = mongoTemplate.updateFirst(query, update, CollectionName.ACCOUNTS);
        return result.getModifiedCount() != 0;
    }
}
