package com.beowulf.model.aggregate;

public class AggregateBlockReward {
	
	private String supernode;
	private long numberBlock;
	private long totalBlockReward;

	public String getSupernode() {
		return supernode;
	}
	
	public void setSupernode(String supernode) {
		this.supernode = supernode;
	}

	public long getNumberBlock() {
		return numberBlock;
	}

	public void setNumberBlock(long numberBlock) {
		this.numberBlock = numberBlock;
	}

	public long getTotalBlockReward() {
		return totalBlockReward;
	}

	public void setTotalBlockReward(long totalBlockReward) {
		this.totalBlockReward = totalBlockReward;
	}

}
