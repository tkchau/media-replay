package com.beowulf.model.request;

/**
 * @author tatrongcau
 * @project beowulf-services
 * @time 2019-09-24
 */
public class BeowulfCreateWebhookRequest {
    private String account_name;
    private String url;

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
