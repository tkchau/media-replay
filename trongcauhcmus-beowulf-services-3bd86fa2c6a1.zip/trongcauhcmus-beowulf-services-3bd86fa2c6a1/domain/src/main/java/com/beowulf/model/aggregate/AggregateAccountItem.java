package com.beowulf.model.aggregate;

public class AggregateAccountItem {

    private int daily_inc_account;

    public AggregateAccountItem() {
    }

    public int getDaily_inc_account() {
        return daily_inc_account;
    }

    public void setDaily_inc_account(int daily_inc_account) {
        this.daily_inc_account = daily_inc_account;
    }

}
