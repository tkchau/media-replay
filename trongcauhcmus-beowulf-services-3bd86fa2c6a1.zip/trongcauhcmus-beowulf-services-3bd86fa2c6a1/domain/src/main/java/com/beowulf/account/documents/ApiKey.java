package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.API_KEYS)
public class ApiKey {
    private ObjectId id;

    @Indexed(unique = true)
    private String api_key;
    @Indexed(unique = true)
    private String api_name;
    private String access_token;
    private String status;
    @Indexed
    private long created_at;
    private long updated_at;
    private String api_key_level;
    private long create_wallet_counting_per_day;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getApi_key() {
        return api_key;
    }

    public void setApi_key(String api_key) {
        this.api_key = api_key;
    }

    public String getApi_name() {
        return api_name;
    }

    public void setApi_name(String api_name) {
        this.api_name = api_name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }

    public long getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(long updated_at) {
        this.updated_at = updated_at;
    }

    public String getApi_key_level() {
        return api_key_level;
    }

    public void setApi_key_level(String api_key_level) {
        this.api_key_level = api_key_level;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public long getCreate_wallet_counting_per_day() {
        return create_wallet_counting_per_day;
    }

    public void setCreate_wallet_counting_per_day(long create_wallet_counting_per_day) {
        this.create_wallet_counting_per_day = create_wallet_counting_per_day;
    }
}
