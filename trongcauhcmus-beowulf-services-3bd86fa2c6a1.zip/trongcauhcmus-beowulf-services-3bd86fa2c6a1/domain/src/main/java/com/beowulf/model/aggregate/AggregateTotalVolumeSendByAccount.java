package com.beowulf.model.aggregate;

public class AggregateTotalVolumeSendByAccount {
	private String supernode;
	private long numberTransaction;
	private long volume;

	public String getSupernode() {
		return supernode;
	}
	
	public void setSupernode(String supernode) {
		this.supernode = supernode;
	}

	public long getNumberTransaction() {
		return numberTransaction;
	}

	public void setNumberTransaction(long numberTransaction) {
		this.numberTransaction = numberTransaction;
	}

	public long getVolume() {
		return volume;
	}

	public void setVolume(long volume) {
		this.volume = volume;
	}

}
