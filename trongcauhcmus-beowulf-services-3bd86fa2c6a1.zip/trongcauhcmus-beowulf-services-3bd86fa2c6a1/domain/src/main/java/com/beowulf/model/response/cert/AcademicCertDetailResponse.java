package com.beowulf.model.response.cert;

import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.document.certdata.AcademicCertificateData;

public class AcademicCertDetailResponse {
    private String transaction_id;
    private AcademicCertificateData cert_data;

    public AcademicCertDetailResponse() {
    }

    public AcademicCertDetailResponse(BeowulfAcademicCertificate certificate) {
        this.transaction_id = certificate.getTransaction_id();
        this.cert_data = certificate.getData();
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public AcademicCertificateData getCert_data() {
        return cert_data;
    }

    public void setCert_data(AcademicCertificateData cert_data) {
        this.cert_data = cert_data;
    }
}