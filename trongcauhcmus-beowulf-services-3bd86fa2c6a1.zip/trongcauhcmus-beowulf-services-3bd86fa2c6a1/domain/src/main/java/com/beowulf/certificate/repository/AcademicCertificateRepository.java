package com.beowulf.certificate.repository;

import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.repository.extend.AcademicCertificateRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface AcademicCertificateRepository extends MongoRepository<BeowulfAcademicCertificate, ObjectId>, AcademicCertificateRepositoryExtend {
    @Query(value = "{'transaction_id': ?0}")
    BeowulfAcademicCertificate findBeowulfAcademicCertificateByTransaction_id(String transactionId);
}
