package com.beowulf.validator;

import com.beowulf.annotations.DateTimeValidated;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeValidator implements ConstraintValidator<DateTimeValidated, String> {

    private SimpleDateFormat sdf;

    @Override
    public void initialize(DateTimeValidated constraintAnnotation) {
        String pattern = constraintAnnotation.pattern();
        sdf = new SimpleDateFormat(pattern);
        sdf.setLenient(false);
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        if (object == null) {
            return false;
        }

        try {
            Date date = sdf.parse(object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
