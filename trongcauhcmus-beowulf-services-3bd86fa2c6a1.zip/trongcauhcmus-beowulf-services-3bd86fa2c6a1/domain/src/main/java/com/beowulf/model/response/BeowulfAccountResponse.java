package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.enums.AssetSymbolType;

public class BeowulfAccountResponse {
    private String id;
    private String name;
    private String creator;
    private AuthorityData permissions;
    private long created_at;
    private String created_operation_id;
    private long created_block;
    private long total_mined_block = 0L;
    private Asset total_mined_fee = new Asset(0L, AssetSymbolType.W);
    private Asset total_mined_reward = new Asset(0L, AssetSymbolType.M);
    private long total_confirmed_operation = 0L;

    public BeowulfAccountResponse() {
    }

    public BeowulfAccountResponse(BeowulfAccount beowulfAccount) {
        this.id = beowulfAccount.getId().toHexString();
        this.name = beowulfAccount.getName();
        this.creator = beowulfAccount.getCreator();
        this.permissions = beowulfAccount.getPermissions();
        this.created_at = beowulfAccount.getCreated_at();
        this.created_operation_id = beowulfAccount.getCreated_operation_id();
        this.created_block = beowulfAccount.getCreated_block();
        this.total_mined_block = beowulfAccount.getTotal_mined_block();
        this.total_mined_fee = beowulfAccount.getTotal_mined_fee();
        this.total_mined_reward = beowulfAccount.getTotal_mined_reward();
        this.total_confirmed_operation = beowulfAccount.getTotal_confirmed_operation();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public AuthorityData getPermissions() {
        return permissions;
    }

    public void setPermissions(AuthorityData permissions) {
        this.permissions = permissions;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }

    public String getCreated_operation_id() {
        return created_operation_id;
    }

    public void setCreated_operation_id(String created_operation_id) {
        this.created_operation_id = created_operation_id;
    }

    public long getCreated_block() {
        return created_block;
    }

    public void setCreated_block(long created_block) {
        this.created_block = created_block;
    }

    public long getTotal_mined_block() {
        return total_mined_block;
    }

    public void setTotal_mined_block(long total_mined_block) {
        this.total_mined_block = total_mined_block;
    }

    public Asset getTotal_mined_fee() {
        return total_mined_fee;
    }

    public void setTotal_mined_fee(Asset total_mined_fee) {
        this.total_mined_fee = total_mined_fee;
    }

    public Asset getTotal_mined_reward() {
        return total_mined_reward;
    }

    public void setTotal_mined_reward(Asset total_mined_reward) {
        this.total_mined_reward = total_mined_reward;
    }

    public long getTotal_confirmed_operation() {
        return total_confirmed_operation;
    }

    public void setTotal_confirmed_operation(long total_confirmed_operation) {
        this.total_confirmed_operation = total_confirmed_operation;
    }
}
