package com.beowulf.annotations;

import com.beowulf.validator.DragCaptchaValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DragCaptchaValidator.class)
@Documented
public @interface DragCaptchaValidated {
    String message() default "Captcha is invalid";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    String name() default "captcha";

    String bypass() default "vungoimora";

    @Target({ElementType.FIELD, ElementType.PARAMETER})
    @Retention(RetentionPolicy.RUNTIME)
    @Documented
    public @interface List {
        DragCaptchaValidated[] value();
    }
}
