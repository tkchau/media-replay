package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.operations.OperationData;
import com.beowulf.model.BeowulfData;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.DateTimeUtils;
import com.beowulfchain.beowulfj.enums.OperationType;

public class OperationDetailResponse {

    private String id;
    private String operation_id;
    private OperationType type;
    private long block_num;
    private String transaction_id;
    private int transaction_num;
    private OperationData operation;
    private long timestamp;

    public OperationDetailResponse() {
    }

    public OperationDetailResponse(BeowulfOperation beowulfOperation) {
        this.id = beowulfOperation.getBc_id().toHexString();
        BeowulfData bcData = Common.dataFromObjectId(beowulfOperation.getBc_id());
        this.block_num = bcData.getBlockNum();
        this.operation_id = beowulfOperation.getOperation_id();
        this.type = beowulfOperation.getType();
        this.transaction_id = beowulfOperation.getTransaction_id();
        this.transaction_num = bcData.getTxIndex();
        this.operation = beowulfOperation.getOperation();
        this.timestamp = DateTimeUtils.getTimestampMillsFromObjectId(beowulfOperation.getBc_id());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOperation_id() {
        return operation_id;
    }

    public void setOperation_id(String operation_id) {
        this.operation_id = operation_id;
    }

    public OperationType getType() {
        return type;
    }

    public void setType(OperationType type) {
        this.type = type;
    }

    public long getBlock_num() {
        return block_num;
    }

    public void setBlock_num(long block_num) {
        this.block_num = block_num;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public int getTransaction_num() {
        return transaction_num;
    }

    public void setTransaction_num(int transaction_num) {
        this.transaction_num = transaction_num;
    }

    public OperationData getOperation() {
        return operation;
    }

    public void setOperation(OperationData operation) {
        this.operation = operation;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
