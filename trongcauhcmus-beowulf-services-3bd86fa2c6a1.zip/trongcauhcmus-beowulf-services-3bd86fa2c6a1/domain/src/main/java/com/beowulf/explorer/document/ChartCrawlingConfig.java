package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.model.chart.record.ChartDailyRecord;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.CHART_CRAWLING_CONFIG)
public class ChartCrawlingConfig {

    @Id
    ObjectId id;

    @Indexed(unique = true)
    private String node_url;

    private long last_crawl_date;

    private long last_crawl_time_cursor;

    private ChartDailyRecord last_crawl_record;

    public ChartCrawlingConfig() {
    }

    public String getNode_url() {
        return node_url;
    }

    public void setNode_url(String node_url) {
        this.node_url = node_url;
    }

    public long getLast_crawl_date() {
        return last_crawl_date;
    }

    public void setLast_crawl_date(long last_crawl_date) {
        this.last_crawl_date = last_crawl_date;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public long getLast_crawl_time_cursor() {
        return last_crawl_time_cursor;
    }

    public void setLast_crawl_time_cursor(long last_crawl_time_cursor) {
        this.last_crawl_time_cursor = last_crawl_time_cursor;
    }

    public ChartDailyRecord getLast_crawl_record() {
        return last_crawl_record;
    }

    public void setLast_crawl_record(ChartDailyRecord last_crawl_record) {
        this.last_crawl_record = last_crawl_record;
    }
}
