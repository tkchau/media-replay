/*
 * Copyright (c) 2018.
 * @author TrongCauTa - trongcauhcmus@gmail.com
 * @version 4/16/18 10:11 AM
 */

package com.beowulf.hook.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.model.request.BeowulfCreateWebhookRequest;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.COL_BWF_ACCOUNT)
public class BeowulfAccountWebhook {
    ObjectId id;

    @Indexed(unique = true)
    private String account_name;
    private String url;

    public BeowulfAccountWebhook() {
    }

    public BeowulfAccountWebhook(BeowulfCreateWebhookRequest request) {
        this.setAccount_name(request.getAccount_name());
        this.setUrl(request.getUrl());
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
