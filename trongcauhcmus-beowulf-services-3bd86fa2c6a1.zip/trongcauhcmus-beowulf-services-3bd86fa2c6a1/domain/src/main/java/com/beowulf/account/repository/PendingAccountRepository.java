package com.beowulf.account.repository;

import com.beowulf.account.documents.PendingAccount;
import com.beowulf.account.repository.extend.PendingAccountRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface PendingAccountRepository extends MongoRepository<PendingAccount, ObjectId>, PendingAccountRepositoryExtend {

    @Query(value = "{'account_name': ?0}")
    PendingAccount findPendingAccountByName(String account_name);

    @Query(value = "{'pub_key': ?0}")
    PendingAccount findAccountPendingAccountByAddress(String address);

    @Query(value = "{'count': ?0}")
    List<PendingAccount> findPendingAccountsByCount(int count);

}
