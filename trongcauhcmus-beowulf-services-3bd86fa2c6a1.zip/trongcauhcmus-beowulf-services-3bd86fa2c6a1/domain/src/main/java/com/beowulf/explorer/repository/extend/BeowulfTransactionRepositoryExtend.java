package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfTransaction;
import org.bson.types.ObjectId;

import java.util.List;

public interface BeowulfTransactionRepositoryExtend {

    List<BeowulfTransaction> getTransactionPaging(ObjectId startId, int limit, String direction);

    boolean removeTransactionById(ObjectId id);

    boolean removeTransactionByTransactionId(String transactionId);

    List<BeowulfTransaction> getTransactionPagingByBlockId(String blockId, int position, int limit, String direction);

    List<BeowulfTransaction> getTransactionPagingByRegexBlockId(String refBlockId, int position, int limit, String direction);

    List<BeowulfTransaction> findByRegexBlock_id(String refBlockId);
}
