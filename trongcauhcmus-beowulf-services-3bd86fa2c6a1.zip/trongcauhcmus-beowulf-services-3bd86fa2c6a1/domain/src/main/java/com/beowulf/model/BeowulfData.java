package com.beowulf.model;

public class BeowulfData {

    private long blockNum;

    private int txIndex;

    private int opIndex;

    private long blockTime;

    public BeowulfData() {
    }

    public BeowulfData(long blockNum, int txIndex, int opIndex, long blockTime) {
        this.blockNum = blockNum;
        this.txIndex = txIndex;
        this.opIndex = opIndex;
        this.blockTime = blockTime;
    }

    public long getBlockNum() {
        return blockNum;
    }

    public void setBlockNum(long blockNum) {
        this.blockNum = blockNum;
    }

    public int getTxIndex() {
        return txIndex;
    }

    public void setTxIndex(int txIndex) {
        this.txIndex = txIndex;
    }

    public int getOpIndex() {
        return opIndex;
    }

    public void setOpIndex(int opIndex) {
        this.opIndex = opIndex;
    }

    public long getBlockTime() {
        return blockTime;
    }

    public void setBlockTime(long blockTime) {
        this.blockTime = blockTime;
    }

    String toSting() {
        return "" + blockNum + ":" + txIndex + ":" + opIndex + ":" + blockTime;
    }
}
