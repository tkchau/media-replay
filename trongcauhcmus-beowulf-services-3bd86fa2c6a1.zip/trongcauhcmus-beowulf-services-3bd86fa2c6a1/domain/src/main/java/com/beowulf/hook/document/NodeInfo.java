package com.beowulf.hook.document;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.NODE_LIST)
public class NodeInfo {
    ObjectId id;
    @Indexed(unique = true)
    private String node_url;
    private long last_sync;
    private String type;

    public String getNode_url() {
        return node_url;
    }

    public void setNode_url(String node_url) {
        this.node_url = node_url;
    }

    public long getLast_sync() {
        return last_sync;
    }

    public void setLast_sync(long last_sync) {
        this.last_sync = last_sync;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
