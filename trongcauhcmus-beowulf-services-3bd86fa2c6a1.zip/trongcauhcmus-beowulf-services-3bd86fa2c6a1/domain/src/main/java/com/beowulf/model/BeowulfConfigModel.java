package com.beowulf.model;

import com.beowulf.config.document.Configuration;

public class BeowulfConfigModel extends Configuration {
    private String beowulf_node;
    private String credential_account_beowulf_default;
    private String credential_account_beowulf_cipherPrivkey;
    private long last_block;

    public BeowulfConfigModel() {
        this.setKey("beowulf_config");
        this.setBeowulf_node("https://testnet-bw.beowulfchain.com/rpc");
        this.setCredential_account_beowulf_default("caubeo1");
        this.setCredential_account_beowulf_cipherPrivkey("vG4yLIqLprpXWjWU6xbX3rtSfummp34neaI5NiK/iOw9Wxogybsk/iVyTiNooMCVK9eax3KgziH7WUlEAZ3pwQ==");
        this.setLast_block(0L);
    }

    public String getBeowulf_node() {
        return beowulf_node;
    }

    public void setBeowulf_node(String beowulf_node) {
        this.beowulf_node = beowulf_node;
    }

    public String getCredential_account_beowulf_default() {
        return credential_account_beowulf_default;
    }

    public void setCredential_account_beowulf_default(String credential_account_beowulf_default) {
        this.credential_account_beowulf_default = credential_account_beowulf_default;
    }

    public String getCredential_account_beowulf_cipherPrivkey() {
        return credential_account_beowulf_cipherPrivkey;
    }

    public void setCredential_account_beowulf_cipherPrivkey(String credential_account_beowulf_cipherPrivkey) {
        this.credential_account_beowulf_cipherPrivkey = credential_account_beowulf_cipherPrivkey;
    }

    public long getLast_block() {
        return last_block;
    }

    public void setLast_block(long last_block) {
        this.last_block = last_block;
    }
}
