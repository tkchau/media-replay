package com.beowulf.model.request;

public class ListTransactionPagingRequest extends ListObjectsPagingRequest {

}
