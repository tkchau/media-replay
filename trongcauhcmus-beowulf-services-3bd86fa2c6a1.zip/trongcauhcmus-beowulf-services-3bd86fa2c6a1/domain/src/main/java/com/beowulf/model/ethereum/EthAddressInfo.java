/*
 * Copyright (c) 2019.
 * At 1/28/19 11:11 AM
 * Trong Cau Ta
 */

package com.beowulf.model.ethereum;

public class EthAddressInfo {
    private String address;
    private String privkey;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrivkey() {
        return privkey;
    }

    public void setPrivkey(String privkey) {
        this.privkey = privkey;
    }
}
