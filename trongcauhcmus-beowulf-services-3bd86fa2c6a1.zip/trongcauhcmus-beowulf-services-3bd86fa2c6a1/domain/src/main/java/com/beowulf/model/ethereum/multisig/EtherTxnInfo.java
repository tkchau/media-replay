package com.beowulf.model.ethereum.multisig;

import com.beowulf.utilities.Numeric;
import org.spongycastle.pqc.math.linearalgebra.ByteUtils;

import java.math.BigInteger;

public class EtherTxnInfo extends TxnInfo {
    private byte[] data;

    public EtherTxnInfo() {
    }

    public EtherTxnInfo(String receiver, BigInteger value, byte[] data, BigInteger expireTime, BigInteger sequenceId) {
        super(receiver, value, expireTime, sequenceId);
        setData(data);
    }

    @Override
    public byte[] serialize() {
        byte[] prefix = "ETHER".getBytes();
        if (receiver.startsWith("0x")) {
            receiver = receiver.substring(2);
        }
        // decode address to 20 bytes
        byte[] receiverByte = ByteUtils.fromHexString(receiver);
        // uint need to padding data enough 32 bytes
        return Numeric.concat(prefix,
                receiverByte,
                Numeric.paddingUint256(value.toByteArray()),
                data,
                Numeric.paddingUint256(expireTime.toByteArray()),
                Numeric.paddingUint256(sequenceId.toByteArray()));
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = new byte[data.length];
        System.arraycopy(data, 0, this.data, 0, data.length);
    }
}
