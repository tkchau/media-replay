package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfBlock;

import java.util.List;

public class BlockDetailExtendResponse extends BlockDetailResponse {
    private List<String> transaction_ids;

    public BlockDetailExtendResponse() {
    }

    public BlockDetailExtendResponse(BeowulfBlock beowulfBlock) {
        super(beowulfBlock);
    }

    public List<String> getTransaction_ids() {
        return transaction_ids;
    }

    public void setTransaction_ids(List<String> transaction_ids) {
        this.transaction_ids = transaction_ids;
    }
}
