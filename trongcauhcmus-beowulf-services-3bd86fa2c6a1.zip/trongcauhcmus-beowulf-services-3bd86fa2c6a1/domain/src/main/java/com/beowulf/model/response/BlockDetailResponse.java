package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.enums.AssetSymbolType;

public class BlockDetailResponse {

    private String id;

    private String block_id;

    private long block_number;

    private long timestamp;

    private String supernode;

    private int number_transaction;

    private String total_fee;

    private String block_reward;

    private String supernode_signature;

    public BlockDetailResponse() {
    }

    public BlockDetailResponse(BeowulfBlock beowulfBlock) {
        this.id = beowulfBlock.getBc_id().toHexString();
        this.block_id = beowulfBlock.getBlock_id();
        this.block_number = beowulfBlock.getBlock_number();
        this.timestamp = beowulfBlock.getTimestamp();
        this.supernode = beowulfBlock.getSupernode();
        this.block_reward = new Asset(beowulfBlock.getBlock_reward(), AssetSymbolType.M).toString();
        this.supernode_signature = beowulfBlock.getSupernode_signature();
        this.total_fee = new Asset(beowulfBlock.getTotal_fee(), AssetSymbolType.W).toString();
        this.number_transaction = beowulfBlock.getNumber_transaction();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBlock_id() {
        return block_id;
    }

    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public long getBlock_number() {
        return block_number;
    }

    public void setBlock_number(long block_number) {
        this.block_number = block_number;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getSupernode() {
        return supernode;
    }

    public void setSupernode(String supernode) {
        this.supernode = supernode;
    }

    public int getNumber_transaction() {
        return number_transaction;
    }

    public void setNumber_transaction(int number_transaction) {
        this.number_transaction = number_transaction;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getBlock_reward() {
        return block_reward;
    }

    public void setBlock_reward(String block_reward) {
        this.block_reward = block_reward;
    }

    public String getSupernode_signature() {
        return supernode_signature;
    }

    public void setSupernode_signature(String supernode_signature) {
        this.supernode_signature = supernode_signature;
    }

}

