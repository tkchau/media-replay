package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.ChartCrawlingConfig;
import com.beowulf.explorer.repository.extend.ChartCrawlingConfigRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ChartCrawlingConfigRepository extends MongoRepository<ChartCrawlingConfig, ObjectId>, ChartCrawlingConfigRepositoryExtend {
}
