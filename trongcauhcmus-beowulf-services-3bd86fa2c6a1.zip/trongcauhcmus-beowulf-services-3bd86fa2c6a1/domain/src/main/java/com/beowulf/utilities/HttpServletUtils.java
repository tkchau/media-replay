package com.beowulf.utilities;

import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class HttpServletUtils {
    public static String getClientIP(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null | StringUtils.isEmpty(xfHeader)) {
            return request.getRemoteAddr();
        }
        String[] ipStack = xfHeader.split(",");
        return ipStack[ipStack.length - 1];
    }

    public static void doFilter(HttpServletRequest httpServletRequest, int rate, TimeUnit timeUnit) {
        String clientIpAddress = HttpServletUtils.getClientIP(httpServletRequest);
        switch (timeUnit) {
            case SECONDS:
                if (isMaximumRequestsPerSecondExceeded(clientIpAddress, rate))
                    throw ServiceExceptionUtils.tooManyRequest();
                break;
            case MINUTES:
                if (isMaximumRequestsPerMinuteExceeded(clientIpAddress, rate))
                    throw ServiceExceptionUtils.tooManyRequest();
                break;
            case HOURS:
                if (isMaximumRequestsPerHourExceeded(clientIpAddress, rate))
                    throw ServiceExceptionUtils.tooManyRequest();
                break;
            case DAYS:
                if (isMaximumRequestsPerDayExceeded(clientIpAddress, rate))
                    throw ServiceExceptionUtils.tooManyRequest();
                break;
            default:
                throw ServiceExceptionUtils.tooManyRequest();
        }
    }

    public static boolean isMaximumRequestsPerSecondExceeded(String clientIpAddress, int rate) {
        int requests;
        try {
            requests = RequestRateCaching.getPerSecond(clientIpAddress);
            if (requests >= rate)
                return true;
        } catch (ExecutionException e) {
            requests = 0;
        }
        requests++;
        RequestRateCaching.putPerSecond(clientIpAddress, requests);
        return false;
    }

    public static boolean isMaximumRequestsPerMinuteExceeded(String clientIpAddress, int rate) {
        int requests;
        try {
            requests = RequestRateCaching.getPerMinute(clientIpAddress);
            if (requests >= rate)
                return true;
        } catch (ExecutionException e) {
            requests = 0;
        }
        requests++;
        RequestRateCaching.putPerMinute(clientIpAddress, requests);
        return false;
    }

    public static boolean isMaximumRequestsPerHourExceeded(String clientIpAddress, int rate) {
        int requests;
        try {
            requests = RequestRateCaching.getPerHour(clientIpAddress);
            if (requests >= rate)
                return true;
        } catch (ExecutionException e) {
            requests = 0;
        }
        requests++;
        RequestRateCaching.putPerHour(clientIpAddress, requests);
        return false;
    }

    public static boolean isMaximumRequestsPerDayExceeded(String clientIpAddress, int rate) {
        int requests;
        try {
            requests = RequestRateCaching.getPerDay(clientIpAddress);
            if (requests >= rate)
                return true;
        } catch (ExecutionException e) {
            requests = 0;
        }
        requests++;
        RequestRateCaching.putPerDay(clientIpAddress, requests);
        return false;
    }

    public static void decreaseRequest(HttpServletRequest request, TimeUnit timeUnit) {
        try {
            String ip = HttpServletUtils.getClientIP(request);
            int rate = RequestRateCaching.get(ip, timeUnit);
            RequestRateCaching.put(ip, rate - 1, timeUnit);
        } catch (ExecutionException e) {
            LoggerUtil.d(HttpServletUtils.class, "can't decrease not found ip");
        }
    }
}
