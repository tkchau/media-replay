package com.beowulf.model.request;

public class ListBeowulfOperationPagingRequest extends ListObjectsPagingRequest {

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
	}
}
