package com.beowulf.constants;

public class AccountRole {
    public static final int ANONYMOUS_ROLE = 0;

    public static final int API_KEY_ROLE = 1;

    public static final String TEXT_ROLE_ANONYMOUS = "ROLE_ANONYMOUS";
    public static final String TEXT_ROLE_API_KEY = "ROLE_API_KEY";
}
