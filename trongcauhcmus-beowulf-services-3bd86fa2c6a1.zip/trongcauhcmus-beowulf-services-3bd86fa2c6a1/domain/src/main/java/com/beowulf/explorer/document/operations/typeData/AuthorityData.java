package com.beowulf.explorer.document.operations.typeData;

import com.beowulfchain.beowulfj.protocol.AccountName;
import com.beowulfchain.beowulfj.protocol.Authority;
import com.beowulfchain.beowulfj.protocol.PublicKey;

import java.util.LinkedHashMap;

public class AuthorityData {
    private long weightThreshold;
    private LinkedHashMap<String, Integer> accountAuths;
    private LinkedHashMap<String, Integer> keyAuths;

    public AuthorityData(){

    }

    public AuthorityData(Authority authority){
        this.weightThreshold = authority.getWeightThreshold();
        this.accountAuths = new LinkedHashMap<>();
        for (AccountName accountName : authority.getAccountAuths().keySet()) {
            this.accountAuths.put(accountName.getName(), authority.getAccountAuths().get(accountName));
        }
        this.keyAuths = new LinkedHashMap<>();
        for (PublicKey publicKey : authority.getKeyAuths().keySet()){
            this.keyAuths.put(publicKey.getAddressFromPublicKey(), authority.getKeyAuths().get(publicKey));
        }
    }

    public long getWeightThreshold() {
        return weightThreshold;
    }

    public void setWeightThreshold(long weightThreshold) {
        this.weightThreshold = weightThreshold;
    }

    public LinkedHashMap<String, Integer> getAccountAuths() {
        return accountAuths;
    }

    public void setAccountAuths(LinkedHashMap<String, Integer> accountAuths) {
        this.accountAuths = accountAuths;
    }

    public LinkedHashMap<String, Integer> getKeyAuths() {
        return keyAuths;
    }

    public void setKeyAuths(LinkedHashMap<String, Integer> keyAuths) {
        this.keyAuths = keyAuths;
    }
}
