package com.beowulf.model.response;

public class BeowulfCreateMultisigAccountResponse {
    private String txid;
    private long blockNum;
    private long trxNum;
    private boolean expired;
    private long createdTime;

    public BeowulfCreateMultisigAccountResponse(String txid) {
        this.txid = txid;
    }

    public BeowulfCreateMultisigAccountResponse(String txid, long blockNum, long trxNum, boolean expired, long createdTime) {
        this.txid = txid;
        this.blockNum = blockNum;
        this.trxNum = trxNum;
        this.expired = expired;
        this.createdTime = createdTime;
    }

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public long getBlockNum() {
        return blockNum;
    }

    public void setBlockNum(long blockNum) {
        this.blockNum = blockNum;
    }

    public long getTrxNum() {
        return trxNum;
    }

    public void setTrxNum(long trxNum) {
        this.trxNum = trxNum;
    }

    public boolean isExpired() {
        return expired;
    }

    public void setExpired(boolean expired) {
        this.expired = expired;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }
}
