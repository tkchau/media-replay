package com.beowulf.explorer.document.extensions;

import com.beowulfchain.beowulfj.protocol.extensions.JsonExtension;

public class JsonExtensionData extends ExtensionData {
    private String data;

    public JsonExtensionData() {
    }

    public JsonExtensionData(JsonExtension jsonExtension) {
        this.data = jsonExtension.getValue().getData();
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
