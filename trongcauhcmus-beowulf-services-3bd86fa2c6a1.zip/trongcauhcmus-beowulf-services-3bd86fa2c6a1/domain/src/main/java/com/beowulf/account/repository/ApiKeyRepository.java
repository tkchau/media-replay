package com.beowulf.account.repository;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.repository.extend.ApiKeyRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface ApiKeyRepository extends MongoRepository<ApiKey, ObjectId>, ApiKeyRepositoryExtend {
    @Query(value = "{'api_key' : ?0}")
    public ApiKey findApiKeyByApiKeyId(String apiKey);
}
