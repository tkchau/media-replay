package com.beowulf.account.repository.impl;

import com.beowulf.account.documents.AddressPayment;
import com.beowulf.account.repository.extend.ETHAddressPaymentRepositoryExtend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class ETHAddressPaymentRepositoryImpl implements ETHAddressPaymentRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void updateStatus(String address, int status_address) {
        Query query = new Query();
        query.addCriteria(Criteria.where("address").is(address));
        Update update = new Update();
        update.set("status_address", status_address);
        mongoTemplate.findAndModify(query, update, AddressPayment.class);
    }

}
