package com.beowulf.account.repository.impl;

import com.beowulf.account.documents.AddressPayment;
import com.beowulf.account.documents.PendingAccount;
import com.beowulf.account.repository.extend.PendingAccountRepositoryExtend;
import com.beowulf.constants.CollectionName;
import com.mongodb.client.result.DeleteResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class PendingAccountRepositoryImpl implements PendingAccountRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean removeByAccountName(String account_name) {
        Query query = new Query();
        query.addCriteria(Criteria.where("account_name").is(account_name));
        DeleteResult result = mongoTemplate.remove(query, PendingAccount.class, CollectionName.ACCOUNT_CREATED);
        return result.getDeletedCount() != 0;
    }

    @Override
    public void updateCount(String address, int count) {
        Query query = new Query();
        query.addCriteria(Criteria.where("address").is(address));
        Update update = new Update();
        update.set("count", count);
        mongoTemplate.findAndModify(query, update, AddressPayment.class);
    }

}

