package com.beowulf.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Properties;

public class GeneralConfigProperties {
    private static GeneralConfigProperties appContext = new GeneralConfigProperties();

    private String mongo_host;
    private String mongo_databaseName;
    private String mongo_username;
    private String mongo_password;
    private boolean mongo_ssl;

    // Mail define
    private String company_name;
    private String company_mail_address;
    private String company_mail_AmazonAccessKey;
    private String company_mail_AmazonSecretKey;
    private String[] company_mail_admin;

    private String google_recaptcha_key;

    private GeneralConfigProperties() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext();
        Properties properties = new Properties();
        try {

            String configFile = System.getProperty("beowulf.conf");
            if (configFile == null) {
                configFile = "classpath:/bw-core.properties";
            }
            properties.load(appContext.getResource(configFile).getInputStream());

            // DATABASE GET PROPERTIES
            mongo_host = properties.getProperty("mongo.host", "localhost:57899");
            mongo_databaseName = properties.getProperty("mongo.databaseName", "mongoDatabaseName");
            mongo_username = properties.getProperty("mongo.username", "mongoUsername");
            mongo_password = properties.getProperty("mongo.password", "mongoEncryptedPassword");
            mongo_ssl = Boolean.parseBoolean(properties.getProperty("mongo.ssl", "true"));

            // Mail service
            company_name = properties.getProperty("company.name", "Beowulfchain Inc.");
            company_mail_address = properties.getProperty("company.mail.address", "noreply@beowulfchain.com");
            company_mail_AmazonAccessKey = properties.getProperty("company.mail.AmazonAccessKey");
            company_mail_AmazonSecretKey = properties.getProperty("company.mail.AmazonSecretKey");
            company_mail_admin = properties.getProperty("company.mail.admin").split(",");

            google_recaptcha_key = properties.getProperty("google.recaptcha.key", "6LecasQUAAAAAGsN8NraBJGcHz4MngsUU1y6TCBi");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static GeneralConfigProperties getInstance() {
        if (appContext == null) {
            appContext = new GeneralConfigProperties();
        }
        return appContext;
    }

    public String getMongo_host() {
        return mongo_host;
    }

    public String getMongo_databaseName() {
        return mongo_databaseName;
    }

    public String getMongo_username() {
        return mongo_username;
    }

    public String getMongo_password() {
        return mongo_password;
    }

    public boolean isMongo_ssl() {
        return mongo_ssl;
    }

    public String getCompany_name() {
        return company_name;
    }

    public String getCompany_mail_address() {
        return company_mail_address;
    }

    public String getCompany_mail_AmazonAccessKey() {
        return company_mail_AmazonAccessKey;
    }

    public String getCompany_mail_AmazonSecretKey() {
        return company_mail_AmazonSecretKey;
    }

    public String[] getCompany_mail_admin() {
        return company_mail_admin;
    }

    public String getGoogle_recaptcha_key() {
        return google_recaptcha_key;
    }
}
