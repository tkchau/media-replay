package com.beowulf.hook.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.model.TransactionReceipt;
import com.beowulf.utilities.GsonSingleton;
import com.beowulfchain.beowulfj.exceptions.BeowulfInvalidTransactionException;
import com.google.gson.JsonObject;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.COL_BWF_HOOK_HISTORY)
public class BeowulfTransactionReceipt extends TransactionReceipt {
    private String account;
    private String txid;
    private long amount;
    private String asset;
    private int confirmation;
    private String type;
    private String memo;

    public BeowulfTransactionReceipt() {
    }

    public BeowulfTransactionReceipt(String account, String txid, long amount, String asset, int confirmation, String type, String memo) {
        this.account = account;
        this.txid = txid;
        this.amount = amount;
        this.asset = asset;
        this.confirmation = confirmation;
        this.type = type;
        this.memo = memo;
    }

    public BeowulfTransactionReceipt mergeReceipt(BeowulfTransactionReceipt receipt) throws BeowulfInvalidTransactionException {
        if (!this.getTxid().equals(receipt.getTxid())
                || !this.getAccount().equals(receipt.getAccount())
                || !this.getAsset().equals(receipt.getAsset())) {
            throw new BeowulfInvalidTransactionException("merge action can not complete because two action is different hash or address");
        }

        long value1 = this.getAmount();
        long value2 = receipt.getAmount();
        if (this.getType().equals(receipt.getType())) {
            this.setAmount(value1 + value2);
        } else {
            if (value1 == value2) {
                this.setAmount(0L);
            } else if (value1 > value2) {
                this.setAmount(value1 - value2);
            } else {
                this.setType(receipt.getType());
                this.setAmount(value2 - value1);
            }
        }
        return this;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public int getConfirmation() {
        return confirmation;
    }

    public void setConfirmation(int confirmation) {
        this.confirmation = confirmation;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    @Override
    public String toJson() {
        JsonObject jsonObject = GsonSingleton.getInstance().toJsonTree(this).getAsJsonObject();
        return jsonObject.toString();
    }

    @Override
    public String toString() {
        return GsonSingleton.getInstance().toJson(this);
    }
}
