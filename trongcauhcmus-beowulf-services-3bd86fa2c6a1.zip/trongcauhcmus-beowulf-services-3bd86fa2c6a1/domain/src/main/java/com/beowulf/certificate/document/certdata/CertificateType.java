package com.beowulf.certificate.document.certdata;

public class CertificateType {
    public static final String LAND_CERTIFICATE = "land_cert";
    public static final String LAND_CERT_KEY_ID = "data.cert_id";
    public static final String ACADEMIC_CERTIFICATE = "academic_cert";
    public static final String ACADEMIC_CERT_KEY_ID = "data.serial_num";
    public static final String ACADEMIC_CERT_KEY_STUDENT_ID = "data.student_id";
}
