package com.beowulf.model.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class ListTransactionsBlockIdPagingRequest extends ListObjectsPagingRequest {

    @NotNull(message = "Block_id is required")
    @NotEmpty(message = "Block_id cannot be empty")
    @Size(min = 40)
    private String block_id;
    private int position;

    public ListTransactionsBlockIdPagingRequest() {
    }

    public String getBlock_id() {
        return block_id;
    }

    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
