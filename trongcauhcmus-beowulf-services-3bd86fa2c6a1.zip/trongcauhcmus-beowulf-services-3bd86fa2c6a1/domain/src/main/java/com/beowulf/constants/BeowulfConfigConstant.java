package com.beowulf.constants;

public class BeowulfConfigConstant {

	public static final String BEOWULF_SIP_GET_RELATED_TRANSACTION_TEST_URL = "http://bw-telecom-account-testnet/apiv1/explorer/transaction/related?transaction_id=";

	public static final String BEOWULF_SIP_GET_RELATED_TRANSACTION_PRODUCTION_URL = "https://tel.beowulfchain.com/apiv1/explorer/transaction/related?transaction_id=";
	
	public static final long MAX_CRAWLING_DATA_THREAD = 100;

	public static long NUMBER_CURRENT_CRAWLING_THREAD = 0;
	
	public static int MAX_SUPERNODE_RESULT = 1000;
}
