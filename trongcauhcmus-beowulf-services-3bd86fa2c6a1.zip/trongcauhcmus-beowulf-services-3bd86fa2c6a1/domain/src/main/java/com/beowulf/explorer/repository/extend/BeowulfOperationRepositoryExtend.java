package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.model.aggregate.AggregateAccountItem;
import com.beowulf.model.aggregate.AggregateAmountTransferItem;
import org.bson.types.ObjectId;

import java.util.List;

public interface BeowulfOperationRepositoryExtend {

    //Insert new Operation data to document
    boolean addNewOperation(BeowulfOperation newOperation);

    BeowulfOperation findBeowulfOperationByTransaction_idAndIndex(String transactionId, int indexOp);

    List<BeowulfOperation> findBeowulfOperationByTransactionId(String transactionId);

    List<BeowulfOperation> getListOperation(ObjectId startId, int limit, String direction, String type);

    long countOperationByAccount(String accountName);

    List<BeowulfOperation> getOperationByTransferAsset(ObjectId startId, int limit, String direction, String transfer_asset);

    List<BeowulfOperation> findBeowulfOperationByRelateAccount(ObjectId startId, String account, String direction, int limit, String type);

    boolean removeOperationById(ObjectId id);

    boolean removeOperationByOperationId(String operationId);

    AggregateAccountItem getTotalIncAccountDaily(ObjectId startId, ObjectId endId);

    List<AggregateAmountTransferItem> getTotalAmountTransferDaily(ObjectId startId, ObjectId endId);
}
