package com.beowulf.model.response;

public class HookResponseStatus {
    private boolean status;

    public HookResponseStatus() {
    }

    public HookResponseStatus(boolean status) {
        this.status = status;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
