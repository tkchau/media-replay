package com.beowulf.hook.repository;

import com.beowulf.hook.document.Action;
import com.beowulf.hook.repository.extend.HookActionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface HookActionRepository extends MongoRepository<Action, ObjectId>, HookActionRepositoryExtend {

}
