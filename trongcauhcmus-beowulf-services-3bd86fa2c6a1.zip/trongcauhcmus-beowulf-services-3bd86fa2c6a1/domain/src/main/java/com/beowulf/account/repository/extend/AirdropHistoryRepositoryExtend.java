package com.beowulf.account.repository.extend;

public interface AirdropHistoryRepositoryExtend {
    void removeByAccountName(String account_name);
}
