package com.beowulf.constants;

public class Constant {

	public static final int MAX_RECORD_RESPONSE = 50;

	public static final int MAX_TOKEN_HOLDER_RESPONSE = 200;

	public static final String SUPERNODE_CACHE_PRE_FIX = "Random_123_SN_";

	public static final String BLOCK_CACHE_PRE_FIX = "Abcxyz_456_BL_";

	public static final String TRANSACTION_CACHE_PRE_FIX = "TUVXYZ_789_TS_";

	public static final String LIST_DIRECTION_NEXT = "next";

	public static final String LIST_DIRECTION_PREVIOUS = "prev";

	public static final int MAX_HANDLE_TIMES = 5;

	public static final String PAGING_KEY = "bc_id";

	public static final String ID_KEY = "_id";

	public static final int CRAWLER_JUMPSTEP = 10000;
}
