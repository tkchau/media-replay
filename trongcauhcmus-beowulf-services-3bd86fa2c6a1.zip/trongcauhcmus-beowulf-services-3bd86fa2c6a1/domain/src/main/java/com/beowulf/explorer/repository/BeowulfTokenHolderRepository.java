package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfTokenHolder;
import com.beowulf.explorer.repository.extend.BeowulfTokenHolderRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BeowulfTokenHolderRepository extends MongoRepository<BeowulfTokenHolder, ObjectId>, BeowulfTokenHolderRepositoryExtend {

}