package com.beowulf.account.repository.extend;

public interface PendingAccountRepositoryExtend {

    boolean removeByAccountName(String account_name);

    void updateCount(String address, int count);

}
