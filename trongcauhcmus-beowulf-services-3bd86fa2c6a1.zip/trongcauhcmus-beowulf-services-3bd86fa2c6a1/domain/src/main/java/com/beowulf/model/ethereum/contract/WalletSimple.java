package com.beowulf.model.ethereum.contract;

import io.reactivex.Flowable;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.*;
import org.web3j.abi.datatypes.generated.Bytes32;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.1.0.
 */
@SuppressWarnings("ALL")
public class WalletSimple extends Contract {
    private static final String BINARY = "60606040526001805460ff19169055341561001957600080fd5b604051610e9f380380610e9f833981016040528080519091019050805160031461004257600080fd5b600081805161005592916020019061005c565b50506100ea565b8280548282559060005260206000209081019282156100b3579160200282015b828111156100b35782518254600160a060020a031916600160a060020a03919091161782556020929092019160019091019061007c565b506100bf9291506100c3565b5090565b6100e791905b808211156100bf578054600160a060020a03191681556001016100c9565b90565b610da6806100f96000396000f30060606040526004361061007f5763ffffffff60e060020a6000350416630dcd7a6c81146100f45780632079fb9a146101685780632da034091461019a57806339125215146101bf5780637df73e271461026f578063a0b7967b146102a2578063a68a76cc146102c7578063abe3219c146102da578063fc0f392d146102ed575b60003411156100f2577f6e89d517057028190560dd200cf6bf792842861353d1173761dfa362e1c133f03334600036604051600160a060020a0385168152602081018490526060604082018181529082018390526080820184848082843782019150509550505050505060405180910390a15b005b34156100ff57600080fd5b6100f260048035600160a060020a03908116916024803592604435169160643591608435919060c49060a43590810190830135806020601f8201819004810201604051908101604052818152929190602084018383808284375094965061030095505050505050565b341561017357600080fd5b61017e600435610431565b604051600160a060020a03909116815260200160405180910390f35b34156101a557600080fd5b6100f2600160a060020a0360043581169060243516610459565b34156101ca57600080fd5b6100f260048035600160a060020a03169060248035919060649060443590810190830135806020601f8201819004810201604051908101604052818152929190602084018383808284375094968635966020808201359750919550606081019450604090810135860180830194503592508291601f8301819004810201905190810160405281815292919060208401838380828437509496506104d895505050505050565b341561027a57600080fd5b61028e600160a060020a0360043516610718565b604051901515815260200160405180910390f35b34156102ad57600080fd5b6102b5610776565b60405190815260200160405180910390f35b34156102d257600080fd5b61017e6107bd565b34156102e557600080fd5b61028e6107e2565b34156102f857600080fd5b6100f26107eb565b60008061030c33610718565b151561031757600080fd5b87878787876040517f455243323000000000000000000000000000000000000000000000000000000081526c01000000000000000000000000600160a060020a03968716810260058301526019820195909552929094169092026039820152604d810191909152606d810191909152608d01604051809103902091506103a0888385888861084a565b5085905080600160a060020a031663a9059cbb898960006040516020015260405160e060020a63ffffffff8516028152600160a060020a0390921660048301526024820152604401602060405180830381600087803b151561040157600080fd5b6102c65a03f1151561041257600080fd5b50505060405180519050151561042757600080fd5b5050505050505050565b600080548290811061043f57fe5b600091825260209091200154600160a060020a0316905081565b600061046433610718565b151561046f57600080fd5b5081600160a060020a038116633ef133678360405160e060020a63ffffffff8416028152600160a060020a039091166004820152602401600060405180830381600087803b15156104bf57600080fd5b6102c65a03f115156104d057600080fd5b505050505050565b6000806104e433610718565b15156104ef57600080fd5b87878787876040517f455448455200000000000000000000000000000000000000000000000000000081526c01000000000000000000000000600160a060020a038716026005820152601981018590526039810184805190602001908083835b6020831061056e5780518252601f19909201916020918201910161054f565b6001836020036101000a038019825116818451161790925250505091909101938452505060208201526040908101935091505051809103902091506105b6888385888861084a565b905087600160a060020a0316878760405180828051906020019080838360005b838110156105ee5780820151838201526020016105d6565b50505050905090810190601f16801561061b5780820380516001836020036101000a031916815260200191505b5091505060006040518083038185876187965a03f192505050151561063f57600080fd5b7f59bed9ab5d78073465dd642a9e3e76dfdb7d53bcae9d09df7d0b8f5234d5a8063382848b8b8b604051600160a060020a038088168252868116602083015260408201869052841660608201526080810183905260c060a0820181815290820183818151815260200191508051906020019080838360005b838110156106cf5780820151838201526020016106b7565b50505050905090810190601f1680156106fc5780820380516001836020036101000a031916815260200191505b5097505050505050505060405180910390a15050505050505050565b6000805b60005481101561076b5782600160a060020a031660008281548110151561073f57fe5b600091825260209091200154600160a060020a031614156107635760019150610770565b60010161071c565b600091505b50919050565b600080805b600a8110156107b45781600282600a811061079257fe5b015411156107ac57600281600a81106107a757fe5b015491505b60010161077b565b50600101919050565b60006107c7610a44565b604051809103906000f08015156107dd57600080fd5b905090565b60015460ff1681565b6107f433610718565b15156107ff57600080fd5b6001805460ff1916811790557f0909e8f76a4fd3e970f2eaef56c0ee6dfaf8b87c5b8d3f56ffce78e825a9115733604051600160a060020a03909116815260200160405180910390a1565b60008061085786866108cf565b60015490915060ff168015610872575061087087610718565b155b1561087c57600080fd5b4284101561088957600080fd5b61089283610983565b61089b81610718565b15156108a657600080fd5b33600160a060020a031681600160a060020a031614156108c557600080fd5b9695505050505050565b60008060008084516041146108e357600080fd5b602085015192506040850151915060ff6041860151169050601b8160ff16101561090b57601b015b6001868285856040516000815260200160405260006040516020015260405193845260ff90921660208085019190915260408085019290925260608401929092526080909201915160208103908084039060008661646e5a03f1151561097057600080fd5b5050602060405103519695505050505050565b60008061098f33610718565b151561099a57600080fd5b5060009050805b600a8110156109f55782600282600a81106109b857fe5b015414156109c557600080fd5b600282600a81106109d257fe5b0154600282600a81106109e157fe5b015410156109ed578091505b6001016109a1565b600282600a8110610a0257fe5b0154831015610a1057600080fd5b600282600a8110610a1d57fe5b015461271001831115610a2f57600080fd5b82600283600a8110610a3d57fe5b0155505050565b60405161032680610a558339019056006060604052341561000f57600080fd5b60008054600160a060020a033316600160a060020a03199091161790556102eb8061003b6000396000f30060606040526004361061003c5763ffffffff60e060020a600035041662821de381146100db5780633ef133671461010a5780636b9f96ea1461012b575b600054600160a060020a03163480156108fc0290604051600060405180830381858888f19350505050151561007057600080fd5b7f69b31548dea9b3b707b4dff357d326e3e9348b24e7a6080a218a6edeeec48f9b3334600036604051600160a060020a0385168152602081018490526060604082018181529082018390526080820184848082843782019150509550505050505060405180910390a1005b34156100e657600080fd5b6100ee61013e565b604051600160a060020a03909116815260200160405180910390f35b341561011557600080fd5b610129600160a060020a036004351661014d565b005b341561013657600080fd5b610129610284565b600054600160a060020a031681565b600080548190819033600160a060020a0390811691161461016d57600080fd5b83925030915082600160a060020a03166370a082318360006040516020015260405160e060020a63ffffffff8416028152600160a060020a039091166004820152602401602060405180830381600087803b15156101ca57600080fd5b6102c65a03f115156101db57600080fd5b50505060405180519150508015156101f25761027e565b60008054600160a060020a038086169263a9059cbb929091169084906040516020015260405160e060020a63ffffffff8516028152600160a060020a0390921660048301526024820152604401602060405180830381600087803b151561025857600080fd5b6102c65a03f1151561026957600080fd5b50505060405180519050151561027e57600080fd5b50505050565b600054600160a060020a039081169030163180156108fc0290604051600060405180830381858888f1935050505015156102bd57600080fd5b5600a165627a7a72305820bccf53564dc028daea261336ff477bed43b2bfa9dfb7ebb78673dfc94036da6c0029a165627a7a7230582000c8d9b7fd3f73e1b7d85c0745cb5c0b9bf8aceac88311c416d157da05603ed20029";

    public static final String FUNC_SENDMULTISIGTOKEN = "sendMultiSigToken";

    public static final String FUNC_SIGNERS = "signers";

    public static final String FUNC_FLUSHFORWARDERTOKENS = "flushForwarderTokens";

    public static final String FUNC_SENDMULTISIG = "sendMultiSig";

    public static final String FUNC_ISSIGNER = "isSigner";

    public static final String FUNC_GETNEXTSEQUENCEID = "getNextSequenceId";

    public static final String FUNC_CREATEFORWARDER = "createForwarder";

    public static final String FUNC_SAFEMODE = "safeMode";

    public static final String FUNC_ACTIVATESAFEMODE = "activateSafeMode";

    public static final Event DEPOSITED_EVENT = new Event("Deposited",
            Arrays.asList(new TypeReference<Address>() {
            }, new TypeReference<Uint256>() {
            }, new TypeReference<DynamicBytes>() {
            }));

    public static final Event SAFEMODEACTIVATED_EVENT = new Event("SafeModeActivated",
            Arrays.asList(new TypeReference<Address>() {
            }));

    public static final Event TRANSACTED_EVENT = new Event("Transacted",
            Arrays.asList(new TypeReference<Address>() {
            }, new TypeReference<Address>() {
            }, new TypeReference<Bytes32>() {
            }, new TypeReference<Address>() {
            }, new TypeReference<Uint256>() {
            }, new TypeReference<DynamicBytes>() {
            }));

    @Deprecated
    protected WalletSimple(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected WalletSimple(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected WalletSimple(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected WalletSimple(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public TransactionManager getTransactionManager() {
        return this.transactionManager;
    }

    public RemoteCall<TransactionReceipt> sendMultiSigToken(String toAddress, BigInteger value, String tokenContractAddress, BigInteger expireTime, BigInteger sequenceId, byte[] signature) {
        final Function function = new Function(
                FUNC_SENDMULTISIGTOKEN,
                Arrays.asList(new Address(toAddress),
                        new Uint256(value),
                        new Address(tokenContractAddress),
                        new Uint256(expireTime),
                        new Uint256(sequenceId),
                        new DynamicBytes(signature)),
                Collections.emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> signers(BigInteger param0) {
        final Function function = new Function(FUNC_SIGNERS,
                Arrays.asList(new Uint256(param0)),
                Arrays.asList(new TypeReference<Address>() {
                }));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> flushForwarderTokens(String forwarderAddress, String tokenContractAddress) {
        final Function function = new Function(
                FUNC_FLUSHFORWARDERTOKENS,
                Arrays.asList(new Address(forwarderAddress),
                        new Address(tokenContractAddress)),
                Collections.emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> sendMultiSig(String toAddress, BigInteger value, byte[] data, BigInteger expireTime, BigInteger sequenceId, byte[] signature) {
        final Function function = new Function(
                FUNC_SENDMULTISIG,
                Arrays.asList(new Address(toAddress),
                        new Uint256(value),
                        new DynamicBytes(data),
                        new Uint256(expireTime),
                        new Uint256(sequenceId),
                        new DynamicBytes(signature)),
                Collections.emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<Boolean> isSigner(String signer) {
        final Function function = new Function(FUNC_ISSIGNER,
                Arrays.asList(new Address(signer)),
                Arrays.asList(new TypeReference<Bool>() {
                }));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> getNextSequenceId() {
        final Function function = new Function(FUNC_GETNEXTSEQUENCEID,
                Arrays.asList(),
                Arrays.asList(new TypeReference<Uint256>() {
                }));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<TransactionReceipt> createForwarder() {
        final Function function = new Function(
                FUNC_CREATEFORWARDER,
                Arrays.asList(),
                Collections.emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<Boolean> safeMode() {
        final Function function = new Function(FUNC_SAFEMODE,
                Arrays.asList(),
                Arrays.asList(new TypeReference<Bool>() {
                }));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<TransactionReceipt> activateSafeMode() {
        final Function function = new Function(
                FUNC_ACTIVATESAFEMODE,
                Arrays.asList(),
                Collections.emptyList());
        return executeRemoteCallTransaction(function);
    }

    public List<DepositedEventResponse> getDepositedEvents(TransactionReceipt transactionReceipt) {
        List<EventValuesWithLog> valueList = extractEventParametersWithLog(DEPOSITED_EVENT, transactionReceipt);
        ArrayList<DepositedEventResponse> responses = new ArrayList<DepositedEventResponse>(valueList.size());
        for (EventValuesWithLog eventValues : valueList) {
            DepositedEventResponse typedResponse = new DepositedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.from = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.data = (byte[]) eventValues.getNonIndexedValues().get(2).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<DepositedEventResponse> depositedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, DepositedEventResponse>() {
            @Override
            public DepositedEventResponse apply(Log log) {
                EventValuesWithLog eventValues = extractEventParametersWithLog(DEPOSITED_EVENT, log);
                DepositedEventResponse typedResponse = new DepositedEventResponse();
                typedResponse.log = log;
                typedResponse.from = (String) eventValues.getNonIndexedValues().get(0).getValue();
                typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
                typedResponse.data = (byte[]) eventValues.getNonIndexedValues().get(2).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<DepositedEventResponse> depositedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(DEPOSITED_EVENT));
        return depositedEventFlowable(filter);
    }

    public List<SafeModeActivatedEventResponse> getSafeModeActivatedEvents(TransactionReceipt transactionReceipt) {
        List<EventValuesWithLog> valueList = extractEventParametersWithLog(SAFEMODEACTIVATED_EVENT, transactionReceipt);
        ArrayList<SafeModeActivatedEventResponse> responses = new ArrayList<SafeModeActivatedEventResponse>(valueList.size());
        for (EventValuesWithLog eventValues : valueList) {
            SafeModeActivatedEventResponse typedResponse = new SafeModeActivatedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.msgSender = (String) eventValues.getNonIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<SafeModeActivatedEventResponse> safeModeActivatedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, SafeModeActivatedEventResponse>() {
            @Override
            public SafeModeActivatedEventResponse apply(Log log) {
                EventValuesWithLog eventValues = extractEventParametersWithLog(SAFEMODEACTIVATED_EVENT, log);
                SafeModeActivatedEventResponse typedResponse = new SafeModeActivatedEventResponse();
                typedResponse.log = log;
                typedResponse.msgSender = (String) eventValues.getNonIndexedValues().get(0).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<SafeModeActivatedEventResponse> safeModeActivatedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(SAFEMODEACTIVATED_EVENT));
        return safeModeActivatedEventFlowable(filter);
    }

    public List<TransactedEventResponse> getTransactedEvents(TransactionReceipt transactionReceipt) {
        List<EventValuesWithLog> valueList = extractEventParametersWithLog(TRANSACTED_EVENT, transactionReceipt);
        ArrayList<TransactedEventResponse> responses = new ArrayList<TransactedEventResponse>(valueList.size());
        for (EventValuesWithLog eventValues : valueList) {
            TransactedEventResponse typedResponse = new TransactedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.msgSender = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.otherSigner = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.operation = (byte[]) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.toAddress = (String) eventValues.getNonIndexedValues().get(3).getValue();
            typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(4).getValue();
            typedResponse.data = (byte[]) eventValues.getNonIndexedValues().get(5).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<TransactedEventResponse> transactedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new io.reactivex.functions.Function<Log, TransactedEventResponse>() {
            @Override
            public TransactedEventResponse apply(Log log) {
                EventValuesWithLog eventValues = extractEventParametersWithLog(TRANSACTED_EVENT, log);
                TransactedEventResponse typedResponse = new TransactedEventResponse();
                typedResponse.log = log;
                typedResponse.msgSender = (String) eventValues.getNonIndexedValues().get(0).getValue();
                typedResponse.otherSigner = (String) eventValues.getNonIndexedValues().get(1).getValue();
                typedResponse.operation = (byte[]) eventValues.getNonIndexedValues().get(2).getValue();
                typedResponse.toAddress = (String) eventValues.getNonIndexedValues().get(3).getValue();
                typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(4).getValue();
                typedResponse.data = (byte[]) eventValues.getNonIndexedValues().get(5).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<TransactedEventResponse> transactedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(TRANSACTED_EVENT));
        return transactedEventFlowable(filter);
    }

    @Deprecated
    public static WalletSimple load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new WalletSimple(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static WalletSimple load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new WalletSimple(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static WalletSimple load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new WalletSimple(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static WalletSimple load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new WalletSimple(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<WalletSimple> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider, List<String> allowedSigners) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.asList(new DynamicArray<Address>(
                org.web3j.abi.Utils.typeMap(allowedSigners, Address.class))));
        return deployRemoteCall(WalletSimple.class, web3j, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<WalletSimple> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider, List<String> allowedSigners) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.asList(new DynamicArray<Address>(
                org.web3j.abi.Utils.typeMap(allowedSigners, Address.class))));
        return deployRemoteCall(WalletSimple.class, web3j, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<WalletSimple> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, List<String> allowedSigners) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.asList(new DynamicArray<Address>(
                org.web3j.abi.Utils.typeMap(allowedSigners, Address.class))));
        return deployRemoteCall(WalletSimple.class, web3j, credentials, gasPrice, gasLimit, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<WalletSimple> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, List<String> allowedSigners) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.asList(new DynamicArray<Address>(
                org.web3j.abi.Utils.typeMap(allowedSigners, Address.class))));
        return deployRemoteCall(WalletSimple.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, encodedConstructor);
    }

    public static class DepositedEventResponse {
        public Log log;

        public String from;

        public BigInteger value;

        public byte[] data;
    }

    public static class SafeModeActivatedEventResponse {
        public Log log;

        public String msgSender;
    }

    public static class TransactedEventResponse {
        public Log log;

        public String msgSender;

        public String otherSigner;

        public byte[] operation;

        public String toAddress;

        public BigInteger value;

        public byte[] data;
    }
}
