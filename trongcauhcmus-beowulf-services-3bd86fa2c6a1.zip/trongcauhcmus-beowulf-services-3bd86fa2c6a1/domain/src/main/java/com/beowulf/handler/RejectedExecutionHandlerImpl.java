package com.beowulf.handler;


import com.beowulf.utilities.LoggerUtil;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

public class RejectedExecutionHandlerImpl implements RejectedExecutionHandler {
    private static final String TAG = RejectedExecutionHandlerImpl.class.getName();

    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
        try {
            LoggerUtil.w(TAG, r.toString() + " is rejected");
        } catch (Exception e) {
        }
    }
}
