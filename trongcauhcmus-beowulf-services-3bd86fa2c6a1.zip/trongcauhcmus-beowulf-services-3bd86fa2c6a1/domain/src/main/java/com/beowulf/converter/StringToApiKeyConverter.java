package com.beowulf.converter;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.repository.ApiKeyRepository;
import com.beowulf.constants.ApiKeyType;
import com.beowulf.utilities.ApiKeyUtils;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.StringUtils;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

@Component
public class StringToApiKeyConverter implements Converter<String, ApiKey> {
    private static final String TAG = StringToApiKeyConverter.class.getName();

    @Autowired
    private ApiKeyRepository apiKeyRepository;

    @Override
    public ApiKey convert(@Nullable String authorization) {
        try {
            if (StringUtils.isEmpty(authorization))
                return null;


            if (!authorization.startsWith(ApiKeyType.BASIC))
                return null;

            authorization = authorization.substring(5).trim();

            authorization = new String(Base64.decodeBase64(authorization));

            String[] args = authorization.split(":");
            if (args.length != 2)
                return null;

            String apiKeyId = args[0];
            String token = args[1];

            ApiKey apiKey = apiKeyRepository.findApiKeyByApiKeyId(apiKeyId);

            if (apiKey == null)
                return null;

            if (!token.equals(ApiKeyUtils.decryptToken(apiKey.getAccess_token())))
                return null;

            return apiKey;

        } catch (Exception e) {
            LoggerUtil.exception(TAG, e, true);
        }
        return null;
    }
}
