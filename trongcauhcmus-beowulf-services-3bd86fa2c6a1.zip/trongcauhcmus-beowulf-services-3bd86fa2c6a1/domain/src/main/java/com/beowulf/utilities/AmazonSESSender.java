package com.beowulf.utilities;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.*;
import com.beowulf.config.GeneralConfigProperties;
import com.google.gson.Gson;

import javax.swing.*;

public class AmazonSESSender {
    public static String company = GeneralConfigProperties.getInstance().getCompany_name();
    public static String companyMail = GeneralConfigProperties.getInstance().getCompany_mail_address();
    public static String secretKey = GeneralConfigProperties.getInstance().getCompany_mail_AmazonSecretKey();
    public static String accessKey = GeneralConfigProperties.getInstance().getCompany_mail_AmazonAccessKey();

    public static int sendEmailToAddress(String title, String templateContent, String[] addresses) throws Exception {

        try {
            System.out.println("Start send email");
            Destination destination = new Destination();
            destination.withToAddresses(addresses);
            AWSCredentials awsCredentials = new BasicAWSCredentials(
                    accessKey, secretKey);
            AWSCredentialsProvider provider = new AWSStaticCredentialsProvider(awsCredentials);
            AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard()
                    .withCredentials(provider)
                    .withRegion(Regions.US_WEST_2)
                    .build();
            Message message = new Message();
            message.withBody(new Body().withHtml(new Content().withCharset("UTF-8").withData(templateContent)));
            message.withSubject(new Content().withCharset("UTF-8").withData(title));
            String source = "\"" + company + "\"<"
                    + companyMail + ">";
            SendEmailRequest request = new SendEmailRequest().withDestination(destination).withMessage(message)
                    .withSource(source);
            System.out
                    .println("Send email via Amazon ses resule : " + new Gson().toJson(client.sendEmail(request)));

            return 1;
        } catch (Exception e) {
            System.out.println("The email was not sent. Error message: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }


    public static class SendAmazonSESEmailAsyncWorker extends SwingWorker<Integer, Void> {
        private String templateContent;
        private String title;
        private String[] addresses;

        public SendAmazonSESEmailAsyncWorker(String templateContent, String title, String[] addresses) {
            this.templateContent = templateContent;
            this.title = title;
            this.addresses= addresses;
        }

        @Override
        protected Integer doInBackground() {
            try {
                sendEmailToAddress(title, templateContent, addresses);
            } catch (Exception e) {
                System.out.println("SendEmailAsyncWorker: Error while execute in background");
            }
            return 1;
        }

        @Override
        protected void done() {
            System.out.println("SendEmailAsyncWorker: done");
            super.done();
        }
    }
}
