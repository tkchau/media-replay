package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.Action;
import com.beowulf.explorer.repository.ActionRepository;
import com.beowulf.explorer.repository.extend.ActionRepositoryExtend;
import com.mongodb.client.result.DeleteResult;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class ActionRepositoryImpl implements ActionRepositoryExtend {

	private final Logger logger = LoggerFactory.getLogger(ActionRepository.class);

	@Autowired
    MongoTemplate mongoTemplate;

	@Override
	public boolean addNewAction(Action action) {
		mongoTemplate.save(action);
		return true;
	}

	@Override
	public boolean removeAction(ObjectId id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		DeleteResult result = mongoTemplate.remove(query, Action.class, CollectionName.ACTIONS);
		return result.getDeletedCount() != 0;
	}
}
