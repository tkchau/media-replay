/*
 * Copyright (c) 2018.
 * @author TrongCauTa - trongcauhcmus@gmail.com
 * @version 4/17/18 4:26 PM
 */

package com.beowulf.hook.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.utilities.GsonSingleton;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.COL_BWF_SMT_TOKEN_INFO)
public class SmtTokenInfo {
    ObjectId id;

    @Indexed(unique = true)
    private String token_symbol;
    private int decimal;

    public String getToken_symbol() {
        return token_symbol;
    }

    public void setToken_symbol(String token_symbol) {
        this.token_symbol = token_symbol;
    }

    public int getDecimal() {
        return decimal;
    }

    public void setDecimal(int decimal) {
        this.decimal = decimal;
    }

    @Override
    public String toString() {
        return GsonSingleton.getInstance().toJson(this);
    }
}
