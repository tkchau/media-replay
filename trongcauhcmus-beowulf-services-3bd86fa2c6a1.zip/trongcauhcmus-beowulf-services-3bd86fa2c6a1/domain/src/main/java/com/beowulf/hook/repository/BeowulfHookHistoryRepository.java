package com.beowulf.hook.repository;


import com.beowulf.hook.document.BeowulfTransactionReceipt;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BeowulfHookHistoryRepository extends MongoRepository<BeowulfTransactionReceipt, ObjectId> {
}
