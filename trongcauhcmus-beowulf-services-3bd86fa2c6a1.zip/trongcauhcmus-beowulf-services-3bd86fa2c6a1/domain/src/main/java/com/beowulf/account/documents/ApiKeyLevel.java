package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.API_KEY_LEVELS)
public class ApiKeyLevel {
    private ObjectId id;

    @Indexed(unique = true)
    private String api_key_level;
    private String description;
    private long max_number_wallet;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getApi_key_level() {
        return api_key_level;
    }

    public void setApi_key_level(String api_key_level) {
        this.api_key_level = api_key_level;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getMax_number_wallet() {
        return max_number_wallet;
    }

    public void setMax_number_wallet(long max_number_wallet) {
        this.max_number_wallet = max_number_wallet;
    }
}
