package com.beowulf.constants;

public class BeowulfConstant {

    public static final String GENESIS_CREATE_OPERATION_ID = "00000000-0000-0000-0000-000000000000";

    public static final String GENESIS_ACCOUNT_NAME = "beowulf";

    public static final String NULL_ACCOUNT_NAME = "null";

    public static final String BWF_ASSET_SYMBOL = "BWF";

    public static final String W_ASSET_SYMBOL = "W";

    public static final String VOTING_ASSET_SYMBOL = "M";

    public static final int MAXIMUM_ASSET_LEN = 8;

    public static final int NATIVE_ASSET_PRECISION = 5;

    public static final int DEFAULT_TXID_LEN = 40;
}
