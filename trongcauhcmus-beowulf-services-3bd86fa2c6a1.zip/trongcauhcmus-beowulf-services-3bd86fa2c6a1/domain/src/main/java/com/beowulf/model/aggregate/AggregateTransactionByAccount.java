package com.beowulf.model.aggregate;

public class AggregateTransactionByAccount {

	private String supernode;
	private long numberTransaction;
	private long totalFee;

	public String getSupernode() {
		return supernode;
	}
	
	public void setSupernode(String supernode) {
		this.supernode = supernode;
	}

	public long getNumberTransaction() {
		return numberTransaction;
	}

	public void setNumberTransaction(long numberTransaction) {
		this.numberTransaction = numberTransaction;
	}

	public long getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(long totalFee) {
		this.totalFee = totalFee;
	}

}
