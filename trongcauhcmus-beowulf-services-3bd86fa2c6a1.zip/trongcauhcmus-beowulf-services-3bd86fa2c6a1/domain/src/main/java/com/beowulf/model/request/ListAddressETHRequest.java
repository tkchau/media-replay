package com.beowulf.model.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ListAddressETHRequest {
    @NotEmpty
    @NotNull
    private String address;
    @NotEmpty
    @NotNull
    private String private_key;
    @NotEmpty
    @NotNull
    private String asset_code;


    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrivate_key() {
        return private_key;
    }

    public void setPrivate_key(String private_key) {
        this.private_key = private_key;
    }
}
