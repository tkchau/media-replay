package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.repository.extend.BeowulfBlockRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface BeowulfBlockRepository extends MongoRepository<BeowulfBlock, ObjectId>, BeowulfBlockRepositoryExtend {

    @Query(value = "{'block_id' : ?0}")
    public BeowulfBlock findByBlockId(String blockId);

    @Query(value = "{'block_number' : ?0}")
    public BeowulfBlock findByBlockNumber(long blockNumber);
}
