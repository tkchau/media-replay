package com.beowulf.model.ethereum;

import org.springframework.util.StringUtils;
import org.web3j.protocol.core.Response;

import java.math.BigInteger;

public class ParityNextNonceResponse extends Response<String> {

    public BigInteger nonceValueExact() {
        if (StringUtils.hasText(getResult()))
            return new BigInteger(getResult().substring(2), 16);
        return null;
    }
}