package com.beowulf.model.request;


import com.beowulf.utilities.GsonSingleton;

/**
 * @author trongcauta
 * @time 10:50 AM
 * @data 5/24/19
 */
public class HttpRequestObject {
    /**
     * @return The json representation of this object.
     */
    public String toJson() {
        return GsonSingleton.getInstance().toJson(this);
    }
}
