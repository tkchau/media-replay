package com.beowulf.hook.repository.extend;

import com.beowulf.hook.document.NodeInfo;

public interface NodeInfoRepositoryExtend {
    void updateLastSync(String node_url, long blocknum);

    NodeInfo getHighestNodeByType(String type);
}
