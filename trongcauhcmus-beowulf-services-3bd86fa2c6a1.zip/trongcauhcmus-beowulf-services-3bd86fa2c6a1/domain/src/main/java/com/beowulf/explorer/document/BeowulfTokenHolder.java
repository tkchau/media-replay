package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulfchain.beowulfj.protocol.Asset;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.TOKEN_HOLDERS)
@CompoundIndexes({
        @CompoundIndex(def = "{\"account\": 1, \"balance.name\": 1}", unique = true),
        @CompoundIndex(def = "{\"balance.name\": 1, \"balance.amount\": -1}"),
})
public class BeowulfTokenHolder {

    @Id
    private ObjectId id;

    private Asset balance;

    private String account;

    public BeowulfTokenHolder() {
    }

    public BeowulfTokenHolder(String account, Asset assetBalance) {
        this.account = account;
        this.balance = assetBalance;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public Asset getBalance() {
        return balance;
    }

    public void setBalance(Asset balance) {
        this.balance = balance;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}