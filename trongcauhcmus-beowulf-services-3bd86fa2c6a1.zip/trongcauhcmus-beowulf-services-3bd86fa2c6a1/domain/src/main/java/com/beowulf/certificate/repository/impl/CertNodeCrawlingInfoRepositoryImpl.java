package com.beowulf.certificate.repository.impl;

import com.beowulf.certificate.document.CertNodeInfo;
import com.beowulf.certificate.repository.extend.CertNodeCrawlingInfoRepositoryExtend;
import com.beowulf.model.BlockchainType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class CertNodeCrawlingInfoRepositoryImpl implements CertNodeCrawlingInfoRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void updateLastCrawl(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl").lt(blockNum));

        Update update = new Update();
        update.set("last_crawl", blockNum);
        mongoTemplate.findAndModify(query, update, CertNodeInfo.class);
    }

    @Override
    public boolean updateLastCrawlOnDestroy(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl").gt(blockNum));

        Update update = new Update();
        update.set("last_crawl", blockNum);
        CertNodeInfo certNodeInfo = mongoTemplate.findAndModify(query, update, CertNodeInfo.class);
        return certNodeInfo != null;
    }

    @Override
    public void updateLastIrrversibleCrawl(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_irreversible").lt(blockNum));

        Update update = new Update();
        update.set("last_crawl_irreversible", blockNum);
        mongoTemplate.findAndModify(query, update, CertNodeInfo.class);
    }

    @Override
    public boolean updateLastIrreversibleCrawlOnDestroy(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_irreversible").gt(blockNum));

        Update update = new Update();
        update.set("last_crawl_irreversible", blockNum);
        CertNodeInfo certNodeInfo = mongoTemplate.findAndModify(query, update, CertNodeInfo.class);
        return certNodeInfo != null;
    }

    @Override
    public long getLastCrawlingBlock(long startBlock, String nodeUrl) {
        CertNodeInfo certNodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (certNodeInfo == null) {
            createNewNodeInfo(startBlock, nodeUrl);
            return startBlock;
        } else {
            long last_crawl = certNodeInfo.getLast_crawl();
            return Math.max(last_crawl, startBlock);
        }
    }

    @Override
    public long getLastCrawlingIrreversibleBlock(long startBlock, String nodeUrl) {
        CertNodeInfo certNodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (certNodeInfo == null) {
            createNewNodeInfo(startBlock, nodeUrl);
            return startBlock;
        } else {
            long last_irreversible = certNodeInfo.getLast_crawl_irreversible();
            return Math.max(last_irreversible, startBlock);
        }
    }

    @Override
    public CertNodeInfo findNodeInfoByNode_url(String node_url) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(node_url));
        return mongoTemplate.findOne(query, CertNodeInfo.class);
    }

    private void createNewNodeInfo(long startBlock, String nodeUrl) {
        CertNodeInfo certNodeInfo = new CertNodeInfo();
        certNodeInfo.setNode_url(nodeUrl);
        certNodeInfo.setLast_crawl(startBlock);
        certNodeInfo.setLast_crawl_irreversible(startBlock);
        certNodeInfo.setType(BlockchainType.BWF.name());
        mongoTemplate.save(certNodeInfo);
    }
}
