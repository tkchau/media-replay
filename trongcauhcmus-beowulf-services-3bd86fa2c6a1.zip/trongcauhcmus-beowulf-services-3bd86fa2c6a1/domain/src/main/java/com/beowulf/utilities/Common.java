package com.beowulf.utilities;

import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulf.model.BeowulfData;
import com.beowulfchain.beowulfj.protocol.AccountName;
import eu.bittrade.crypto.core.CryptoUtils;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.InvalidParameterException;
import java.util.Date;
import java.util.Map;

public class Common {
    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
            Base64 encoder = new Base64();
            imageString = encoder.encodeToString(imageBytes);
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "data:image/png;base64," + imageString;
    }

    public static int makeStableLimitation(int limit) {
        if (limit <= 0 || limit > Constant.MAX_RECORD_RESPONSE) {
            limit = Constant.MAX_RECORD_RESPONSE;
        }
        return limit;
    }

    public static ObjectId makeStableObjectIdRequest(String id) {
        if (StringUtils.hasText(id)) {
            if (ObjectId.isValid(id)) {
                return new ObjectId(id);
            }
        }
        return null;
    }

    public static String handleDirectionRequest(String direction) {
        if (StringUtils.hasText(direction)) {
            if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction) || Constant.LIST_DIRECTION_NEXT.equals(direction)) {
                return direction;
            }
            throw new InvalidParameterException("Invalid param direction");
        } else {
            throw new InvalidParameterException("direction is null");
        }
    }

    public static Query buildPagingQuery(String key, Object value, int limit, String direction, Pair<String, Object> filter) {
        Query query = new Query();
        if (value != null) {
            if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction)) {
                query.addCriteria(Criteria.where(key).gt(value));
                query.with(Sort.by(Sort.Direction.ASC, key));
            } else if (Constant.LIST_DIRECTION_NEXT.equals(direction)) {
                query.addCriteria(Criteria.where(key).lt(value));
                query.with(Sort.by(Sort.Direction.DESC, key));
            }
        } else {
            query.with(Sort.by(Sort.Direction.DESC, key));
        }
        query.limit(limit);
        if (filter != null) {
            query.addCriteria(Criteria.where(filter.getFirst()).is(filter.getSecond()));
        }
        return query;
    }

    /**
     * Convert the first four bytes of the hash into a number.
     *
     * @return The number.
     */
    public static long getNumberFromBlockId(String blockId) {
        try {
            byte[] fourBytesByte = new byte[4];
            System.arraycopy(CryptoUtils.HEX.decode(blockId), 0, fourBytesByte, 0, 4);
            return ByteBuffer.wrap(fourBytesByte).order(ByteOrder.BIG_ENDIAN).getInt();
        } catch (Exception e) {
            throw new InvalidParameterException("Invalid block Id");
        }
    }

    public static String getPreBlockIdFromBlockNum(long blockNum) {
        try {
            byte[] bytes = CryptoUtils.bigIntegerToBytes(BigInteger.valueOf(blockNum), 4);
            return CryptoUtils.HEX.encode(bytes);
        } catch (Exception e) {
            throw new InvalidParameterException("Invalid block number");
        }
    }

    public static boolean isValidAccountName(String account) {
        try {
            AccountName isValidName = new AccountName(account);
            return true;
        } catch (Exception e) {
            throw new InvalidParameterException("Invalid account name");
        }
    }

    public static boolean isMultisigAccount(AuthorityData authorityData) {
        Map<String, Integer> mapAccountS = authorityData.getAccountAuths();
        Map<String, Integer> mapKeyS = authorityData.getKeyAuths();
        return (mapAccountS.size() + mapKeyS.size()) > 1;
    }

    public static ObjectId generateObjectIdFromData(BeowulfData blockChainData) {
        int machineId = (int) (blockChainData.getBlockNum() & 0xFFFFFF);
        short processId = (short) ((blockChainData.getBlockNum() >> 24) & 0xFFFF);
        int counter = ((blockChainData.getTxIndex() & 0xFFFF) << 8) | (blockChainData.getOpIndex() & 0xFF);
        return new ObjectId(new Date(blockChainData.getBlockTime()), machineId, processId, counter);
    }

    public static BeowulfData dataFromObjectId(ObjectId id) {
        int machineId = id.getMachineIdentifier();
        short processId = id.getProcessIdentifier();
        int txIndex = id.getCounter() >> 8;
        int opIndex = id.getCounter() & 0xFF;
        long blockTime = id.getTimestamp();
        long blockNum = 0L;
        blockNum = ((blockNum | (processId & 0xFFFF)) << 24) | (machineId & 0xFFFFFF);
        return new BeowulfData(blockNum, txIndex, opIndex, blockTime);
    }
}
