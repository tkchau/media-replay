package com.beowulf.model.request;

public class OpenWebHookRequest extends HttpRequestObject {
    private String address;
    private String url;

    public OpenWebHookRequest() {
    }

    public OpenWebHookRequest(String address, String url) {
        this.address = address;
        this.url = url;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
