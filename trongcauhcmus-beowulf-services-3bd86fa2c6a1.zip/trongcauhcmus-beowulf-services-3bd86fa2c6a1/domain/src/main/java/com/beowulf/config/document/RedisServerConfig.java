package com.beowulf.config.document;

public class RedisServerConfig extends Configuration {
    private String host;
    private int port;
    private int max_pool;

    public RedisServerConfig() {
        this.setKey("redis_config");
        this.setHost("127.0.0.1");
        this.setMax_pool(10);
        this.setPort(6379);
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getMax_pool() {
        return max_pool;
    }

    public void setMax_pool(int max_pool) {
        this.max_pool = max_pool;
    }
}
