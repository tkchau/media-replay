package com.beowulf.model.request;

import com.beowulfchain.beowulfj.protocol.AccountName;

import java.util.HashMap;

public class BeowulfCreateMultisigAccountRequest {
    private String account_name;
    private HashMap<AccountName, Integer> accountAuths;
    private HashMap<String, Integer> keyAuths;
    private int min_weight;

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public HashMap<AccountName, Integer> getAccountAuths() {
        return accountAuths;
    }

    public void setAccountAuths(HashMap<AccountName, Integer> accountAuths) {
        this.accountAuths = accountAuths;
    }

    public HashMap<String, Integer> getKeyAuths() {
        return keyAuths;
    }

    public void setKeyAuths(HashMap<String, Integer> keyAuths) {
        this.keyAuths = keyAuths;
    }

    public int getMin_weight() {
        return min_weight;
    }

    public void setMin_weight(int min_weight) {
        this.min_weight = min_weight;
    }
}
