package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfTokenHolder;

import java.math.BigDecimal;

public class TokenHolderDetailResponse {
    private String account;
    private long balance;
    private String balance_in_str;

    public TokenHolderDetailResponse() {
    }

    public TokenHolderDetailResponse(BeowulfTokenHolder tokenHolder, int precision) {
        this.account = tokenHolder.getAccount();
        this.balance = tokenHolder.getBalance().getAmount();
        BigDecimal decimal = BigDecimal.valueOf(Math.pow(10, precision));
        this.balance_in_str = BigDecimal.valueOf(this.balance).divide(decimal).toPlainString() + " " + tokenHolder.getBalance().getName();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public long getBalance() {
        return balance;
    }

    public void setBalance(long balance) {
        this.balance = balance;
    }

    public String getBalance_in_str() {
        return balance_in_str;
    }

    public void setBalance_in_str(String balance_in_str) {
        this.balance_in_str = balance_in_str;
    }
}