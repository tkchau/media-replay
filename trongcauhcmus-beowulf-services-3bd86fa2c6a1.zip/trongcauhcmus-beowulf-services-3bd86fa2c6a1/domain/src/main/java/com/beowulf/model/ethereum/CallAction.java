package com.beowulf.model.ethereum;

import com.beowulf.model.ethereum.contract.ERC20;
import org.web3j.protocol.parity.methods.response.Trace;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CallAction {
    private String from;
    private String to;
    private BigInteger value;
    private String type;
    private String trace;
    private List<Long> trace_address;

    public CallAction(ERC20.TransferEventResponse eventResponse) {
        this.setFrom(eventResponse._from);
        this.setTo(eventResponse._to);
        this.setValue(eventResponse._value);
        this.setType("log");
        String trace_position = String.format("log_%s", eventResponse.log.getLogIndex().toString());
        this.setTrace(trace_position);
        this.setTrace_address(Collections.singletonList(eventResponse.log.getLogIndex().longValueExact()));
    }

    public CallAction(Trace trace) {
        Trace.CallAction callAction = (Trace.CallAction) trace.getAction();
        this.setFrom(callAction.getFrom());
        this.setTo(callAction.getTo());
        this.setValue(callAction.getValue());
        this.setType(callAction.getCallType());
        List<Long> trace_address = new ArrayList<>();
        StringBuilder trace_position = new StringBuilder(callAction.getCallType());
        for (BigInteger traceAddress : trace.getTraceAddress()) {
            trace_address.add(traceAddress.longValueExact());
            trace_position.append(String.format("_%s", traceAddress.toString()));
        }
        this.setTrace_address(trace_address);
        this.setTrace(trace_position.toString());
    }

    public CallAction() {
    }

    public List<Long> getTrace_address() {
        return trace_address;
    }

    public void setTrace_address(List<Long> trace_address) {
        this.trace_address = trace_address;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public BigInteger getValue() {
        return value;
    }

    public void setValue(BigInteger value) {
        this.value = value;
    }

    public String getTrace() {
        return trace;
    }

    public void setTrace(String trace) {
        this.trace = trace;
    }
}
