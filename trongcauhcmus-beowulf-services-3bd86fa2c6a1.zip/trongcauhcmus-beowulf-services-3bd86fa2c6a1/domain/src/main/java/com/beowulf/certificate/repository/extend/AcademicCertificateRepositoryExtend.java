package com.beowulf.certificate.repository.extend;

import com.beowulf.certificate.document.BeowulfAcademicCertificate;

import java.util.List;

public interface AcademicCertificateRepositoryExtend {

    BeowulfAcademicCertificate findAcademicCertificateBySerialNum(String serialNum);

    List<BeowulfAcademicCertificate> findAcademicCertificateByStudentId(String studentId);

}
