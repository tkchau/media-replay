package com.beowulf.constants;

import java.math.BigDecimal;

public class CurrencyConstant {

	public static final BigDecimal DEFAULT_SYSTEM_UNIT = new BigDecimal("100000");
	public static final String DEFAULT_SYSTEM_DECIMAL_FORMAT = "#.#####";

	// public static final Map<String, String> beowulfTokens = initMap();
	//
	// private static Map<String, String> initMap() {
	// Map<String, String> map = new HashMap<String, String>();
	// map.put("3144730325", "GTO");
	// map.put("422266069", "1SG");
	// map.put("408898069", "BNB");
	// map.put("2645387285", "DGX");
	// map.put("2973826645", "KNOW");
	// map.put("W", "W");
	// map.put("BWF", "BWF");
	// map.put("M", "M");
	// return Collections.unmodifiableMap(map);
	// }

	public enum BEOWULF_TOKEN {
		GTO("GTO", "Gifto", "3144730325", "#.#####", new BigDecimal("100000")), DGX("DGX", "Digix Gold Token",
				"2645387285", "#.#####", new BigDecimal("100000"));

		private final String currencyCode;

		private final String name;

		private final String tokenAddress;

		private final String decimalFormat;

		private final BigDecimal unit;

		BEOWULF_TOKEN(String currencyCode, String name, String tokenAddress, String decimalFormat, BigDecimal unit) {
			this.currencyCode = currencyCode;
			this.name = name;
			this.tokenAddress = tokenAddress;
			this.decimalFormat = decimalFormat;
			this.unit = unit;
		}

		public String getCurrencyCode() {
			return currencyCode;
		}

		public String getName() {
			return name;
		}

		public String getTokenAddress() {
			return tokenAddress;
		}

		public String getDecimalFormat() {
			return decimalFormat;
		}

		public BigDecimal getUnit() {
			return unit;
		}
	}
}
