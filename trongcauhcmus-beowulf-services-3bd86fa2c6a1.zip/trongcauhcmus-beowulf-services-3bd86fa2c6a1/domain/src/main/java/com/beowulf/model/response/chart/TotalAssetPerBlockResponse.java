package com.beowulf.model.response.chart;

import com.beowulf.explorer.document.BeowulfBlock;

public class TotalAssetPerBlockResponse {
    private long block_number;
    private long timestamp;
    private long total_fee_per_block;
    private int number_transaction;
    private long block_reward;
    private long asset_reward;

    public TotalAssetPerBlockResponse() {
    }

    public TotalAssetPerBlockResponse(BeowulfBlock beowulfBlock) {
        this.block_number = beowulfBlock.getBlock_number();
        this.timestamp = beowulfBlock.getTimestamp();
        this.total_fee_per_block = beowulfBlock.getTotal_fee();
        this.number_transaction = beowulfBlock.getNumber_transaction();
        this.block_reward = beowulfBlock.getBlock_reward();
        this.asset_reward = block_reward + total_fee_per_block;
    }

    public long getTotal_fee_per_block() {
        return total_fee_per_block;
    }

    public void setTotal_fee_per_block(long total_fee_per_block) {
        this.total_fee_per_block = total_fee_per_block;
    }

    public long getAsset_reward() {
        return asset_reward;
    }

    public void setAsset_reward(long asset_reward) {
        this.asset_reward = asset_reward;
    }

    public long getBlock_number() {
        return block_number;
    }

    public void setBlock_number(long block_number) {
        this.block_number = block_number;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getNumber_transaction() {
        return number_transaction;
    }

    public void setNumber_transaction(int number_transaction) {
        this.number_transaction = number_transaction;
    }

    public long getBlock_reward() {
        return block_reward;
    }

    public void setBlock_reward(long block_reward) {
        this.block_reward = block_reward;
    }
}
