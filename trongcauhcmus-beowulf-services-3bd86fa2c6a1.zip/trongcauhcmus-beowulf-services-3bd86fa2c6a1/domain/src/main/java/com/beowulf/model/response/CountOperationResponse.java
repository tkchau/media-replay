package com.beowulf.model.response;

import java.util.List;

public class CountOperationResponse {

    private List<OperationDetailResponse> last_operation;

    public List<OperationDetailResponse> getLast_operation() {
        return last_operation;
    }

    public void setLast_operation(List<OperationDetailResponse> last_operation) {
        this.last_operation = last_operation;
    }
}
