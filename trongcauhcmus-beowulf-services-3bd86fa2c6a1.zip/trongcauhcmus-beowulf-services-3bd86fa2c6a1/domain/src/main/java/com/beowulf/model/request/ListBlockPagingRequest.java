package com.beowulf.model.request;

public class ListBlockPagingRequest extends ListObjectsPagingRequest {
}
