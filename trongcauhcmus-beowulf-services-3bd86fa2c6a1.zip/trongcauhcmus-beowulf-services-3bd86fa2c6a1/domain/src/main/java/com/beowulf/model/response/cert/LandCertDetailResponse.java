package com.beowulf.model.response.cert;

import com.beowulf.certificate.document.BeowulfLandCertificate;
import com.beowulf.certificate.document.certdata.LandCertificateData;

import java.util.List;

public class LandCertDetailResponse {
    private String transaction_id;
    private List<String> tx_histories;
    private LandCertificateData cert_data;

    public LandCertDetailResponse() {
    }

    public LandCertDetailResponse(BeowulfLandCertificate certificate) {
        this.transaction_id = certificate.getTransaction_id();
        this.cert_data = certificate.getData();
        this.tx_histories = certificate.getTx_histories();
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public LandCertificateData getCert_data() {
        return cert_data;
    }

    public void setCert_data(LandCertificateData cert_data) {
        this.cert_data = cert_data;
    }

    public List<String> getTx_histories() {
        return tx_histories;
    }

    public void setTx_histories(List<String> tx_histories) {
        this.tx_histories = tx_histories;
    }
}