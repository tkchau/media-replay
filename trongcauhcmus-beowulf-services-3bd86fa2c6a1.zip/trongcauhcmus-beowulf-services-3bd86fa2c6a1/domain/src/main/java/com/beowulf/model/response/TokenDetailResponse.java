package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfToken;

public class TokenDetailResponse {
    private String id;
    private String name;
    private int decimals;
    private long current_supply;
    private String control_account;
    private String creator;
    private long created_block;
    private String operation_id;
    private long created_time;

    public TokenDetailResponse() {
    }

    public TokenDetailResponse(BeowulfToken beowulfToken) {
        this.id = beowulfToken.getId().toHexString();
        this.name = beowulfToken.getName();
        this.decimals = beowulfToken.getDecimals();
        this.current_supply = beowulfToken.getCurrent_supply();
        this.control_account = beowulfToken.getControl_account();
        this.creator = beowulfToken.getCreator();
        this.created_block = beowulfToken.getCreated_block();
        this.operation_id = beowulfToken.getOperation_id();
        this.created_time = beowulfToken.getCreated_at();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDecimals() {
        return decimals;
    }

    public void setDecimals(int decimals) {
        this.decimals = decimals;
    }

    public long getCurrent_supply() {
        return current_supply;
    }

    public void setCurrent_supply(long current_supply) {
        this.current_supply = current_supply;
    }

    public String getControl_account() {
        return control_account;
    }

    public void setControl_account(String control_account) {
        this.control_account = control_account;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public long getCreated_block() {
        return created_block;
    }

    public void setCreated_block(long created_block) {
        this.created_block = created_block;
    }

    public long getCreated_time() {
        return created_time;
    }

    public void setCreated_time(long created_time) {
        this.created_time = created_time;
    }

    public String getOperation_id() {
        return operation_id;
    }

    public void setOperation_id(String operation_id) {
        this.operation_id = operation_id;
    }
}
