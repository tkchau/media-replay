package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfAccount;

public class CreatedAccountResponse {

    private String id;
    private String created_operation_id;
    private String name;
    private long created_at;

    public CreatedAccountResponse() {
    }

    public CreatedAccountResponse(BeowulfAccount beowulfAccount) {
        this.id = beowulfAccount.getId().toHexString();
        this.created_operation_id = beowulfAccount.getCreated_operation_id();
        this.name = beowulfAccount.getName();
        this.created_at = beowulfAccount.getCreated_at();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreated_operation_id() {
        return created_operation_id;
    }

    public void setCreated_operation_id(String created_operation_id) {
        this.created_operation_id = created_operation_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }
}
