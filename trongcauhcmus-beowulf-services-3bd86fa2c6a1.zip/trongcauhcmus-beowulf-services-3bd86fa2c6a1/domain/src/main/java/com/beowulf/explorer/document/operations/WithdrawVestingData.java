package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.WithdrawVestingOperation;

public class WithdrawVestingData extends OperationData{
    private String account;
    private Asset vestingShares;
    private Asset fee;

    public WithdrawVestingData() {
    }

    public WithdrawVestingData(WithdrawVestingOperation withdrawVestingOperation) {
        this.account = withdrawVestingOperation.getAccount().getName();
        this.vestingShares = withdrawVestingOperation.getVestingShares();
        this.fee = withdrawVestingOperation.getFee();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Asset getVestingShares() {
        return vestingShares;
    }

    public void setVestingShares(Asset vestingShares) {
        this.vestingShares = vestingShares;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }
}
