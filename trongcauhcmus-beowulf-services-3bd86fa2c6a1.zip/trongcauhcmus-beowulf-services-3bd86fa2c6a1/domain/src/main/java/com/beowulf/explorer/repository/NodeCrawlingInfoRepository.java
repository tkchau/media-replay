package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.NodeInfo;
import com.beowulf.explorer.repository.extend.NodeCrawlingInfoRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface NodeCrawlingInfoRepository extends MongoRepository<NodeInfo, ObjectId>, NodeCrawlingInfoRepositoryExtend {
}
