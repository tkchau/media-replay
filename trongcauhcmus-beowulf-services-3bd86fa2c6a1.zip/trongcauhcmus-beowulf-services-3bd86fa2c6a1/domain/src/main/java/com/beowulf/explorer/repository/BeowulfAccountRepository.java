package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.repository.extend.BeowulfAccountRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface BeowulfAccountRepository extends MongoRepository<BeowulfAccount, ObjectId>, BeowulfAccountRepositoryExtend {

    @Query(value = "{'name' : ?0}")
    BeowulfAccount findAccountByName(String name);

}
