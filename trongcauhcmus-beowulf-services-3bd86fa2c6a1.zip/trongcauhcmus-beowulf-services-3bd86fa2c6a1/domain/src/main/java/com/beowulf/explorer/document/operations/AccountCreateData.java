package com.beowulf.explorer.document.operations;

import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.AccountCreateOperation;

public class AccountCreateData extends OperationData{
    private Asset fee;
    private String creator;
    private String newAccountName;
    private AuthorityData owner;
    private String jsonMetadata;

    public AccountCreateData() {
    }

    public AccountCreateData(AccountCreateOperation accountCreateOperation){
        this.fee = accountCreateOperation.getFee();
        this.creator = accountCreateOperation.getCreator().getName();
        this.newAccountName = accountCreateOperation.getNewAccountName().getName();
        AuthorityData authorityData = new AuthorityData(accountCreateOperation.getOwner());
        this.owner = authorityData;
        this.jsonMetadata = accountCreateOperation.getJsonMetadata();
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }

    public Asset getFee() {
        return fee;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreator() {
        return creator;
    }

    public void setNewAccountName(String newAccountName) {
        this.newAccountName = newAccountName;
    }

    public String getNewAccountName() {
        return newAccountName;
    }

    public void setOwner(AuthorityData owner) {
        this.owner = owner;
    }

    public AuthorityData getOwner() {
        return owner;
    }

    public String getJsonMetadata() {
        return jsonMetadata;
    }

    public void setJsonMetadata(String jsonMetadata) {
        this.jsonMetadata = jsonMetadata;
    }
}



