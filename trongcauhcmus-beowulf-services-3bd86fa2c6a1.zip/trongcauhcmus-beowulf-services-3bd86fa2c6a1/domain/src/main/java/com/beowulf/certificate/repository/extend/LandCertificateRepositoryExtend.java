package com.beowulf.certificate.repository.extend;

import com.beowulf.certificate.document.BeowulfLandCertificate;
import org.bson.types.ObjectId;

public interface LandCertificateRepositoryExtend {

    BeowulfLandCertificate findLandCertificateByCertId(String certId);

    boolean updateCertificateByObjectId(ObjectId id, BeowulfLandCertificate newLandCert);

}
