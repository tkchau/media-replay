package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.Action;
import org.bson.types.ObjectId;

public interface ActionRepositoryExtend {
	
    boolean addNewAction(Action action);

    boolean removeAction(ObjectId id);
}
