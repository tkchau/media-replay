package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.TransferToVestingOperation;

public class TransferToVestingData extends OperationData{
    private String from;
    private String to;
    private Asset amount;
    private Asset fee;

    public TransferToVestingData() {
    }

    public TransferToVestingData(TransferToVestingOperation transferToVestingOperation) {
        this.from = transferToVestingOperation.getFrom().getName();
        this.to = transferToVestingOperation.getTo().getName();
        this.amount = transferToVestingOperation.getAmount();
        this.fee = transferToVestingOperation.getFee();
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public Asset getAmount() {
        return amount;
    }

    public void setAmount(Asset amount) {
        this.amount = amount;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }
}
