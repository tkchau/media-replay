package com.beowulf.model.chart;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

public enum ChartType {

    TOTAL_TX("total_tx"),
    TOTAL_BLOCK("total_block"),
    TOTAL_ACCOUNT("total_account"),
    AVG_TX_COUNT("transactions_per_block"),
    AVG_ACCOUNT_COUNT("accounts_per_block"),
    AVG_TRANSFER_AMOUNT("bwf_transfer_per_block");

    private String type;

    ChartType(String type) {
        this.type = type;
    }

    public static List<ChartType> valueAsList() {
        return Arrays.asList(ChartType.values());
    }

    public static boolean contains(String value) {
        try {
            return valueAsList()
                    .stream().anyMatch(e -> e.getType().equals(value));
        } catch (Exception e) {
            return false;
        }
    }

    public static <E extends Enum<E>> boolean contains(Class<E> _enumClass, String value) {
        try {
            return EnumSet.allOf(_enumClass)
                    .contains(Enum.valueOf(_enumClass, value));
        } catch (Exception e) {
            return false;
        }
    }

    public static ChartType from(String slug) {
        for (ChartType value : ChartType.values()) {
            if (value.type.equals(slug)) {
                return value;
            }
        }
        return null;
    }

    public String getType() {
        return type;
    }
}
