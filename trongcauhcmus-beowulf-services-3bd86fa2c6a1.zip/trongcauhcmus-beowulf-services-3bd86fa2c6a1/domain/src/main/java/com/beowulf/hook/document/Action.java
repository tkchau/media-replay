package com.beowulf.hook.document;


import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = CollectionName.ACTIONS)
public class Action {
    ObjectId id;
    @Indexed(unique = true)
    private String actionId;

    @Indexed(expireAfterSeconds = 36000)
    private Date createAt;

    public String getActionId() {
        return actionId;
    }

    public void setActionId(String actionId) {
        this.actionId = actionId;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }
}
