package com.beowulf.certificate.repository.impl;

import com.beowulf.certificate.document.BeowulfLandCertificate;
import com.beowulf.certificate.document.certdata.CertificateType;
import com.beowulf.certificate.repository.extend.LandCertificateRepositoryExtend;
import com.beowulf.constants.CollectionName;
import com.mongodb.client.result.UpdateResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;


public class LandCertificateRepositoryImpl implements LandCertificateRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public BeowulfLandCertificate findLandCertificateByCertId(String certId) {
        Pair<String, Object> filterLandCertId = Pair.of(CertificateType.LAND_CERT_KEY_ID, certId);
        return findCertificateBy(filterLandCertId);
    }

    @Override
    public boolean updateCertificateByObjectId(ObjectId id, BeowulfLandCertificate newLandCert) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        Update update = new Update();
        update.set("transaction_id", newLandCert.getTransaction_id());
        update.set("data", newLandCert.getData());
        update.set("tx_histories", newLandCert.getTx_histories());
        UpdateResult result = mongoTemplate.updateFirst(query, update, BeowulfLandCertificate.class);
        return result.getModifiedCount() != 0;
    }

    private BeowulfLandCertificate findCertificateBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        return mongoTemplate.findOne(query, BeowulfLandCertificate.class, CollectionName.LAND_CERTIFICATES);
    }

}
