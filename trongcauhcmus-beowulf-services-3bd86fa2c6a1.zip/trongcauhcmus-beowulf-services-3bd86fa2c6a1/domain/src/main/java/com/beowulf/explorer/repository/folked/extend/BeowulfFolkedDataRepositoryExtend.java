package com.beowulf.explorer.repository.folked.extend;

import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.BeowulfTransaction;

public interface BeowulfFolkedDataRepositoryExtend {
    void insertFolkedTransaction(BeowulfTransaction folkedTx);

    void insertFolkedBlock(BeowulfBlock folkedBlock);

    void insertFolkedOperation(BeowulfOperation folkedOperation);
}
