package com.beowulf.explorer.repository.extend;

public interface AccountRepositoryExtend {

}
