package com.beowulf.model.response;

public class EtherValueResponse {
    private String ethbtc;
    private long ethbtc_timestamp;
    private String ethusd;
    private long ethusd_timestamp;

    public String getEthbtc() {
        return ethbtc;
    }

    public void setEthbtc(String ethbtc) {
        this.ethbtc = ethbtc;
    }

    public long getEthbtc_timestamp() {
        return ethbtc_timestamp;
    }

    public void setEthbtc_timestamp(long ethbtc_timestamp) {
        this.ethbtc_timestamp = ethbtc_timestamp;
    }

    public String getEthusd() {
        return ethusd;
    }

    public void setEthusd(String ethusd) {
        this.ethusd = ethusd;
    }

    public long getEthusd_timestamp() {
        return ethusd_timestamp;
    }

    public void setEthusd_timestamp(long ethusd_timestamp) {
        this.ethusd_timestamp = ethusd_timestamp;
    }
}
