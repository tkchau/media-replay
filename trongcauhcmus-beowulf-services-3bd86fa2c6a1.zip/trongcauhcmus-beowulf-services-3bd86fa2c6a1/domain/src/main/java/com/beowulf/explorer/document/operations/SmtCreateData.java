package com.beowulf.explorer.document.operations;

import com.beowulf.explorer.document.operations.typeData.AssetData;
import com.beowulfchain.beowulfj.base.models.FutureExtensions;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.SmtCreateOperation;

import java.util.List;

public class SmtCreateData extends OperationData {
    private String controlAccount;
    private String creator;
    private AssetData symbol;
    private Asset smtCreationFee;
    private int precision;
    private List<FutureExtensions> extensions;
    private long maxSupply;

    public SmtCreateData() {
    }

    public SmtCreateData(SmtCreateOperation smtCreateOperation) {
        this.controlAccount = smtCreateOperation.getControlAccount().getName();
        this.creator = smtCreateOperation.getCreator().getName();
        this.symbol = new AssetData(smtCreateOperation.getSymbol());
        this.smtCreationFee = smtCreateOperation.getSmtCreationFee();
        this.precision = smtCreateOperation.getPrecision().intValue();
        this.extensions = smtCreateOperation.getExtensions();
        this.maxSupply = smtCreateOperation.getMaxSupply();
    }

    public String getControlAccount() {
        return controlAccount;
    }

    public void setControlAccount(String controlAccount) {
        this.controlAccount = controlAccount;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public AssetData getSymbol() {
        return symbol;
    }

    public void setSymbol(AssetData symbol) {
        this.symbol = symbol;
    }

    public Asset getSmtCreationFee() {
        return smtCreationFee;
    }

    public void setSmtCreationFee(Asset smtCreationFee) {
        this.smtCreationFee = smtCreationFee;
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public List<FutureExtensions> getExtensions() {
        return extensions;
    }

    public void setExtensions(List<FutureExtensions> extensions) {
        this.extensions = extensions;
    }

    public long getMaxSupply() {
        return maxSupply;
    }

    public void setMaxSupply(long maxSupply) {
        this.maxSupply = maxSupply;
    }
}
