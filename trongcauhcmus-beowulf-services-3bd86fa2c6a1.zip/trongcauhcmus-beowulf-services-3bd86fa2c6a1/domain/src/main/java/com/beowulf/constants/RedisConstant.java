package com.beowulf.constants;

public class RedisConstant {
    public static final String TOPIC_KEY_EXPIRED = "__key*__:expired";

    public static final String PREFIX_PLAN_EXPIRED = "plan_expire";
    public static final String PREFIX_PAYMENT_EXPIRED = "payment_expire";

    public static final String PREFIX_CRYPITOR_PAYMENT_EXPIRED = "crypitor_payment_expire";
}
