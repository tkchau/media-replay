package com.beowulf.constants;

public class ApiKeyStatus {
    public static final String ENABLE = "enable";
    public static final String DISABLE = "disable";
}
