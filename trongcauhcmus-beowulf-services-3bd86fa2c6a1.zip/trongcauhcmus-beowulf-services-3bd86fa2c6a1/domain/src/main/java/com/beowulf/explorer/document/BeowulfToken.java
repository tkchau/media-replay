package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.operations.SmtCreateData;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.TOKENS)
public class BeowulfToken {

    @Id
    private ObjectId id;

    @Indexed(unique = true)
    private String name;

    @Indexed
    private String control_account;

    private int decimals;
    private String creator;
    private long current_supply;
    private long created_block;
    private String operation_id;
    /**
     * this is the block timestamp include the creation
     */
    private long created_at;

    private String description;
    private String image_url;

    public BeowulfToken() {
    }

    public BeowulfToken(SmtCreateData smtCreateData) {
        this.name = smtCreateData.getSymbol().getName();
        this.decimals = smtCreateData.getSymbol().getDecimals();
        this.control_account = smtCreateData.getControlAccount();
        this.creator = smtCreateData.getCreator();
        this.current_supply = smtCreateData.getMaxSupply();
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDecimals() {
        return decimals;
    }

    public void setDecimals(int decimals) {
        this.decimals = decimals;
    }

    public String getControl_account() {
        return control_account;
    }

    public void setControl_account(String control_account) {
        this.control_account = control_account;
    }

    public long getCurrent_supply() {
        return current_supply;
    }

    public void setCurrent_supply(long current_supply) {
        this.current_supply = current_supply;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public long getCreated_block() {
        return created_block;
    }

    public void setCreated_block(long created_block) {
        this.created_block = created_block;
    }

    public String getOperation_id() {
        return operation_id;
    }

    public void setOperation_id(String operation_id) {
        this.operation_id = operation_id;
    }

    public long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(long created_at) {
        this.created_at = created_at;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }
}
