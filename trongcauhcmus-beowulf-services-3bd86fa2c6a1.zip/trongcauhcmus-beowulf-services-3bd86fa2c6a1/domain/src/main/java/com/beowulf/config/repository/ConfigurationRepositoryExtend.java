package com.beowulf.config.repository;

import com.beowulf.config.document.Configuration;

public interface ConfigurationRepositoryExtend {
    public <T extends Configuration> T findConfigByKey(String key, Class<T> _class);
}
