package com.beowulf.handler;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.ResponseObject;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.ServiceExceptionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.security.InvalidParameterException;

@RestControllerAdvice()
public class ServiceExceptionHandler {

    private static HttpHeaders header;

    static {
        header = new HttpHeaders();
        header.setContentType(MediaType.APPLICATION_JSON_UTF8);
    }

    @ExceptionHandler({ServiceException.class})
    protected Object handleServiceException(HttpServletRequest req, HttpServletResponse res, final ServiceException ex) throws IOException {
        HttpStatus httpStatus = ex.getHttpStatus();
        ResponseObject response = ex.generateResponse();
        return new ResponseEntity<ResponseObject>(response, header, httpStatus);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    protected Object handleMethodArgumentNotValid(HttpServletRequest request, MethodArgumentNotValidException e) {
        if (e.getBindingResult().getAllErrors().get(0) instanceof FieldError) {
            FieldError fieldError = (FieldError) e.getBindingResult().getAllErrors().get(0);
            String error_message = String.format("Invalid param '%s', value '%s' is rejected, %s", fieldError.getField(), fieldError.getRejectedValue(), fieldError.getDefaultMessage());
            ServiceException exception = ServiceExceptionUtils.invalidRequestParam(error_message);
            return new ResponseEntity<ResponseObject>(exception.generateResponse(), header, exception.getHttpStatus());
        }
        e.printStackTrace();
        return getResponseObject();
    }

    @ExceptionHandler({MethodArgumentTypeMismatchException.class})
    protected Object handleMethodArgumentTypeMismatchException(HttpServletRequest request, MethodArgumentTypeMismatchException e) {
        String error_message = String.format("Invalid param '%s', value '%s' is rejected", e.getName(), e.getValue());
        ServiceException exception = ServiceExceptionUtils.invalidRequestParam(error_message);
        System.out.println(e.getMessage());
        return new ResponseEntity<ResponseObject>(exception.generateResponse(), header, exception.getHttpStatus());
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    protected ResponseEntity<ResponseObject> handleHttpMessageNotReadable(HttpServletRequest request, HttpMessageNotReadableException e) {
        return getResponseObject();
    }

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<ResponseObject> handleRuntimeException(final Exception ex) {
        ex.printStackTrace();
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        ResponseObject response = null;
        return new ResponseEntity<ResponseObject>(response, header, httpStatus);
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    protected Object methodNotSupported(HttpServletRequest request, final HttpRequestMethodNotSupportedException e) {
        System.out.println("Call api method not supported: url: " + request.getRequestURI() +
                "\n - method: " + request.getMethod() +
                "\n - IP: " + request.getRemoteAddr() +
                "\n - User-Agent: " + request.getHeader("User-Agent") +
                "\n - Cookie: " + request.getHeader("Cookie"));
        ResponseObject responseObject = new ResponseObject();
        responseObject.setError("405000");
        responseObject.setError_description(e.getMessage());
        return new ResponseEntity<ResponseObject>(responseObject, header, HttpStatus.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler({ServletException.class})
    protected ResponseEntity<ResponseObject> handleServletException(final ServletException ex) {
        HttpStatus httpStatus = HttpStatus.NOT_ACCEPTABLE;
        ResponseObject response = new ResponseObject();
        response.setError("406000");
        response.setError_description(ex.getMessage());
        return new ResponseEntity<ResponseObject>(response, header, httpStatus);
    }

    private ResponseEntity<ResponseObject> getResponseObject() {
        ServiceException exception = ServiceExceptionUtils.invalidJSON();
        ResponseObject response = exception.generateResponse();
        HttpStatus httpStatus = exception.getHttpStatus();
        return new ResponseEntity<ResponseObject>(response, header, httpStatus);
    }

    @ExceptionHandler({ConstraintViolationException.class})
    protected ResponseEntity<Object> handleConstraintViolationException(final ConstraintViolationException ex) {
        String message = ex.getConstraintViolations().iterator().next().getMessage();
        ResponseObject responseObject;
        HttpStatus httpStatus;
        try {
            responseObject = GsonSingleton.getInstance().fromJson(message, ResponseObject.class);
            String errorCode = responseObject.getError();
            String httpCode = errorCode.substring(0, 3);
            httpStatus = HttpStatus.valueOf(Integer.parseInt(httpCode));
        } catch (Exception e) {
            ServiceException serviceException = ServiceExceptionUtils.invalidRequestParam(message);
            responseObject = serviceException.generateResponse();
            httpStatus = serviceException.getHttpStatus();
        }

        return new ResponseEntity<>(responseObject, header, httpStatus);
    }

    @ExceptionHandler({IllegalArgumentException.class, InvalidParameterException.class})
    protected ResponseEntity<ResponseObject> handleInvalidParam(final Exception e1) {
        ServiceException exception;
        exception = ServiceExceptionUtils.invalidRequestParam(e1.getMessage());
        return new ResponseEntity<ResponseObject>(exception.generateResponse(), header, exception.getHttpStatus());
    }
}
