package com.beowulf.model.request;

public class ListTokenPagingRequest extends ListObjectsPagingRequest {
}
