package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.Action;
import com.beowulf.explorer.repository.extend.ActionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ActionRepository extends MongoRepository<Action, ObjectId>, ActionRepositoryExtend {

}
