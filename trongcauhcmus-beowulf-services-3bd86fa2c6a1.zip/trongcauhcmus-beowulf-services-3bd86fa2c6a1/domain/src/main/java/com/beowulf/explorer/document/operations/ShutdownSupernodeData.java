package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.operations.virtual.ShutdownSupernodeOperation;

public class ShutdownSupernodeData extends OperationData{
    private String owner;

    public ShutdownSupernodeData() {
    }

    public ShutdownSupernodeData(ShutdownSupernodeOperation shutdownSupernodeOperation) {
        this.owner = shutdownSupernodeOperation.getOwner().getName();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}
