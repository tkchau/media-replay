package com.beowulf.constants;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum SupportedCoin {
    TUSD("0x0000000000085d4780b73119b644ae5ecd22b376", "1000000000000000000"),
    USDT("0xdac17f958d2ee523a2206206994597c13d831ec7", "1000000000000000000"),
    BWF("0x3e3b3849b25964ad844d75759e951fbf3af43194", "100000"),
    ETH("Ethereum", "1000000000000000000");

    private String address;
    private String decimal;

    SupportedCoin(String address, String decimal) {
        this.address = address;
        this.decimal = decimal;
    }

    public String getAddress() {
        return address;
    }

    public String getDecimal() {
        return decimal;
    }

    public static List<SupportedCoin> valueAsList() {
        return Arrays.asList(SupportedCoin.values());
    }

    public static Map<String, String> getSupportedCoin() {
        Map<String, String> supportedCoins = new HashMap<>();
        for (SupportedCoin value : SupportedCoin.values()) {
            supportedCoins.put(value.name(), value.getAddress());
        }
        return supportedCoins;
    }

    public static boolean contain(String value) {
        try {
            return valueAsList().stream().anyMatch(c -> c.getAddress().equals(value) || c.name().equals(value));
        } catch (Exception e) {

        }
        return false;
    }

}