package com.beowulf.account.repository.impl;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.repository.extend.ApiKeyRepositoryExtend;
import com.mongodb.client.ClientSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class ApiKeyRepositoryImpl implements ApiKeyRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean decreaseCounting(ClientSession session, ApiKey apiKey) throws Exception {
        Query query = new Query();
        query.addCriteria(Criteria.where("api_key").is(apiKey.getApi_key()));

        Update update = new Update();
        update.inc("create_wallet_counting_per_day", -1L);
        mongoTemplate.withSession(session).updateFirst(query, update, ApiKey.class);
        return true;
    }

    @Override
    public boolean increaseCounting(ClientSession session, ApiKey apiKey) throws Exception {
        Query query = new Query();
        query.addCriteria(Criteria.where("api_key").is(apiKey.getApi_key()));

        Update update = new Update();
        update.inc("create_wallet_counting_per_day", 1L);
        if (session != null)
            mongoTemplate.withSession(session).updateFirst(query, update, ApiKey.class);
        else mongoTemplate.updateFirst(query, update, ApiKey.class);
        return true;
    }

    @Override
    public boolean saveOrOverWrite(ClientSession session, ApiKey apiKey) throws Exception {
        mongoTemplate.withSession(session).save(apiKey);
        return true;
    }
}
