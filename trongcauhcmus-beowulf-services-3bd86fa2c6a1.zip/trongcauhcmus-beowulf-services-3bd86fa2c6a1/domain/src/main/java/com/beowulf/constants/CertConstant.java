package com.beowulf.constants;

public class CertConstant {
    public static final String TYPE_KEY = "type";
}
