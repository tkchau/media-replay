package com.beowulf.model.request;

public class CloseWebHookRequest extends HttpRequestObject {
    private String address;

    public CloseWebHookRequest() {
    }

    public CloseWebHookRequest(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
