package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.model.aggregate.AggregateFeeReceived;
import org.bson.types.ObjectId;

import java.util.List;

public interface TransactionRepositoryExtend {

	public List<BeowulfTransaction> getTransactionBelongToAccount(String name, ObjectId fromId, long startTime, long endTime,
                                                                  int limit, String direction);

	public List<BeowulfTransaction> getTransactionConfirmedByAccount(String name, ObjectId fromId, long startTime,
                                                                     long endTime, int limit, String direction);

	public List<BeowulfTransaction> getTransferTransactionByAccountName(String name, ObjectId fromId, long startTime,
                                                                        long endTime, int limit, String direction);

	public List<BeowulfTransaction> getCreateAccountTransactionByAccountName(String name, ObjectId fromId, long startTime,
                                                                             long endTime, int limit, String direction);

	public List<AggregateFeeReceived> getTotalFeeSupernodeReceived(String name, long startTime, long endTime);

	public List<BeowulfTransaction> getLastestTransactions(int limit);

	public List<BeowulfTransaction> getTransaction(ObjectId fromId, long startTime, long endTime, int limit, String direction);

	public List<BeowulfTransaction> getTransactionBelongToBlock(List<Long> blockNumbers);

	public List<BeowulfTransaction> getTransactionByBlockNumber(long blockNumber, ObjectId fromId, long startTime,
                                                                long endTime, int limit, String direction);

	public List<BeowulfTransaction> getListTransactionById(List<String> transactionIds);

	public List<BeowulfTransaction> getTransferTransactionByCurrencyCode(String currencyCode, ObjectId fromId, long startTime,
                                                                         long endTime, int limit, String direction);

}
