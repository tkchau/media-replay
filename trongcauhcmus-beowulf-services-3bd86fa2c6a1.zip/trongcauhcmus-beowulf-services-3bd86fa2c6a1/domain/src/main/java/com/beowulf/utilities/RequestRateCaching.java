package com.beowulf.utilities;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class RequestRateCaching {
    private static LoadingCache<String, Integer>
            requestCountingPerSecond = CacheBuilder
            .newBuilder()
            .expireAfterWrite(1, TimeUnit.SECONDS)
            .build(new CacheLoader<String, Integer>() {
                public Integer load(String key) {
                    return 0;
                }
            });

    private static LoadingCache<String, Integer>
            requestCountingPerMinute = CacheBuilder
            .newBuilder()
            .expireAfterWrite(1, TimeUnit.MINUTES)
            .build(new CacheLoader<String, Integer>() {
                public Integer load(String key) {
                    return 0;
                }
            });

    private static LoadingCache<String, Integer>
            requestCountingPerHour = CacheBuilder
            .newBuilder()
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<String, Integer>() {
                public Integer load(String key) {
                    return 0;
                }
            });

    private static LoadingCache<String, Integer>
            requestCountingPerDay = CacheBuilder
            .newBuilder()
            .expireAfterWrite(1, TimeUnit.DAYS)
            .build(new CacheLoader<String, Integer>() {
                public Integer load(String key) {
                    return 0;
                }
            });

    public static int getPerSecond(String clientIpAddress) throws ExecutionException {
        return requestCountingPerSecond.get(clientIpAddress);
    }

    public static void putPerSecond(String clientIpAddress, int requests) {
        requestCountingPerSecond.put(clientIpAddress, requests);
    }

    public static int getPerMinute(String clientIpAddress) throws ExecutionException {
        return requestCountingPerMinute.get(clientIpAddress);
    }

    public static void putPerMinute(String clientIpAddress, int requests) {
        requestCountingPerMinute.put(clientIpAddress, requests);
    }

    public static int getPerHour(String clientIpAddress) throws ExecutionException {
        return requestCountingPerHour.get(clientIpAddress);
    }

    public static void putPerHour(String clientIpAddress, int requests) {
        requestCountingPerHour.put(clientIpAddress, requests);
    }

    public static int getPerDay(String clientIpAddress) throws ExecutionException {
        return requestCountingPerDay.get(clientIpAddress);
    }

    public static void putPerDay(String clientIpAddress, int requests) {
        requestCountingPerDay.put(clientIpAddress, requests);
    }

    public static int get(String clientIpAddress, TimeUnit timeUnit) throws ExecutionException {
        switch (timeUnit) {
            case SECONDS:
                return getPerSecond(clientIpAddress);
            case MINUTES:
                return getPerMinute(clientIpAddress);
            case HOURS:
                return getPerHour(clientIpAddress);
            default:
                return getPerDay(clientIpAddress);
        }
    }

    public static void put(String clientIpAddress, int requests, TimeUnit timeUnit) {
        switch (timeUnit) {
            case SECONDS:
                putPerSecond(clientIpAddress, requests);
                return;
            case MINUTES:
                putPerMinute(clientIpAddress, requests);
                return;
            case HOURS:
                putPerHour(clientIpAddress, requests);
                return;
            default:
                putPerDay(clientIpAddress, requests);
        }
    }

    public static ConcurrentMap<String, Integer> listAll(TimeUnit timeUnit) {
        switch (timeUnit) {
            case SECONDS:
                return requestCountingPerSecond.asMap();
            case MINUTES:
                return requestCountingPerMinute.asMap();
            case HOURS:
                return requestCountingPerHour.asMap();
            default:
                return requestCountingPerDay.asMap();
        }
    }


}
