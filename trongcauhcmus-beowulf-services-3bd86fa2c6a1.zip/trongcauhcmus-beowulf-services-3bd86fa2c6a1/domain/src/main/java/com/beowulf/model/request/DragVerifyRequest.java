package com.beowulf.model.request;

public class DragVerifyRequest {
    private String token;
    private int x;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
}
