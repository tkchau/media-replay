package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.SupernodeUpdateOperation;

public class SupernodeUpdateData extends OperationData{
    private String owner;
    private String blockSigningKey;
    private Asset fee;

    public SupernodeUpdateData() {
    }

    public SupernodeUpdateData(SupernodeUpdateOperation supernodeUpdateOperation) {
        this.owner = supernodeUpdateOperation.getOwner().getName();
        this.blockSigningKey = supernodeUpdateOperation.getBlockSigningKey().getAddressFromPublicKey();
        this.fee = supernodeUpdateOperation.getFee();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBlockSigningKey() {
        return blockSigningKey;
    }

    public void setBlockSigningKey(String blockSigningKey) {
        this.blockSigningKey = blockSigningKey;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }
}
