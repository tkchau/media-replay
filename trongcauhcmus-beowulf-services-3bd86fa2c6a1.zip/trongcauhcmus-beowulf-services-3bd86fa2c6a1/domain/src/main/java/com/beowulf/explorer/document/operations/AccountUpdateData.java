package com.beowulf.explorer.document.operations;

import com.beowulf.explorer.document.operations.typeData.AuthorityData;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.AccountUpdateOperation;

public class AccountUpdateData extends OperationData{
    private String account;
    private Asset fee;
    private AuthorityData owner;
    private String jsonMetadata;

    public AccountUpdateData() {
    }

    public AccountUpdateData(AccountUpdateOperation accountUpdateOperation) {
        this.account = accountUpdateOperation.getAccount().getName();
        this.fee = accountUpdateOperation.getFee();
        AuthorityData authorityData = new AuthorityData(accountUpdateOperation.getOwner());
        this.owner = authorityData;
        this.jsonMetadata = accountUpdateOperation.getJsonMetadata();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }

    public AuthorityData getOwner() {
        return owner;
    }

    public void setOwner(AuthorityData owner) {
        this.owner = owner;
    }

    public String getJsonMetadata() {
        return jsonMetadata;
    }

    public void setJsonMetadata(String jsonMetadata) {
        this.jsonMetadata = jsonMetadata;
    }
}
