package com.beowulf.account.repository;

import com.beowulf.account.documents.AddressPayment;
import com.beowulf.account.repository.extend.ETHAddressPaymentRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ETHAddressPaymentRepository extends MongoRepository<AddressPayment, ObjectId>, ETHAddressPaymentRepositoryExtend {

    @Query(value = "{'status_address': ?0}")
    List<AddressPayment> findAddressPaymentsByStatusAddress(int status_address);

    @Query(value = "{'address': ?0}")
    AddressPayment findAddressPaymentByAddress(String address);

}
