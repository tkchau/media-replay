package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.extend.BeowulfTransactionRepositoryExtend;
import com.beowulf.utilities.Common;
import com.mongodb.client.result.DeleteResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import java.util.List;

@Repository
public class BeowulfTransactionRepositoryImpl implements BeowulfTransactionRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public List<BeowulfTransaction> getTransactionPaging(ObjectId startId, int limit, String direction) {
        return listTransactionPaging(Constant.PAGING_KEY, startId, limit, direction, null);
    }

    private boolean removeTransactionBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        DeleteResult result = mongoTemplate.remove(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
        return result.getDeletedCount() != 0;
    }

    @Override
    public boolean removeTransactionById(ObjectId id) {
        Pair<String, Object> filterId = Pair.of("_id", id);
        return removeTransactionBy(filterId);
    }

    @Override
    public boolean removeTransactionByTransactionId(String transactionId) {
        Pair<String, Object> filterTransactionId = Pair.of("operation_id", transactionId);
        return removeTransactionBy(filterTransactionId);
    }

    @Override
    public List<BeowulfTransaction> getTransactionPagingByBlockId(String blockId, int position, int limit, String direction) {
        Query query = new Query();
        query.addCriteria(Criteria.where("block_id").is(blockId));
        position = Math.max(position, 0);
        if (Constant.LIST_DIRECTION_NEXT.equals(direction)) {
            query.addCriteria(new Criteria().andOperator(
                    Criteria.where("transaction_num").gte(position),
                    Criteria.where("transaction_num").lt(position + limit))
            );
            query.with(Sort.by(Sort.Direction.ASC, "transaction_num"));
        } else if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction)) {
            query.addCriteria(new Criteria().andOperator(
                    Criteria.where("transaction_num").lt(position),
                    Criteria.where("transaction_num").gte(position - limit)));
            query.with(Sort.by(Sort.Direction.DESC, "transaction_num"));
        }
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
    }

    @Override
    public List<BeowulfTransaction> getTransactionPagingByRegexBlockId(String refBlockId, int position, int limit, String direction) {
        Query query = new Query();
        query.addCriteria(Criteria.where("block_id").regex("^" + refBlockId));
        position = Math.max(position, 0);
        if (Constant.LIST_DIRECTION_NEXT.equals(direction)) {
            query.addCriteria(new Criteria().andOperator(
                    Criteria.where("transaction_num").gte(position),
                    Criteria.where("transaction_num").lt(position + limit))
            );
            query.with(Sort.by(Sort.Direction.ASC, "transaction_num"));
        } else if (Constant.LIST_DIRECTION_PREVIOUS.equals(direction)) {
            query.addCriteria(new Criteria().andOperator(
                    Criteria.where("transaction_num").lt(position),
                    Criteria.where("transaction_num").gte(position - limit)));
            query.with(Sort.by(Sort.Direction.DESC, "transaction_num"));
        }
        query.limit(limit);
        return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
    }

    @Override
    public List<BeowulfTransaction> findByRegexBlock_id(String refBlockId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("block_id").regex("^" + refBlockId));
        return mongoTemplate.find(query, BeowulfTransaction.class, CollectionName.TRANSACTIONS);
    }

    private List<BeowulfTransaction> listTransactionPaging(String key, Object value, int limit, String direction, @Nullable Pair<String, Object> filter) {
        Query query = Common.buildPagingQuery(key, value, limit, direction, filter);
        return mongoTemplate.find(query, BeowulfTransaction.class);
    }
}
