package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.ChartCrawlingConfig;
import com.beowulf.model.chart.record.ChartDailyRecord;

public interface ChartCrawlingConfigRepositoryExtend {

    boolean updateLastCrawlDate(String nodeUrl, long date);

    boolean updateLastCrawlDateOnDestroy(String nodeUrl, long date);

    boolean updateLastCrawlChartRecord(String nodeUrl, ChartDailyRecord record);

    boolean updateLastCrawlChartRecordOnDestroy(String nodeUrl, ChartDailyRecord record);

    long getLastCrawlDate(long startDate, String nodeUrl);

    ChartDailyRecord getLastCrawlChartRecord(long timeCursor, String nodeUrl);

    ChartCrawlingConfig findConfigByNode_url(String node_url);

}
