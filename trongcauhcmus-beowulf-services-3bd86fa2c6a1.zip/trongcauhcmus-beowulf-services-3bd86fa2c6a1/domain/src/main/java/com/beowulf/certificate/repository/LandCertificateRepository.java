package com.beowulf.certificate.repository;

import com.beowulf.certificate.document.BeowulfLandCertificate;
import com.beowulf.certificate.repository.extend.LandCertificateRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface LandCertificateRepository extends MongoRepository<BeowulfLandCertificate, ObjectId>, LandCertificateRepositoryExtend {
    @Query(value = "{'transaction_id': ?0}")
    BeowulfLandCertificate findBeowulfLandCertificateByTransaction_id(String transactionId);
}
