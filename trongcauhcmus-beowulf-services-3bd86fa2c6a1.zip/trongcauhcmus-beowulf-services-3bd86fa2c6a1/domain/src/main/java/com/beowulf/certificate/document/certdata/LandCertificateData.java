package com.beowulf.certificate.document.certdata;

import com.beowulf.utilities.GsonSingleton;
import org.springframework.data.mongodb.core.index.Indexed;

import java.util.List;

public class LandCertificateData extends CertificateData {
    @Indexed(unique = true)
    private String cert_id;
    private List<String> owners;
    private String land_id;
    private String map_id;
    private String issue_date;
    private String address;
    private String area;
    private String form_of_use;
    private String purpose_of_use;
    private String origin_of_use;
    private String time_of_use;
    private String signer;
    private String date_of_signed;

    public LandCertificateData() {
    }

    public static LandCertificateData parseLandCert(String extensionValue) throws IllegalArgumentException {
        try {
            return GsonSingleton.getInstance().fromJson(extensionValue, LandCertificateData.class);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid properties of Land certificate");
        }
    }

    public String getCert_id() {
        return cert_id;
    }

    public void setCert_id(String cert_id) {
        this.cert_id = cert_id;
    }

    public List<String> getOwners() {
        return owners;
    }

    public void setOwners(List<String> owners) {
        this.owners = owners;
    }

    public String getLand_id() {
        return land_id;
    }

    public void setLand_id(String land_id) {
        this.land_id = land_id;
    }

    public String getMap_id() {
        return map_id;
    }

    public void setMap_id(String map_id) {
        this.map_id = map_id;
    }

    public String getIssue_date() {
        return issue_date;
    }

    public void setIssue_date(String issue_date) {
        this.issue_date = issue_date;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getForm_of_use() {
        return form_of_use;
    }

    public void setForm_of_use(String form_of_use) {
        this.form_of_use = form_of_use;
    }

    public String getPurpose_of_use() {
        return purpose_of_use;
    }

    public void setPurpose_of_use(String purpose_of_use) {
        this.purpose_of_use = purpose_of_use;
    }

    public String getOrigin_of_use() {
        return origin_of_use;
    }

    public void setOrigin_of_use(String origin_of_use) {
        this.origin_of_use = origin_of_use;
    }

    public String getTime_of_use() {
        return time_of_use;
    }

    public void setTime_of_use(String time_of_use) {
        this.time_of_use = time_of_use;
    }

    public String getSigner() {
        return signer;
    }

    public void setSigner(String signer) {
        this.signer = signer;
    }

    public String getDate_of_signed() {
        return date_of_signed;
    }

    public void setDate_of_signed(String date_of_signed) {
        this.date_of_signed = date_of_signed;
    }
}
