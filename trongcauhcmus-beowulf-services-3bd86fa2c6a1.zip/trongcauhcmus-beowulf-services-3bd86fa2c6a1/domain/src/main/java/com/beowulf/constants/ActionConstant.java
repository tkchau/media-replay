package com.beowulf.constants;

public class ActionConstant {

    public static final String INSERT_ACTION = "insert";

    public static final String HIGHEST_HANDLE_ACTION = "highest_handle";

    public static final String IRREVERSIBLE_HANDLE_ACTION = "irreversible_handle";

    public static final String CERT_HANDLE_ACTION = "certificate_handle";

    public static final String UPDATE_ACTION = "update";

    public static final String REMOVE_ACTION = "remove";

    public static final int TTL_ACTION = 60;

    public static final int TTL_UPDATE_ACCOUNT_ACTION = 60;

}
