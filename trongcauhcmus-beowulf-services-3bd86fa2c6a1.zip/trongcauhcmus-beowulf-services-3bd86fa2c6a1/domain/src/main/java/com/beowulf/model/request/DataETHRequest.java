package com.beowulf.model.request;

import com.beowulf.model.ethereum.CallAction;

import java.util.List;

public class DataETHRequest {
    private String hash;
    private String blockHash;
    private String address;
    private long blockNumber;
    private int confirmations;
    private String coinType;
    private String transactionIndex;
    private boolean erc20;
    private String in_value;
    private String out_value;
    private String total_value;
    private List<CallAction> trace_actions;

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(String blockHash) {
        this.blockHash = blockHash;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public int getConfirmations() {
        return confirmations;
    }

    public void setConfirmations(int confirmations) {
        this.confirmations = confirmations;
    }

    public String getCoinType() {
        return coinType;
    }

    public void setCoinType(String coinType) {
        this.coinType = coinType;
    }

    public String getTransactionIndex() {
        return transactionIndex;
    }

    public void setTransactionIndex(String transactionIndex) {
        this.transactionIndex = transactionIndex;
    }

    public boolean isErc20() {
        return erc20;
    }

    public void setErc20(boolean erc20) {
        this.erc20 = erc20;
    }

    public String getIn_value() {
        return in_value;
    }

    public void setIn_value(String in_value) {
        this.in_value = in_value;
    }

    public String getOut_value() {
        return out_value;
    }

    public void setOut_value(String out_value) {
        this.out_value = out_value;
    }

    public String getTotal_value() {
        return total_value;
    }

    public void setTotal_value(String total_value) {
        this.total_value = total_value;
    }

    public List<CallAction> getTrace_actions() {
        return trace_actions;
    }

    public void setTrace_actions(List<CallAction> trace_actions) {
        this.trace_actions = trace_actions;
    }
}
