/*
package com.beowulf.model.response;

import com.beowulf.constants.CurrencyConstant;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.utilities.CurrencyUnitConverter;
import com.beowulfchain.beowulfj.enums.OperationType;

public class TransferDetail {

	private String from;
	private String to;
	private String amount;
	private String fee;
	private String memo;
	private String new_account_name;
	private String creator;

	public TransferDetail() {
	}

	public TransferDetail(BeowulfTransaction beowulfTransaction) {
		if (OperationType.TRANSFER_OPERATION.name().equals(beowulfTransaction.getType())
				|| OperationType.TRANSFER_TO_VESTING_OPERATION.name().equals(beowulfTransaction.getType())) {
			this.from = beowulfTransaction.getFrom();
			this.to = beowulfTransaction.getTo();
			this.amount = CurrencyUnitConverter.formatValue(beowulfTransaction.getAmount(),
					CurrencyConstant.DEFAULT_SYSTEM_DECIMAL_FORMAT) + " " + beowulfTransaction.getAmount_currency();
			this.fee = CurrencyUnitConverter.formatValue(beowulfTransaction.getFee(),
					CurrencyConstant.DEFAULT_SYSTEM_DECIMAL_FORMAT) + " " + beowulfTransaction.getFee_currency();
			this.memo = beowulfTransaction.getMemo();
		}
		if (OperationType.ACCOUNT_CREATE_OPERATION.name().equals(beowulfTransaction.getType())) {
			this.new_account_name = beowulfTransaction.getNew_account_name();
			this.creator = beowulfTransaction.getCreator();
			this.fee = CurrencyUnitConverter.formatValue(beowulfTransaction.getFee(),
					CurrencyConstant.DEFAULT_SYSTEM_DECIMAL_FORMAT) + " " + beowulfTransaction.getFee_currency();
		}
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getNew_account_name() {
		return new_account_name;
	}

	public void setNew_account_name(String new_account_name) {
		this.new_account_name = new_account_name;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

}
*/
