package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.operations.virtual.HardforkOperation;

public class HardforkData extends OperationData{
    private long hardforkId;

    public HardforkData() {
    }

    public HardforkData(HardforkOperation hardforkOperation) {
        this.hardforkId = hardforkOperation.getHardforkId();
    }

    public long getHardforkId() {
        return hardforkId;
    }

    public void setHardforkId(long hardforkId) {
        this.hardforkId = hardforkId;
    }
}
