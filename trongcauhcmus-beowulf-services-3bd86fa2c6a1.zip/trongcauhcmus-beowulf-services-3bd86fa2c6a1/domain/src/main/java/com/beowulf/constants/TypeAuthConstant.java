package com.beowulf.constants;

public class TypeAuthConstant {

    public static final int ACCOUNT = 1;

    public static final int KEY = 2;

}
