package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import com.beowulf.model.request.AccountPaymentRequest;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.ACCOUNT_CREATED)
public class PendingAccount {
    @Id
    private ObjectId id;
    @Indexed(unique = true)
    private String payment_id;
    @Indexed(unique = true)
    private String account_name;
    private String pub_key;
    private String email;
    private long start_time;
    private int expired_time;
    private String min_fee_payment;
    private String asset_code;
    @Indexed
    private String address;
    @Indexed
    private int count;

    public PendingAccount() {
    }

    public PendingAccount(String payment_id, AccountPaymentRequest request, long start_time, int expired_time, String min_fee_payment, String address, int count) {
        this.payment_id = payment_id;
        this.account_name = request.getAccount_name();
        this.pub_key = request.getPublic_key();
        this.email = request.getEmail();
        this.start_time = start_time;
        this.expired_time = expired_time;
        this.min_fee_payment = min_fee_payment;
        this.asset_code = request.getAsset_code();
        this.address = address;
        this.count = count;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getPub_key() {
        return pub_key;
    }

    public void setPub_key(String pub_key) {
        this.pub_key = pub_key;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getStart_time() {
        return start_time;
    }

    public void setStart_time(long start_time) {
        this.start_time = start_time;
    }

    public int getExpired_time() {
        return expired_time;
    }

    public void setExpired_time(int expired_time) {
        this.expired_time = expired_time;
    }

    public String getMin_fee_payment() {
        return min_fee_payment;
    }

    public void setMin_fee_payment(String min_fee_payment) {
        this.min_fee_payment = min_fee_payment;
    }

    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
