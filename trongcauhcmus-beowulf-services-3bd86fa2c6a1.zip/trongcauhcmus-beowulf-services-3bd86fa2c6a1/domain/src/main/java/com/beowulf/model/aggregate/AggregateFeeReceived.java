package com.beowulf.model.aggregate;

public class AggregateFeeReceived {
	
	private String supernode;
	private long numberTransaction;
	private long totalFee;
	private long totalBlockReward;

	public String getSupernode() {
		return supernode;
	}
	
	public void setSupernode(String supernode) {
		this.supernode = supernode;
	}

	public long getNumberTransaction() {
		return numberTransaction;
	}

	public void setNumberTransaction(long numberTransaction) {
		this.numberTransaction = numberTransaction;
	}

	public long getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(long totalFee) {
		this.totalFee = totalFee;
	}

	public long getTotalBlockReward() {
		return totalBlockReward;
	}

	public void setTotalBlockReward(long totalBlockReward) {
		this.totalBlockReward = totalBlockReward;
	}

}
