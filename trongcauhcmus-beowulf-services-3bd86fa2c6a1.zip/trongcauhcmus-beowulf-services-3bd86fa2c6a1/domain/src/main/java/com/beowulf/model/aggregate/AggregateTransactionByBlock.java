package com.beowulf.model.aggregate;

public class AggregateTransactionByBlock {
	
	private long blockNumber;
	private long numberTransaction;
	private long totalFee;

	public long getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(long blockNumber) {
		this.blockNumber = blockNumber;
	}

	public long getNumberTransaction() {
		return numberTransaction;
	}

	public void setNumberTransaction(long numberTransaction) {
		this.numberTransaction = numberTransaction;
	}

	public long getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(long totalFee) {
		this.totalFee = totalFee;
	}

}
