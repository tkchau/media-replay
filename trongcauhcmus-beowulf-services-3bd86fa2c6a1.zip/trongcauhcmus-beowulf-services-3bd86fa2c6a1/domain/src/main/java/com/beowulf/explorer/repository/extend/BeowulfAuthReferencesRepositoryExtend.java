package com.beowulf.explorer.repository.extend;

public interface BeowulfAuthReferencesRepositoryExtend {
    boolean removeOldAccountReference(String refValue, String accountName);
}
