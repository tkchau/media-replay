package com.beowulf.model;

public class HttpRes {
    public int code;
    public String mess;

    public HttpRes(int code, String mess) {
        this.code = code;
        this.mess = mess;
    }
}
