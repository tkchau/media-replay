package com.beowulf.explorer.repository.folked.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.BeowulfBlock;
import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.folked.extend.BeowulfFolkedDataRepositoryExtend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BeowulfFolkedDataRepositoryImpl implements BeowulfFolkedDataRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public void insertFolkedTransaction(BeowulfTransaction folkedTx) {
        mongoTemplate.save(folkedTx, CollectionName.FOLKED_TRANSACTIONS);
    }

    @Override
    public void insertFolkedBlock(BeowulfBlock folkedBlock) {
        mongoTemplate.save(folkedBlock, CollectionName.FOLKED_BLOCKS);
    }

    @Override
    public void insertFolkedOperation(BeowulfOperation folkedOperation) {
        mongoTemplate.save(folkedOperation, CollectionName.FOLKED_OPERATIONS);
    }
}
