package com.beowulf.hook.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.hook.document.Action;
import com.beowulf.hook.repository.extend.HookActionRepositoryExtend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class HookActionRepositoryImpl implements HookActionRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean addNewAction(Action action) throws DuplicateKeyException {
        mongoTemplate.save(action);
        return true;
    }

    @Override
    public boolean removeAction(Action action) {
        try {
            Query query = new Query();
            query.addCriteria(new Criteria()
                    .andOperator(Criteria.where("name").is(action.getActionId()),
                            Criteria.where("action").is(action.getActionId())));
            mongoTemplate.remove(query, Action.class, CollectionName.ACTIONS);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
