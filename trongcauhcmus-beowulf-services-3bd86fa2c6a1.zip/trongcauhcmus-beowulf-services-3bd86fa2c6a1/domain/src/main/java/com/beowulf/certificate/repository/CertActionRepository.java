package com.beowulf.certificate.repository;

import com.beowulf.certificate.document.CertAction;
import com.beowulf.certificate.repository.extend.CertActionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CertActionRepository extends MongoRepository<CertAction, ObjectId>, CertActionRepositoryExtend {
}
