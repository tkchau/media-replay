package com.beowulf.utilities;

import org.bson.types.ObjectId;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

public class DateTimeUtils {

    public static long getTimestampMillsFromObjectId(ObjectId objectId) {
        return objectId.getTimestamp() * 1000L;
    }

    public static Date atStartOfDay(Date date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay);
    }

    public static Date atStartOfDay(long timestamp) {
        Date date = new Date(timestamp);
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay);
    }

    public static Date atEndOfDay(Date date) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
        return localDateTimeToDate(endOfDay);
    }

    public static Date atEndOfDay(long timestamp) {
        Date date = new Date(timestamp);
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
        return localDateTimeToDate(endOfDay);
    }

    public static Date plusMinutes(Date date, long minutes) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime result = localDateTime.plusMinutes(minutes);
        return localDateTimeToDate(result);
    }

    public static Date plusMinutesWithinADay(Date endOfDate, Date date, long minutes) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime result = localDateTime.plusMinutes(minutes);
        if (result.isBefore(dateToLocalDateTime(endOfDate))) {
            return localDateTimeToDate(result);
        }
        return endOfDate;
    }

    public static Date plusOneDay(Date date) {
        return plusDays(date, 1);
    }

    public static Date plusOneDay(long timestamp) {
        return plusDays(new Date(timestamp), 1);
    }

    public static Date plusDays(Date date, long days) {
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        LocalDateTime result = localDateTime.plusDays(days);
        return localDateTimeToDate(result);
    }

    public static Date MIN(Date date1, Date date2) {
        return date1.before(date2) ? date1 : date2;
    }

    public static Date MAX(Date date1, Date date2) {
        return date1.before(date2) ? date2 : date1;
    }

    public static LocalDateTime dateToLocalDateTime(Date date) {
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    private static Date localDateTimeToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date currentStartOfDay() {
        LocalDateTime startOfDay = LocalDateTime.now().with(LocalTime.MIN);
        return localDateTimeToDate(startOfDay);
    }
}
