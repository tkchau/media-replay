package com.beowulf.utilities;

import org.bouncycastle.pqc.math.linearalgebra.ByteUtils;
import org.web3j.crypto.Sign;

public class Numeric {
    public static long fromHexToDec(String n) {
        String prefix = n.substring(0, 2);
        if (prefix.equals("0x")) {
            n = n.substring(2);
            n = n.replaceAll("^(0+)", "");
        }
        return Long.valueOf(n, 16);
    }

    /**
     * optimize address gettting
     *
     * @param address 32 bytes 0x000000000000000000000000abcd....
     * @return address 20 bytes 0xabcd....
     */
    public static String optimizeEthAddress(String address) {
        String prefix = address.substring(0, 2);
        if (prefix.equals("0x")) {
            address = address.substring(2);
        }
        address = "0x" + address.replaceAll("000000000000000000000000", "");
        return address;
    }

    /**
     * concat byte array to sign for ether bitgo multisig
     *
     * @param arrays
     * @return
     */
    public static byte[] concat(byte[]... arrays) {
        // Determine the length of the result array
        int totalLength = 0;
        for (int i = 0; i < arrays.length; i++) {
            totalLength += arrays[i].length;
        }

        // create the result array
        byte[] result = new byte[totalLength];

        // copy the source arrays into the result array
        int currentIndex = 0;
        for (int i = 0; i < arrays.length; i++) {
            System.arraycopy(arrays[i], 0, result, currentIndex, arrays[i].length);
            currentIndex += arrays[i].length;
        }

        return result;
    }

    /**
     * padding zero byte in to data to fit 32 bytes
     *
     * @param data
     * @return
     */
    public static byte[] paddingUint256(byte[] data) {
        int len = data.length;
        byte[] ret = new byte[32];
        System.arraycopy(data, 0, ret, 32 - len, len);
        return ret;
    }

    public static void printSig(Sign.SignatureData signatureData) {
        byte[] r = signatureData.getR();
        byte[] s = signatureData.getS();
        System.out.print("r:");
        for (int i = 0; i < r.length; i++) {
            System.out.print(" " + ByteUtils.toHexString(new byte[]{r[i]}));
        }
        System.out.println();
        System.out.print("s:");
        for (int i = 0; i < s.length; i++) {
            System.out.print(" " + ByteUtils.toHexString(new byte[]{s[i]}));
        }
        System.out.println();
    }

}
