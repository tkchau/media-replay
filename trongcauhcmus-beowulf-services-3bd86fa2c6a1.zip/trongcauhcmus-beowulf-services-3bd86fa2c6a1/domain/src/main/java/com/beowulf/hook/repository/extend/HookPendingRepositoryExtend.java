package com.beowulf.hook.repository.extend;

import com.beowulf.model.TransactionReceipt;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.List;

public interface HookPendingRepositoryExtend {
    List<Document> findValidHookingPending(ObjectId fromId, int limit);

    boolean removePendingTransactionById(ObjectId id);

    boolean increaseCallTimes(ObjectId id);

    void save(TransactionReceipt receipt);
}
