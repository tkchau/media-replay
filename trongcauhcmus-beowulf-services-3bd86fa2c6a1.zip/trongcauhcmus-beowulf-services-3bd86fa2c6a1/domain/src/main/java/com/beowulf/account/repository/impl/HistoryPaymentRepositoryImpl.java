package com.beowulf.account.repository.impl;

import com.beowulf.account.repository.extend.HistoryPaymentRepositoryExtend;

public class HistoryPaymentRepositoryImpl implements HistoryPaymentRepositoryExtend {
}
