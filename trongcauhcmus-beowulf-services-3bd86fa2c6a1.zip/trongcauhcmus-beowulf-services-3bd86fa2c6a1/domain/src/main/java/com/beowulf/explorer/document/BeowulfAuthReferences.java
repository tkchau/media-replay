package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.AUTH_REFERENCES)
public class BeowulfAuthReferences {
    @Id
    private ObjectId id;
    @Indexed
    private String name;
    private int weight;
    private String name_references;
    private int auth_type;

    public BeowulfAuthReferences() {
    }

    public BeowulfAuthReferences(String name, int weight, String name_references, int auth_type) {
        this.name = name;
        this.weight = weight;
        this.name_references = name_references;
        this.auth_type = auth_type;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName_references() {
        return name_references;
    }

    public void setName_references(String name_references) {
        this.name_references = name_references;
    }

    public int getAuth_type() {
        return auth_type;
    }

    public void setAuth_type(int auth_type) {
        this.auth_type = auth_type;
    }

}
