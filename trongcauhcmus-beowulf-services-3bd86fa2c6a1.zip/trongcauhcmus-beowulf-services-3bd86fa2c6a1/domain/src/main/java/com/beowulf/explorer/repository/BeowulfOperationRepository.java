package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfOperation;
import com.beowulf.explorer.repository.extend.BeowulfOperationRepositoryExtend;
import com.beowulfchain.beowulfj.enums.OperationType;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface BeowulfOperationRepository extends MongoRepository<BeowulfOperation, ObjectId>, BeowulfOperationRepositoryExtend {

    @Query(value = "{'operation_id' : ?0}")
    BeowulfOperation findBeowulfOperationByOperation_id(String operationId);

    @Query(value = "{'type' : ?0}")
    List<BeowulfOperation> findBeowulfOperationsByType(OperationType type);
}
