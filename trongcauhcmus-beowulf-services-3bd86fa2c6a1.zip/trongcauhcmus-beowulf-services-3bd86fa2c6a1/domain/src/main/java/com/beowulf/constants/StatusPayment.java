package com.beowulf.constants;

public enum StatusPayment {
    NOT_PAYMENT(0),
    SUCCESS(1),
    OVER_TIME(2),
    NOT_ENOUGH(3),
    ERROR_NETWORK(4);

    private int status_payment;

    StatusPayment(int status_payment) {
        this.status_payment = status_payment;
    }

    public int getStatus_payment() {
        return status_payment;
    }

}
