package com.beowulf.explorer.document.operations;

import com.beowulfchain.beowulfj.protocol.Asset;
import com.beowulfchain.beowulfj.protocol.operations.TransferOperation;

public class TransferData extends OperationData {
    private String from;
    private String to;
    private Asset amount;
    private Asset fee;
    private String memo;

    public TransferData() {
    }

    public TransferData (TransferOperation transferOperation){
        this.from = transferOperation.getFrom().getName();
        this.to = transferOperation.getTo().getName();
        this.amount = transferOperation.getAmount();
        this.fee = transferOperation.getFee();
        this.memo = transferOperation.getMemo();
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public Asset getAmount() {
        return amount;
    }

    public void setAmount(Asset amount) {
        this.amount = amount;
    }

    public Asset getFee() {
        return fee;
    }

    public void setFee(Asset fee) {
        this.fee = fee;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

}
