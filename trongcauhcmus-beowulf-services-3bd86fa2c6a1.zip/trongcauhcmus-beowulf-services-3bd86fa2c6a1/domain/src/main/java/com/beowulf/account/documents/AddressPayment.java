package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.ADDRESS_PAYMENT)
public class AddressPayment {
    @Id
    private ObjectId id;
    @Indexed(unique = true)
    private String address;
    private String private_key;
    @Indexed
    private int status_address;
    private String asset_code;

    public AddressPayment() {
    }

    public AddressPayment(String address, String private_key, int status_address, String asset_code) {
        this.address = address;
        this.private_key = private_key;
        this.status_address = status_address;
        this.asset_code = asset_code;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrivate_key() {
        return private_key;
    }

    public void setPrivate_key(String private_key) {
        this.private_key = private_key;
    }

    public int getStatus_address() {
        return status_address;
    }

    public void setStatus_address(int status_address) {
        this.status_address = status_address;
    }

    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }
}
