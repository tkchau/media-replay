package com.beowulf.hook.repository.extend;

import com.beowulf.hook.document.Action;
import org.springframework.dao.DuplicateKeyException;

public interface HookActionRepositoryExtend {

    boolean addNewAction(Action action) throws DuplicateKeyException;

    boolean removeAction(Action action);
}
