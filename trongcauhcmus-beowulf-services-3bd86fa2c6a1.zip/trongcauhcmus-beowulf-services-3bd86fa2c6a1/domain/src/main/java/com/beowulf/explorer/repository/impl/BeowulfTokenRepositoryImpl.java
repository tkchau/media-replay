package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.BeowulfConstant;
import com.beowulf.constants.CollectionName;
import com.beowulf.constants.Constant;
import com.beowulf.explorer.document.BeowulfToken;
import com.beowulf.explorer.repository.extend.BeowulfTokenRepositoryExtend;
import com.beowulf.utilities.Common;
import com.beowulfchain.beowulfj.protocol.Asset;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import javax.annotation.Nullable;
import java.util.List;

public class BeowulfTokenRepositoryImpl implements BeowulfTokenRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public boolean removeTokenByName(String tokenName) {
        Pair<String, Object> filterName = Pair.of("name", tokenName);
        return removeTokenBy(filterName);
    }

    @Override
    public List<BeowulfToken> getTokenPaging(ObjectId start_id, int limit, String direction) {
        return listTokenPaging(Constant.ID_KEY, start_id, limit, direction, null);
    }

    @Override
    public boolean updateNativeSupply(String asset, Asset currentSupply) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").is(asset));
        Update update = new Update();
        update.set("current_supply", currentSupply.getAmount());
        update.set("decimals", BeowulfConstant.NATIVE_ASSET_PRECISION);
        update.set("operation_id", BeowulfConstant.GENESIS_CREATE_OPERATION_ID);
        UpdateResult result = mongoTemplate.upsert(query, update, BeowulfToken.class, CollectionName.TOKENS);
        return result.getModifiedCount() != 0;
    }

    private List<BeowulfToken> listTokenPaging(String key, Object value, int limit, String direction, @Nullable Pair<String, Object> filter) {
        Query query = Common.buildPagingQuery(key, value, limit, direction, filter);
        return mongoTemplate.find(query, BeowulfToken.class);
    }

    private boolean removeTokenBy(Pair<String, Object> filter) {
        Query query = new Query();
        String key = filter.getFirst();
        Object value = filter.getSecond();
        query.addCriteria(Criteria.where(key).is(value));
        DeleteResult result = mongoTemplate.remove(query, BeowulfToken.class, CollectionName.TOKENS);
        return result.getDeletedCount() != 0;
    }
}
