package com.beowulf.hook.repository;

import com.beowulf.hook.document.SmtTokenInfo;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author trongcauta
 * @time 11:48 AM
 * @data 5/23/19
 */
public interface SmtTokenInfoRepository extends MongoRepository<SmtTokenInfo, ObjectId> {
}
