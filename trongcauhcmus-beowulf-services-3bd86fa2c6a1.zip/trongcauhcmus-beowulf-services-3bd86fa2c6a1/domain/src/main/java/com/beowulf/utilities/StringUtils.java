package com.beowulf.utilities;

public class StringUtils extends org.springframework.util.StringUtils {

    public static boolean isEmpty(String ...arrs) {
        for (String s : arrs) {
            if (org.springframework.util.StringUtils.isEmpty(s)) return true;
        }
        return false;
    }

    public static boolean isNotEmpty(String ...arrs) {
        return !isEmpty(arrs);
    }

    public static boolean isInteger(String ...args)
    {
        for (String s : args)
        {
            try {
                Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return false;
            }
        }

        return true;
    }

    public static boolean match(String s1, String s2) {
        if (hasText(s1))
            return s1.equals(s2);
        return false;
    }
}