package com.beowulf.model.ethereum;

import org.web3j.protocol.parity.methods.response.Trace;

import java.util.List;

public class TraceActionNode {
    private Trace trace;
    private long sub_traces;
    private List<TraceActionNode> children;
    private TraceActionNode parent;

    public TraceActionNode getChildren(int index) {
        if (children == null)
            return null;
        if (index < 0 || index > children.size())
            return null;
        return children.get(index);
    }

    public Trace getTrace() {
        return trace;
    }

    public void setTrace(Trace trace) {
        this.trace = trace;
    }

    public List<TraceActionNode> getChildren() {
        return children;
    }

    public void setChildren(List<TraceActionNode> children) {
        this.children = children;
    }

    public long getSub_traces() {
        return sub_traces;
    }

    public void setSub_traces(long sub_traces) {
        this.sub_traces = sub_traces;
    }

    public TraceActionNode getParent() {
        return parent;
    }

    public void setParent(TraceActionNode parent) {
        this.parent = parent;
    }
}
