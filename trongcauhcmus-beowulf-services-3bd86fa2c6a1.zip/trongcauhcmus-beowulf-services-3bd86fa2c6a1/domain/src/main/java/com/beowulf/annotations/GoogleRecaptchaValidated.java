package com.beowulf.annotations;

import com.beowulf.validator.GoogleRecaptchaValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = GoogleRecaptchaValidator.class)
@Documented
public @interface GoogleRecaptchaValidated {
    String message() default "invalid recaptcha";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String name() default "captcha";
}
