/*
package com.beowulf.model.response;

import java.util.List;

public class CountTransactionResponse {

	private long total_transaction;

	private List<TransactionDetailResponse> lasted_transactions;

	public long getTotal_transaction() {
		return total_transaction;
	}

	public void setTotal_transaction(long total_transaction) {
		this.total_transaction = total_transaction;
	}

	public List<TransactionDetailResponse> getLasted_transactions() {
		return lasted_transactions;
	}

	public void setLasted_transactions(List<TransactionDetailResponse> lasted_transactions) {
		this.lasted_transactions = lasted_transactions;
	}

}
*/
