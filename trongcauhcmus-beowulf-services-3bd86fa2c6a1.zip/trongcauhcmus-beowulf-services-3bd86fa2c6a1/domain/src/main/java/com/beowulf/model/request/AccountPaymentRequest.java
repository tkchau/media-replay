package com.beowulf.model.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class AccountPaymentRequest {
    @NotNull
    @NotEmpty
    @Email(message = "Email should be valid", regexp = ".+@.+\\..+")
    private String email;
    @NotNull
    @NotEmpty
    private String account_name;
    @NotNull
    @NotEmpty
    private String public_key;
    @NotNull
    @NotEmpty
    private String asset_code;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getPublic_key() {
        return public_key;
    }

    public void setPublic_key(String public_key) {
        this.public_key = public_key;
    }

    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }
}
