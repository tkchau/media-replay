package com.beowulf.explorer.document;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.SUPERNODES)
public class BeowulfSupernode {
    @Id
    private ObjectId id;
    @Indexed
    private String supernode_account;
    private String mined_block_id;
    private long mined_block_number;

    private long total_operations;
    private long total_rewards;
    private long total_fee;

    public BeowulfSupernode() {
    }

    public BeowulfSupernode(String supernode_account, String mined_block_id, long mined_block_number, long total_operations, long total_rewards, long total_fee) {
        this.supernode_account = supernode_account;
        this.mined_block_id = mined_block_id;
        this.mined_block_number = mined_block_number;
        this.total_operations = total_operations;
        this.total_rewards = total_rewards;
        this.total_fee = total_fee;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getSupernode_account() {
        return supernode_account;
    }

    public void setSupernode_account(String supernode_account) {
        this.supernode_account = supernode_account;
    }

    public String getMined_block_id() {
        return mined_block_id;
    }

    public void setMined_block_id(String mined_block_id) {
        this.mined_block_id = mined_block_id;
    }

    public long getMined_block_number() {
        return mined_block_number;
    }

    public void setMined_block_number(long mined_block_number) {
        this.mined_block_number = mined_block_number;
    }

    public long getTotal_rewards() {
        return total_rewards;
    }

    public void setTotal_rewards(long total_rewards) {
        this.total_rewards = total_rewards;
    }

    public long getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(long total_fee) {
        this.total_fee = total_fee;
    }

    public long getTotal_operations() {
        return total_operations;
    }

    public void setTotal_operations(long total_operations) {
        this.total_operations = total_operations;
    }
}
