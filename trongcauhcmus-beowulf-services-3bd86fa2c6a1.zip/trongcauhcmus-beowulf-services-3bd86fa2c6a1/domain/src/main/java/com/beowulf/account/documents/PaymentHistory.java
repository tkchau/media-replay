package com.beowulf.account.documents;

import com.beowulf.constants.CollectionName;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.HISTORY_PAYMENT)
public class PaymentHistory {
    @Id
    private ObjectId id;
    @Indexed
    private String payment_id;
    @Indexed
    private String hash;
    @Indexed
    private String account_name;
    private String pub_key;
    private String email;
    private long start_time;
    private long end_time;
    private String in_value;
    private String min_fee;
    private String address;
    private int expired_time;
    private String asset_current_code;
    private int status_payment;

    public PaymentHistory() {
    }

    public PaymentHistory(String hash,
                          PendingAccount pendingAccount,
                          long end_time,
                          String in_value,
                          AddressPayment addressPayment,
                          int status_payment) {
        this.payment_id = pendingAccount.getPayment_id();
        this.hash = hash;
        this.account_name = pendingAccount.getAccount_name();
        this.pub_key = pendingAccount.getPub_key();
        this.email = pendingAccount.getEmail();
        this.start_time = pendingAccount.getStart_time();
        this.end_time = end_time;
        this.in_value = in_value;
        this.min_fee = pendingAccount.getMin_fee_payment();
        this.address = addressPayment.getAddress();
        this.expired_time = pendingAccount.getExpired_time();
        this.asset_current_code = addressPayment.getAsset_code();
        this.status_payment = status_payment;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getPub_key() {
        return pub_key;
    }

    public void setPub_key(String pub_key) {
        this.pub_key = pub_key;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getStart_time() {
        return start_time;
    }

    public void setStart_time(long start_time) {
        this.start_time = start_time;
    }

    public long getEnd_time() {
        return end_time;
    }

    public void setEnd_time(long end_time) {
        this.end_time = end_time;
    }

    public String getIn_value() {
        return in_value;
    }

    public void setIn_value(String in_value) {
        this.in_value = in_value;
    }

    public String getMin_fee() {
        return min_fee;
    }

    public void setMin_fee(String min_fee) {
        this.min_fee = min_fee;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getExpired_time() {
        return expired_time;
    }

    public void setExpired_time(int expired_time) {
        this.expired_time = expired_time;
    }

    public String getAsset_current_code() {
        return asset_current_code;
    }

    public void setAsset_current_code(String asset_current_code) {
        this.asset_current_code = asset_current_code;
    }

    public int getStatus_payment() {
        return status_payment;
    }

    public void setStatus_payment(int status_payment) {
        this.status_payment = status_payment;
    }
}
