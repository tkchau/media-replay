package com.beowulf.account.repository.impl;

import com.beowulf.account.repository.extend.HistoryTransactionRepositoryExtend;

public class HistoryTransactionRepositoryImpl implements HistoryTransactionRepositoryExtend {

}
