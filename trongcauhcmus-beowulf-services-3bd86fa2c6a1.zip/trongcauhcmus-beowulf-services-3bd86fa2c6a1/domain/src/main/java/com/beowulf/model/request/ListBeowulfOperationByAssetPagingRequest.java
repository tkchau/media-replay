package com.beowulf.model.request;

public class ListBeowulfOperationByAssetPagingRequest extends ListObjectsPagingRequest {

	private String currency_code;

	public String getCurrency_code() {
		return currency_code;
	}

	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}

}
