package com.beowulf.explorer.repository.extend;

import com.beowulf.explorer.document.BeowulfTokenHolder;
import com.beowulfchain.beowulfj.protocol.Asset;

import java.util.List;

public interface BeowulfTokenHolderRepositoryExtend {

    boolean updateBalanceTokenHolder(String holder, Asset balance);

    List<BeowulfTokenHolder> getTopTokenHoldersByTokenName(String token, int limit);

    long getTotalHolders(String token);

    BeowulfTokenHolder findBeowulfTokenHolderByTokenAndAccount(String token, String holder);

}