package com.beowulf.constants;

public class CollectionName {
    public static final String API_KEYS = "api_keys";
    public static final String API_KEY_LEVELS = "api_key_levels";

    public static final String ACCOUNT_CREATED = "account_created";
    public static final String ADDRESS_PAYMENT = "address_created";
    public static final String HISTORY_PAYMENT = "history_payment";
    public static final String HISTORY_TRANSACTION = "history_transaction";

    public static final String AIRDROP_HISTORY = "airdrop_history";

    public static final String ACTIONS = "actions";
    public static final String CERT_ACTIONS = "cert_actions";

    public static final String NODE_LIST = "node_list";
    public static final String NODE_LIST_CRAWLING = "node_list_crawling";
    public static final String CERT_NODE_LIST_CRAWLING = "cert_node_list_crawling";

    public static final String COL_HOOK_PENDING = "hook_pending";
    public static final String COL_BWF_ACCOUNT = "bwf_account";
    public static final String COL_BWF_HOOK_HISTORY = "bwf_hook_history";
    public static final String COL_BWF_SMT_TOKEN_INFO = "bwf_smt_token_info";

    public static final String CONFIGURATIONS = "configurations";

    // Irreversible Blockchain collections
    public static final String ACCOUNTS = "accounts";
    public static final String AUTH_REFERENCES = "auth_references";
    public static final String BLOCKS = "blocks";
    public static final String TRANSACTIONS = "transactions";
    public static final String RELATED_TRANSACTION = "related_transactions";
    public static final String OPERATIONS = "operations";
    public static final String ACCOUNT_HISTORY = "account_history";
    public static final String SUPERNODES = "supernodes";
    public static final String TOKENS = "tokens";
    public static final String TOKEN_HOLDERS = "token_holders";

    // Folked Blockchain collections
    public static final String FOLKED_BLOCKS = "folked_blocks";
    public static final String FOLKED_OPERATIONS = "folked_operations";
    public static final String FOLKED_TRANSACTIONS = "folked_transactions";

    public static final String LAND_CERTIFICATES = "land_certificates";
    public static final String ACADEMIC_CERTIFICATES = "academic_certificates";

    // Chart collections
    public static final String CHART_CRAWLING_CONFIG = "chart_crawling_config";
}
