package com.beowulf.model.ethereum;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.web3j.protocol.core.Response;

@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class ParityGetBlockHeaderByNumberResponse extends Response<ParityGetBlockHeaderByNumber> {

}
