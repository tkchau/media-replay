package com.beowulf.model.ethereum;

import org.web3j.tx.gas.StaticGasProvider;

import java.math.BigInteger;

public class CustomizeGasProvider extends StaticGasProvider {
    public static final BigInteger GAS_LIMIT;
    public static final BigInteger GAS_PRICE;

    public CustomizeGasProvider() {
        super(GAS_PRICE, GAS_LIMIT);
    }

    static {
        // 4.3 million
        GAS_LIMIT = BigInteger.valueOf(500000L);

        // 10 gWei
        GAS_PRICE = BigInteger.valueOf(10000000000L);
    }
}
