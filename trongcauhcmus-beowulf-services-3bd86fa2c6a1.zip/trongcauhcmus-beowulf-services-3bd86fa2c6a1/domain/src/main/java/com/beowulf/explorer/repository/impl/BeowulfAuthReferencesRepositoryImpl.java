package com.beowulf.explorer.repository.impl;

import com.beowulf.constants.CollectionName;
import com.beowulf.explorer.document.BeowulfAuthReferences;
import com.beowulf.explorer.repository.extend.BeowulfAuthReferencesRepositoryExtend;
import com.mongodb.client.result.DeleteResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;


public class BeowulfAuthReferencesRepositoryImpl implements BeowulfAuthReferencesRepositoryExtend {
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean removeOldAccountReference(String refValue, String accountName) {
        Query query = new Query();
        query.addCriteria(new Criteria().andOperator(
                Criteria.where("name").is(refValue),
                Criteria.where("name_references").is(accountName))
        );
        DeleteResult result = mongoTemplate.remove(query, BeowulfAuthReferences.class, CollectionName.AUTH_REFERENCES);
        return result.getDeletedCount() != 0;
    }
}
