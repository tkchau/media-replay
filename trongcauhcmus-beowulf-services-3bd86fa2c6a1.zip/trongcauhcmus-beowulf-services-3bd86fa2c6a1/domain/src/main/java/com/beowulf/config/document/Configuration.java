package com.beowulf.config.document;

import com.beowulf.constants.CollectionName;
import com.beowulf.utilities.GsonSingleton;
import com.beowulf.utilities.MD5;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CollectionName.CONFIGURATIONS)
public class Configuration {
    private ObjectId id;

    @Indexed(unique = true)
    private String key;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String hash() {
        return MD5.hash(GsonSingleton.getInstance().toJson(this));
    }

    public boolean equals(Configuration obj) {
        return obj != null && obj.hash().equals(this.hash());
    }
}
