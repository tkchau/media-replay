package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfAccount;
import com.beowulf.explorer.repository.extend.AccountRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface AccountRepository extends MongoRepository<BeowulfAccount, ObjectId>, AccountRepositoryExtend {

	@Query(value = "{'name' : ?0}")
	public BeowulfAccount findAccountByName(String name);
}
