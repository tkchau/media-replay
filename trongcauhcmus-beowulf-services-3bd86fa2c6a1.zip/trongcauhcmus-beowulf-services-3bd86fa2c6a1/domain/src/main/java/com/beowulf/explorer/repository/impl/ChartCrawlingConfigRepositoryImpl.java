package com.beowulf.explorer.repository.impl;

import com.beowulf.explorer.document.ChartCrawlingConfig;
import com.beowulf.explorer.repository.extend.ChartCrawlingConfigRepositoryExtend;
import com.beowulf.model.chart.record.ChartDailyRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.Date;

public class ChartCrawlingConfigRepositoryImpl implements ChartCrawlingConfigRepositoryExtend {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public boolean updateLastCrawlDate(String nodeUrl, long date) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_date").lte(date));

        Update update = new Update();
        update.set("last_crawl_date", date);
        ChartCrawlingConfig chartCrawlingConfig = mongoTemplate.findAndModify(query, update, ChartCrawlingConfig.class);
        return chartCrawlingConfig != null;
    }

    @Override
    public boolean updateLastCrawlDateOnDestroy(String nodeUrl, long date) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_date").gte(date));

        Update update = new Update();
        update.set("last_crawl_date", date);
        ChartCrawlingConfig chartCrawlingConfig = mongoTemplate.findAndModify(query, update, ChartCrawlingConfig.class);
        return chartCrawlingConfig != null;
    }

    @Override
    public boolean updateLastCrawlChartRecord(String nodeUrl, ChartDailyRecord record) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_time_cursor").lte(record.getTime_cursor()));

        Update update = new Update();
        update.set("last_crawl_time_cursor", record.getTime_cursor());
        update.set("last_crawl_record", record);
        ChartCrawlingConfig chartCrawlingConfig = mongoTemplate.findAndModify(query, update, ChartCrawlingConfig.class);
        return chartCrawlingConfig != null;
    }

    @Override
    public boolean updateLastCrawlChartRecordOnDestroy(String nodeUrl, ChartDailyRecord record) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_time_cursor").gte(record.getTime_cursor()));

        Update update = new Update();
        update.set("last_crawl_time_cursor", record.getTime_cursor());
        update.set("last_crawl_record", record);
        ChartCrawlingConfig chartCrawlingConfig = mongoTemplate.findAndModify(query, update, ChartCrawlingConfig.class);
        return chartCrawlingConfig != null;
    }

    @Override
    public long getLastCrawlDate(long startDate, String nodeUrl) {
        ChartCrawlingConfig config = this.findConfigByNode_url(nodeUrl);
        if (config == null) {
            createNewConfig(startDate, nodeUrl);
            return startDate;
        } else {
            long lastCrawlDate = config.getLast_crawl_date();
            return Math.max(lastCrawlDate, startDate);
        }
    }

    @Override
    public ChartDailyRecord getLastCrawlChartRecord(long timeCursor, String nodeUrl) {
        ChartCrawlingConfig config = this.findConfigByNode_url(nodeUrl);
        if (config == null) {
            config = createNewConfig(timeCursor, nodeUrl);
            return config.getLast_crawl_record();
        } else {
            return config.getLast_crawl_record();
        }
    }

    @Override
    public ChartCrawlingConfig findConfigByNode_url(String node_url) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(node_url));
        return mongoTemplate.findOne(query, ChartCrawlingConfig.class);
    }

    private ChartCrawlingConfig createNewConfig(long startDate, String nodeUrl) {
        ChartCrawlingConfig config = new ChartCrawlingConfig();
        config.setNode_url(nodeUrl);
        config.setLast_crawl_date(startDate);
        config.setLast_crawl_time_cursor(startDate);
        ChartDailyRecord record = new ChartDailyRecord(new Date(startDate));
        record.setTime_cursor(startDate);
        config.setLast_crawl_record(record);
        return mongoTemplate.save(config);
    }
}
