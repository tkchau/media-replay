package com.beowulf.config.repository;

import com.beowulf.config.document.Configuration;
import com.beowulf.constants.CollectionName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class ConfigurationRepositoryImpl implements ConfigurationRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public <T extends Configuration> T findConfigByKey(String key, Class<T> _class) {
        Query query = new Query();
        query.addCriteria(Criteria.where("key").is(key));
        return mongoTemplate.findOne(query, _class, CollectionName.CONFIGURATIONS);
    }
}
