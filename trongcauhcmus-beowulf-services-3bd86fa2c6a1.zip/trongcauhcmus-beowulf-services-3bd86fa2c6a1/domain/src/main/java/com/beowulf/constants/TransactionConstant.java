package com.beowulf.constants;

public class TransactionConstant {
	public static final String LIST_TRANSACTION_DIRECTION_NEXT = "next";
	public static final String LIST_TRANSACTION_DIRECTION_PREVIOUS = "prev";

	public static final String STATUS_REPLACE = "replace";
	public static final String STATUS_REJECT = "lost";
	public static final String STATUS_SUCCESS = "success";

}
