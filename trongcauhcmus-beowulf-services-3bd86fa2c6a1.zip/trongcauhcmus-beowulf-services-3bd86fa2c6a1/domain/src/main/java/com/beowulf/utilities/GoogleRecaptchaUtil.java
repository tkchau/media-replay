package com.beowulf.utilities;

import com.beowulf.config.GeneralConfigProperties;
import com.beowulf.handler.communication.HttpHandler;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class GoogleRecaptchaUtil {
    private static final String verify_url = "https://www.google.com/recaptcha/api/siteverify?secret=@secretkey@&response=@token@";

    public static boolean verify(String token) {
        return verify(token, null);
    }

    public static boolean verify(String token, String remoteIp) {
        try {
            String url = verify_url
                    .replaceAll("@secretkey@", GeneralConfigProperties.getInstance().getGoogle_recaptcha_key())
                    .replaceAll("@token@", token);
            if (remoteIp != null) {
                url = url + "&remoteip=" + remoteIp;
            }
            VerifyResponse response = HttpHandler.getInstance().doGet(VerifyResponse.class, url, null);
            return response.isSuccess();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static final class VerifyResponse {
        private boolean success;
        private String challenge_ts;
        private double score;
        private String hostname;
        @JsonProperty("error-codes")
        private List<String> error_codes;

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getChallenge_ts() {
            return challenge_ts;
        }

        public void setChallenge_ts(String challenge_ts) {
            this.challenge_ts = challenge_ts;
        }

        public String getHostname() {
            return hostname;
        }

        public void setHostname(String hostname) {
            this.hostname = hostname;
        }

        public List<String> getError_codes() {
            return error_codes;
        }

        public void setError_codes(List<String> error_codes) {
            this.error_codes = error_codes;
        }

        public double getScore() {
            return score;
        }

        public void setScore(double score) {
            this.score = score;
        }
    }
}
