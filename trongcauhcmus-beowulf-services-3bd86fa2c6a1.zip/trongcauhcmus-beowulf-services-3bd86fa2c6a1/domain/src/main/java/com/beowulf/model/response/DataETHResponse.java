package com.beowulf.model.response;

import java.math.BigInteger;

public class DataETHResponse {
    private String address;
    private BigInteger in_value;

    public DataETHResponse() {
    }

    public DataETHResponse(String address, BigInteger in_value) {
        this.address = address;
        this.in_value = in_value;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public BigInteger getIn_value() {
        return in_value;
    }

    public void setIn_value(BigInteger in_value) {
        this.in_value = in_value;
    }
}
