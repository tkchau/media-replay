package com.beowulf.utilities;

import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.chain.NetworkProperties;
import com.beowulfchain.beowulfj.chain.network.Mainnet;
import com.beowulfchain.beowulfj.chain.network.Testnet;
import com.beowulfchain.beowulfj.configuration.BeowulfJConfig;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.operations.*;

import java.util.List;

/**
 * @author tatrongcau
 * @project beowulf-services
 * @time 2019-09-25
 */
public class BeowulfCommunicate {

    private static String node_url = "";
    private static BeowulfJ beowulfJ;
    private static NetworkProperties network;

    public static BeowulfJ init(String node_url) throws BeowulfCommunicationException, BeowulfResponseException {
        if (BeowulfCommunicate.node_url.equals(node_url) && beowulfJ != null){
            return beowulfJ;
        }
        BeowulfCommunicate.node_url = node_url;
        Mainnet mainnet = new Mainnet();
        BeowulfJConfig myConfig = BeowulfJConfig.getNewInstance();
        myConfig.setResponseTimeout(100000);
        myConfig.setDefaultBeowulfApiUri(node_url);
        beowulfJ = BeowulfJ.getNewInstance();
        if (beowulfJ.getConfig().getBeowulfChainId().equals(mainnet.getChain_id())) {
            network = mainnet;
        } else {
            network = new Testnet();
        }
        myConfig.setNetwork(network);
        return beowulfJ;
    }

    public static BeowulfJ getBeowulfJ() {
        return beowulfJ;
    }

    public static NetworkProperties getNetwork() {
        return network;
    }

    public static long getHighestBlock() {
        try {
            beowulfJ.getDynamicGlobalProperties().getHeadBlockNumber();
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static long getLastIrreversibleBlockNum() {
        try {
            beowulfJ.getDynamicGlobalProperties().getLastIrreversibleBlockNum();
        } catch (BeowulfCommunicationException | BeowulfResponseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Getting fee of one operation in Beowulf Block-chain
     *
     * @param operation Operation in Transaction
     */
    public static long getFeeOfOperation(Operation operation) {

        if (operation instanceof TransferOperation) {
            return ((TransferOperation) operation).getFee().getAmount();
        } else if (operation instanceof TransferToVestingOperation) {
            return ((TransferToVestingOperation) operation).getFee().getAmount();
        } else if (operation instanceof WithdrawVestingOperation) {
            return ((WithdrawVestingOperation) operation).getFee().getAmount();
        } else if (operation instanceof AccountCreateOperation) {
            return ((AccountCreateOperation) operation).getFee().getAmount();
        } else if (operation instanceof AccountUpdateOperation) {
            return ((AccountUpdateOperation) operation).getFee().getAmount();
        } else if (operation instanceof SupernodeUpdateOperation) {
            return ((SupernodeUpdateOperation) operation).getFee().getAmount();
        } else if (operation instanceof AccountSupernodeVoteOperation) {
            return ((AccountSupernodeVoteOperation) operation).getFee().getAmount();
        } else if (operation instanceof SmtCreateOperation) {
            return ((SmtCreateOperation) operation).getSmtCreationFee().getAmount();
        } else {
            return 0L;
        }
    }

    /**
     * Getting fee of one block in Beowulf Block-chain
     *
     * @param transactions The List transaction in Block.
     */
    private long getTotalFeeOfBlock(List<CompletedTransaction> transactions) {
        long totalFee = 0L;
        if (!transactions.isEmpty()) {
            for (CompletedTransaction transaction : transactions) {
                long fee = getTotalFeeOfTransaction(transaction);
                totalFee += fee;
            }
        }
        return totalFee;
    }

    /**
     * Getting fee of one transaction in Beowulf Block-chain
     *
     * @param transaction The Transaction in Block.
     */
    private long getTotalFeeOfTransaction(CompletedTransaction transaction) {
        long totalFee = 0L;
        List<Operation> operations = transaction.getOperations();
        if (!operations.isEmpty()) {
            for (Operation operation : operations) {
                long fee = getFeeOfOperation(operation);
                totalFee += fee;
            }
        }
        return totalFee;
    }
}
