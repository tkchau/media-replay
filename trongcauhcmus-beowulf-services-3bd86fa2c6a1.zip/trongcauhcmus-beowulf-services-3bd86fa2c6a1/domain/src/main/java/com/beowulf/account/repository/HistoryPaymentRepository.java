package com.beowulf.account.repository;

import com.beowulf.account.documents.PaymentHistory;
import com.beowulf.account.repository.extend.HistoryPaymentRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface HistoryPaymentRepository extends MongoRepository<PaymentHistory, ObjectId>, HistoryPaymentRepositoryExtend {

    @Query(value = "{'payment_id': ?0}")
    PaymentHistory findPaymentHistoryByPayment_id(String payment_id);

}
