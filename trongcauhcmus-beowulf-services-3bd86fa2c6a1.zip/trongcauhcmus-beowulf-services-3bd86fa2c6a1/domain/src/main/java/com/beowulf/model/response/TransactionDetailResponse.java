package com.beowulf.model.response;

import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.document.extensions.ExtensionData;
import com.beowulf.utilities.Common;
import com.beowulf.utilities.DateTimeUtils;

import java.util.ArrayList;
import java.util.List;

public class TransactionDetailResponse {

    private String id;
    private String block_id;
    private long block_num;
    private String expiration;
    private List<String> signatures = new ArrayList<>();
    private List<ExtensionData> extensions = new ArrayList<>();
    private String transaction_id;
    private long created_time;
    private long transaction_num;
    private List<String> operation_ids = new ArrayList<>();
    private List<OperationDetailResponse> operations = new ArrayList<>();
    private String status;
    private long timestamp;

    public TransactionDetailResponse() {
    }

    public TransactionDetailResponse(BeowulfTransaction beowulfTransaction, List<String> operation_ids, List<OperationDetailResponse> operations) {
        this.id = beowulfTransaction.getBc_id().toHexString();
        this.expiration = beowulfTransaction.getExpiration();
        this.created_time = beowulfTransaction.getCreated_time();
        this.signatures = beowulfTransaction.getSignatures();
        this.transaction_id = beowulfTransaction.getTransaction_id();
        this.block_id = beowulfTransaction.getBlock_id();
        this.block_num = Common.getNumberFromBlockId(this.block_id);
        this.status = beowulfTransaction.getStatus();
        this.operation_ids = operation_ids;
        this.operations = operations;
        this.extensions = beowulfTransaction.getExtensions();
        this.transaction_num = beowulfTransaction.getTransaction_num();
        this.timestamp = DateTimeUtils.getTimestampMillsFromObjectId(beowulfTransaction.getBc_id());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBlock_id() {
        return block_id;
    }

    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public String getExpiration() {
        return expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration;
    }

    public List<String> getSignatures() {
        return signatures;
    }

    public void setSignatures(List<String> signatures) {
        this.signatures = signatures;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public long getCreated_time() {
        return created_time;
    }

    public void setCreated_time(long created_time) {
        this.created_time = created_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ExtensionData> getExtensions() {
        return extensions;
    }

    public void setExtensions(List<ExtensionData> extensions) {
        this.extensions = extensions;
    }

    public List<String> getOperation_ids() {
        return operation_ids;
    }

    public void setOperation_ids(List<String> operation_ids) {
        this.operation_ids = operation_ids;
    }

    public List<OperationDetailResponse> getOperations() {
        return operations;
    }

    public void setOperations(List<OperationDetailResponse> operations) {
        this.operations = operations;
    }

    public long getTransaction_num() {
        return transaction_num;
    }

    public void setTransaction_num(long transaction_num) {
        this.transaction_num = transaction_num;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public long getBlock_num() {
        return block_num;
    }

    public void setBlock_num(long block_num) {
        this.block_num = block_num;
    }
}

