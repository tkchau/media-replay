package com.beowulf.certificate.repository.extend;

import com.beowulf.certificate.document.CertAction;
import org.bson.types.ObjectId;

public interface CertActionRepositoryExtend {

    boolean addNewAction(CertAction certAction);

    boolean removeAction(ObjectId id);
}
