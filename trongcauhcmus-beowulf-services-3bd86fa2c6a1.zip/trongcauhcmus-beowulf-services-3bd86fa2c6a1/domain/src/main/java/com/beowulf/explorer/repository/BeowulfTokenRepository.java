package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfToken;
import com.beowulf.explorer.repository.extend.BeowulfTokenRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface BeowulfTokenRepository extends MongoRepository<BeowulfToken, ObjectId>, BeowulfTokenRepositoryExtend {
    @Query(value = "{'name' : ?0}")
    BeowulfToken findBeowulfTokenByName(String assetName);

    @Query(value = "{'control_account' : ?0}")
    BeowulfToken findBeowulfTokenByControl_account(String controlAccount);
}
