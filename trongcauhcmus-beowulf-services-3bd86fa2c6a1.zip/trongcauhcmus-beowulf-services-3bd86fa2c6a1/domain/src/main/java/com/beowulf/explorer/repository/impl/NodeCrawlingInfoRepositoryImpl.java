package com.beowulf.explorer.repository.impl;

import com.beowulf.explorer.document.NodeInfo;
import com.beowulf.explorer.repository.extend.NodeCrawlingInfoRepositoryExtend;
import com.beowulf.model.BlockchainType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class NodeCrawlingInfoRepositoryImpl implements NodeCrawlingInfoRepositoryExtend {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public void updateLastCrawl(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl").lt(blockNum));

        Update update = new Update();
        update.set("last_crawl", blockNum);
        mongoTemplate.findAndModify(query, update, NodeInfo.class);
    }

    @Override
    public boolean updateLastCrawlOnDestroy(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl").gt(blockNum));

        Update update = new Update();
        update.set("last_crawl", blockNum);
        NodeInfo nodeInfo = mongoTemplate.findAndModify(query, update, NodeInfo.class);
        return nodeInfo != null;
    }

    @Override
    public void updateLastIrreversibleCrawl(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_irreversible").lt(blockNum));

        Update update = new Update();
        update.set("last_crawl_irreversible", blockNum);
        mongoTemplate.findAndModify(query, update, NodeInfo.class);
    }

    @Override
    public boolean updateLastIrreversibleCrawlOnDestroy(String nodeUrl, long blockNum) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl).and("last_crawl_irreversible").gt(blockNum));

        Update update = new Update();
        update.set("last_crawl_irreversible", blockNum);
        NodeInfo nodeInfo = mongoTemplate.findAndModify(query, update, NodeInfo.class);
        return nodeInfo != null;
    }

    @Override
    public long getLastCrawlingBlock(long startBlock, String nodeUrl) {
        NodeInfo nodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (nodeInfo == null) {
            createNewNodeInfo(startBlock, nodeUrl);
            return startBlock;
        } else {
            long last_crawl = nodeInfo.getLast_crawl();
            return Math.max(last_crawl, startBlock);
        }
    }

    @Override
    public long getLastCrawlingIrreversibleBlock(long startBlock, String nodeUrl) {
        NodeInfo nodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (nodeInfo == null) {
            createNewNodeInfo(startBlock, nodeUrl);
            return startBlock;
        } else {
            long lastIrreversibleBlock = nodeInfo.getLast_crawl_irreversible();
            return Math.max(lastIrreversibleBlock, startBlock);
        }
    }

    @Override
    public NodeInfo findNodeInfoByNode_url(String node_url) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(node_url));
        return mongoTemplate.findOne(query, NodeInfo.class);
    }

    @Override
    public boolean updateSegment(String nodeUrl, int segment) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl));

        Update update = new Update();
        update.set("last_segment", segment);
        NodeInfo nodeInfo = mongoTemplate.findAndModify(query, update, NodeInfo.class);
        return nodeInfo != null;
    }

    private boolean updateLastStatus(String nodeUrl, boolean isOnline) {
        Query query = new Query();
        query.addCriteria(Criteria.where("node_url").is(nodeUrl));

        Update update = new Update();
        update.set("online", isOnline);
        NodeInfo nodeInfo = mongoTemplate.findAndModify(query, update, NodeInfo.class);
        return nodeInfo != null;
    }

    @Override
    public boolean turnOn(String nodeUrl) {
        return updateLastStatus(nodeUrl, true);
    }

    @Override
    public boolean turnOff(String nodeUrl) {
        return updateLastStatus(nodeUrl, false);
    }

    @Override
    public boolean isTurnedOff(String nodeUrl) {
        return !getLastStatus(nodeUrl);
    }

    @Override
    public int getLastSegment(String nodeUrl) {
        NodeInfo nodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (nodeInfo == null) {
            createNewNodeInfo(1, nodeUrl);
            return 0;
        } else {
            return nodeInfo.getLast_segment();
        }
    }

    private boolean getLastStatus(String nodeUrl) {
        NodeInfo nodeInfo = this.findNodeInfoByNode_url(nodeUrl);
        if (nodeInfo == null) {
            createNewNodeInfo(1, nodeUrl);
            return false;
        } else {
            return nodeInfo.isOnline();
        }
    }

    private void createNewNodeInfo(long startBlock, String nodeUrl) {
        NodeInfo nodeInfo = new NodeInfo();
        nodeInfo.setNode_url(nodeUrl);
        nodeInfo.setLast_crawl(startBlock);
        nodeInfo.setLast_crawl_irreversible(startBlock);
        nodeInfo.setLast_segment(0);
        nodeInfo.setOnline(true);
        nodeInfo.setType(BlockchainType.BWF.name());
        mongoTemplate.save(nodeInfo);
    }
}
