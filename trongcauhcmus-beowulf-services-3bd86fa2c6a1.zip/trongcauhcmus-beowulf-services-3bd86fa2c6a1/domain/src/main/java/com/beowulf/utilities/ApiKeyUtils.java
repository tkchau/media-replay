package com.beowulf.utilities;

import com.beowulf.constants.ApiKeyType;
import org.apache.commons.codec.binary.Base64;

public class ApiKeyUtils {

    private static final String AES_SECRET = "nwzUwEUJJOdjBfGB";
    private static final String AES_IV = "WvevjSMzxIBOERBW";

    public static String createBasicAccessToken(String apiKey, String token) {
        return ApiKeyType.BASIC + " "
                + Base64.encodeBase64String((apiKey + ":" + token).getBytes());
    }

    public static String encryptToken(String token) {
        return AESEncryptor.encrypt(AES_SECRET, AES_IV, token);
    }

    public static String decryptToken(String token) {
        return AESEncryptor.decrypt(AES_SECRET, AES_IV, token);
    }
}
