package com.beowulf.certificate.repository;

import com.beowulf.certificate.document.CertNodeInfo;
import com.beowulf.certificate.repository.extend.CertNodeCrawlingInfoRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CertNodeCrawlingInfoRepository extends MongoRepository<CertNodeInfo, ObjectId>, CertNodeCrawlingInfoRepositoryExtend {
}
