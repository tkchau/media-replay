package com.beowulf.model.request;

/**
 * @author trongcauta
 * @time 11:16 AM
 * @data 6/3/19
 */
public class BeowulfAccountAirdropRequest {
    private String account_name;

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }
}
