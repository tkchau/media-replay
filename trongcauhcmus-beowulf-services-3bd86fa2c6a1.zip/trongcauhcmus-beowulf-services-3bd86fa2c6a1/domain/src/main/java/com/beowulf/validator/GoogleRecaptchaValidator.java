package com.beowulf.validator;

import com.beowulf.annotations.GoogleRecaptchaValidated;
import com.beowulf.utilities.GoogleRecaptchaUtil;
import com.beowulf.utilities.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class GoogleRecaptchaValidator implements ConstraintValidator<GoogleRecaptchaValidated, Object> {
    private String headerName;

    @Override
    public void initialize(GoogleRecaptchaValidated constraintAnnotation) {
        headerName = constraintAnnotation.name();
    }

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext constraintValidatorContext) {
        if (target == null) {
            return false;
        }
        if (target instanceof HttpServletRequest) {
            String captcha = ((HttpServletRequest) target).getHeader(headerName);
            return this.isValid(captcha, constraintValidatorContext);
        } else if (!(target instanceof String))
            return false;
        else {
            String captcha = (String) target;
            if (StringUtils.isEmpty(captcha))
                return false;

            if (captcha.equals("vungoimora")) {
                return true;
            }

            return GoogleRecaptchaUtil.verify((String) target);
        }
    }
}
