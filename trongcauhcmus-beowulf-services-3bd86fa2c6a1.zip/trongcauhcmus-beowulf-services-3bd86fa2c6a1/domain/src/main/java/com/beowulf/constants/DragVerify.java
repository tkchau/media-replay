package com.beowulf.constants;

public class DragVerify {
    public static final String BACKGROUND_PREFIX_PATH = "classpath:drag/";
    public static final String PUZZLE_PATH = "classpath:drag/Beo_light.png";
    public static final String PUZZLE_HIDE_PATH = "classpath:drag/Beo_dark.png";
    public static final int PUZZLE_BACKGROUND_WIDTH = 278;
    public static final int PUZZLE_BACKGROUND_HEIGHT = 172;
    public static final int MARGIN_X = 70;
    public static final int MARGIN_Y = 5;
    public static final int MAX_BACKGROUND_NO = 10;
    public static final int VALID_RANGE = 5;

}
