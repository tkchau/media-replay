package com.beowulf.handler;

import com.beowulf.constants.RedisConstant;
import com.beowulf.utilities.LoggerUtil;
import com.beowulf.utilities.RedisUtils;
import com.beowulf.utilities.StringUtils;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Component
public class RedisKeyExpireHandler extends MessageListenerAdapter {
    private static final String TAG = RedisKeyExpireHandler.class.getName();

    private static HashMap<String, List<RedisKeyExpiredHandlerCallback>> keyExpiredHandlerCallbackHashMap = new HashMap<>();

    public synchronized static void registerCallback(String event, RedisKeyExpiredHandlerCallback callback) {
        if (StringUtils.hasText(event) && callback != null) {
            List<RedisKeyExpiredHandlerCallback> callbackList = keyExpiredHandlerCallbackHashMap.get(event);
            if (callbackList == null)
                callbackList = new ArrayList<>();
            callbackList.add(callback);
            keyExpiredHandlerCallbackHashMap.put(event, callbackList);
        }
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        String key = new String(message.getBody());
        String topic = new String(pattern);
        String channel = null;
        if (message.getChannel() != null)
            channel = new String(message.getChannel());
        String data = RedisUtils.get(key);
        LoggerUtil.i(TAG, "Redis message event: " + topic + ". Key: " + key + ". Channel: " + channel + ". Data: " + data);
        if (RedisConstant.TOPIC_KEY_EXPIRED.equals(topic))
            handleKeyExpired(key);
    }

    private void handleKeyExpired(String key) {
        int index = key.indexOf(":");
        if (index > 0) {
            String prefix = key.substring(0, index);
            String value = key.substring(index + 1);
            List<RedisKeyExpiredHandlerCallback> callbackList = keyExpiredHandlerCallbackHashMap.get(prefix);
            if (callbackList != null) {
                for (RedisKeyExpiredHandlerCallback callback : callbackList) {
                    try {
                        callback.onKeyExpired(value);
                    } catch (Exception e) {
                        LoggerUtil.e(this, e.getMessage());
                    }
                }
            }
        }
    }
}
