package com.beowulf.explorer.repository;

import com.beowulf.explorer.document.BeowulfTransaction;
import com.beowulf.explorer.repository.extend.BeowulfTransactionRepositoryExtend;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface BeowulfTransactionRepository extends MongoRepository<BeowulfTransaction, ObjectId>, BeowulfTransactionRepositoryExtend {

    @Query(value = "{'transaction_id' : ?0}")
    BeowulfTransaction findByTransactionId(String transactionId);

    @Query(value = "{'block_id' : ?0}")
    List<BeowulfTransaction> findByBlock_id(String blockId);

}
