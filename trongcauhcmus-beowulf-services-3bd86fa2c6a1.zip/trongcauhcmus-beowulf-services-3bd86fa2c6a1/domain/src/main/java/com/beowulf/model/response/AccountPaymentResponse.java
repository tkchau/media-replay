package com.beowulf.model.response;

import com.beowulf.model.request.AccountPaymentRequest;

public class AccountPaymentResponse {
    private String payment_id;
    private String address;
    private String asset_code;
    private String min_fee;
    private String name;
    private String pub_key;
    private String email;
    private int expired_time;

    public AccountPaymentResponse() {
    }

    public AccountPaymentResponse(String payment_id, String address, AccountPaymentRequest request, String min_fee, int expired_time) {
        this.payment_id = payment_id;
        this.address = address;
        this.asset_code = request.getAsset_code();
        this.min_fee = min_fee;
        this.name = request.getAccount_name();
        this.pub_key = request.getPublic_key();
        this.email = request.getEmail();
        this.expired_time = expired_time;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }

    public String getMin_fee() {
        return min_fee;
    }

    public void setMin_fee(String min_fee) {
        this.min_fee = min_fee;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPub_key() {
        return pub_key;
    }

    public void setPub_key(String pub_key) {
        this.pub_key = pub_key;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getExpired_time() {
        return expired_time;
    }

    public void setExpired_time(int expired_time) {
        this.expired_time = expired_time;
    }
}
