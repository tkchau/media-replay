package com.beowulf.model.response;

public class ListAddressETHResponse {
    private String address;
    private String private_key;
    private String asset_code;


    public ListAddressETHResponse() {
    }

    public ListAddressETHResponse(String address, String private_key, String asset_code) {
        this.address = address;
        this.private_key = private_key;
        this.asset_code = asset_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrivate_key() {
        return private_key;
    }

    public void setPrivate_key(String private_key) {
        this.private_key = private_key;
    }

    public String getAsset_code() {
        return asset_code;
    }

    public void setAsset_code(String asset_code) {
        this.asset_code = asset_code;
    }
}
