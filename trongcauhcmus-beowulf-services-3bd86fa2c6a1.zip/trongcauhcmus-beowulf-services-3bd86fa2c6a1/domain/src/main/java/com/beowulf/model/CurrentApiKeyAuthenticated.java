package com.beowulf.model;

import com.beowulf.account.documents.ApiKey;
import com.beowulf.account.documents.ApiKeyLevel;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class CurrentApiKeyAuthenticated extends User {
    private static final long serialVersionUID = 4325617835343481061L;

    private ApiKey apiKey;
    private ApiKeyLevel apiKeyLevel;

    public CurrentApiKeyAuthenticated(String username, String password, Collection<? extends GrantedAuthority> authorities, ApiKey apiKey, ApiKeyLevel apiKeyLevel) {
        super(username, password, authorities);
        this.apiKey = apiKey;
        this.apiKeyLevel = apiKeyLevel;
    }

    public CurrentApiKeyAuthenticated(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities, ApiKey apiKey, ApiKeyLevel apiKeyLevel) {
        super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
        this.apiKey = apiKey;
        this.apiKeyLevel = apiKeyLevel;
    }

    public ApiKey getApiKey() {
        return apiKey;
    }

    public void setApiKey(ApiKey apiKey) {
        this.apiKey = apiKey;
    }

    public ApiKeyLevel getApiKeyLevel() {
        return apiKeyLevel;
    }

    public void setApiKeyLevel(ApiKeyLevel apiKeyLevel) {
        this.apiKeyLevel = apiKeyLevel;
    }
}
