package com.beowulf.model.request;

public class BeowulfCreateAccountRequest {
    private String public_key;
    private String account_name;

    public BeowulfCreateAccountRequest() {
    }

    public BeowulfCreateAccountRequest(String public_key, String account_name) {
        this.public_key = public_key;
        this.account_name = account_name;
    }

    public String getPublic_key() {
        return public_key;
    }

    public void setPublic_key(String public_key) {
        this.public_key = public_key;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }
}
