package com.beowulf.utilities;

import com.beowulf.constants.AccountRole;
import com.beowulf.model.CurrentApiKeyAuthenticated;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ApiKeySecurityContextUtil {

    public static CurrentApiKeyAuthenticated getCurrentApiKeyAuthenticated() {
        CurrentApiKeyAuthenticated account = null;
        try {
            account = (CurrentApiKeyAuthenticated) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return account;
        } catch (Exception e) {
        }
        return null;
    }

    public static void reloadRoleUser(int role) {
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();
        if (role == AccountRole.API_KEY_ROLE) {
            authList.add(new SimpleGrantedAuthority(AccountRole.TEXT_ROLE_API_KEY));
        } else {
            authList.add(new SimpleGrantedAuthority(AccountRole.TEXT_ROLE_ANONYMOUS));
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>(authList);
        Authentication newAuth = new UsernamePasswordAuthenticationToken(auth.getPrincipal(), auth.getCredentials(),
                authorities);
        SecurityContextHolder.getContext().setAuthentication(newAuth);
    }

    public static String getCurrentRole() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && !CollectionUtils.isEmpty(auth.getAuthorities())) {
                Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
                for (GrantedAuthority grantedAuthority : authorities) {
                    return grantedAuthority.getAuthority();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void logout() {
        SecurityContextHolder.getContext().setAuthentication(null);
        SecurityContextHolder.clearContext();
    }
}
