package com.beowulf.model.aggregate;

public class AggregateBlockAndTxItem {

    private int daily_inc_block;

    private int daily_inc_tx;

    public AggregateBlockAndTxItem() {
    }

    public int getDaily_inc_block() {
        return daily_inc_block;
    }

    public void setDaily_inc_block(int daily_inc_block) {
        this.daily_inc_block = daily_inc_block;
    }

    public int getDaily_inc_tx() {
        return daily_inc_tx;
    }

    public void setDaily_inc_tx(int daily_inc_tx) {
        this.daily_inc_tx = daily_inc_tx;
    }
}
