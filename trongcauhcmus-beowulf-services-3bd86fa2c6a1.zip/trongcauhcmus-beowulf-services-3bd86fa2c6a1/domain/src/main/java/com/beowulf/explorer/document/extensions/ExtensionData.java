package com.beowulf.explorer.document.extensions;

public abstract class ExtensionData {
}
