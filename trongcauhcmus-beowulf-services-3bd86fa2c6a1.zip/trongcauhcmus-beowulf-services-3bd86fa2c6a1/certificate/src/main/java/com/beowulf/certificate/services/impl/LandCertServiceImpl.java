
package com.beowulf.certificate.services.impl;

import com.beowulf.certificate.document.BeowulfLandCertificate;
import com.beowulf.certificate.repository.LandCertificateRepository;
import com.beowulf.certificate.services.LandCertService;
import com.beowulf.constants.BeowulfConstant;
import com.beowulf.exception.ServiceException;
import com.beowulf.model.response.cert.LandCertDetailResponse;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulf.utilities.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LandCertServiceImpl implements LandCertService {

    private Logger logger = LoggerFactory.getLogger(LandCertService.class);

    @Autowired
    private LandCertificateRepository landCertificateRepository;

    @Override
    public LandCertDetailResponse getLandCertDetailByTxId(String transactionID) {
        try {
            if (StringUtils.isEmpty(transactionID) || transactionID.length() < BeowulfConstant.DEFAULT_TXID_LEN) {
                throw new IllegalArgumentException("Invalid Transaction Id");
            }
            logger.info("==> CERT: " +
                    "Request get Land-Cert detail with transaction id: " + transactionID);
            BeowulfLandCertificate landCertificate = landCertificateRepository.findBeowulfLandCertificateByTransaction_id(transactionID);
            if (landCertificate == null) {
                throw new NullPointerException();
            }
            return new LandCertDetailResponse(landCertificate);
        } catch (IllegalArgumentException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (NullPointerException e) {
            throw ServiceExceptionUtils.certificateNotFound();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public LandCertDetailResponse getLandCertDetailByCertId(String certId) {
        try {
            if (StringUtils.isEmpty(certId)) {
                throw new IllegalArgumentException("Invalid Cert Id");
            }
            logger.info("==> CERT: " +
                    "Request Land-Cert detail with cert id: " + certId);
            BeowulfLandCertificate landCertificate = landCertificateRepository.findLandCertificateByCertId(certId);
            if (landCertificate == null) {
                throw new NullPointerException("Certificate not found");
            }
            return new LandCertDetailResponse(landCertificate);
        } catch (IllegalArgumentException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (NullPointerException e) {
            throw ServiceExceptionUtils.certificateNotFound();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public long getTotalLandCert() throws ServiceException {
        try {
            logger.info("==> CERT: " +
                    "Request total land certificates");
            return landCertificateRepository.count();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }
}

