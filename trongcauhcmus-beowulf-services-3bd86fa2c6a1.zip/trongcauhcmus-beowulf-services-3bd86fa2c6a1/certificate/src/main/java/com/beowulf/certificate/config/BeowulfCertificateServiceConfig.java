package com.beowulf.certificate.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class BeowulfCertificateServiceConfig {
    private static BeowulfCertificateServiceConfig appContext;

    // Secret declare
    private String crypto_aes_secretkey;
    private String crypto_aes_initVector;

    private String beowulf_node;
    private long beowulf_startblock;
    private long beowulf_highestblock;

    private String allow_origin_domains;

    private BeowulfCertificateServiceConfig() {
        ApplicationContext appContext = new ClassPathXmlApplicationContext();
        Properties properties = new Properties();
        try {

            String configFile = System.getProperty("certificate.conf");
            if (configFile == null) {
                configFile = "classpath:/certificate.properties";
            }
            properties.load(appContext.getResource(configFile).getInputStream());

            crypto_aes_secretkey = properties.getProperty("crypto.aes.secretkey");
            crypto_aes_initVector = "1234567812345678";

            beowulf_node = properties.getProperty("beowulf.node");
            beowulf_startblock = Long.parseLong(properties.getProperty("beowulf.startblock"));

            allow_origin_domains = properties.getProperty("host.cors", "beowulfchain.com");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static BeowulfCertificateServiceConfig getInstance() {
        if (appContext == null) {
            appContext = new BeowulfCertificateServiceConfig();
        }
        return appContext;
    }

    public String getCrypto_aes_secretkey() {
        return crypto_aes_secretkey;
    }

    public String getCrypto_aes_initVector() {
        return crypto_aes_initVector;
    }

    public String getBeowulf_node() {
        return beowulf_node;
    }

    public long getBeowulf_startblock() {
        return beowulf_startblock;
    }

    public long getBeowulf_highestblock() {
        return beowulf_highestblock;
    }

    public String getAllow_origin_domains() {
        return allow_origin_domains;
    }
}
