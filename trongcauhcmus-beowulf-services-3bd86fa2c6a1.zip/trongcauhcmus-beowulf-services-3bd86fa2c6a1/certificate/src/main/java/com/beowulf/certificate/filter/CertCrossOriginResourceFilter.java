package com.beowulf.certificate.filter;

import com.beowulf.certificate.config.BeowulfCertificateServiceConfig;
import com.beowulf.filter.CrossOriginResourceFilter;

public class CertCrossOriginResourceFilter extends CrossOriginResourceFilter {
    private static final String TAG = CertCrossOriginResourceFilter.class.getName();

    public CertCrossOriginResourceFilter() {
        super();
    }

    @Override
    public boolean validateOrigin(String origin) {
        String cors = BeowulfCertificateServiceConfig.getInstance().getAllow_origin_domains();
        return origin.endsWith(cors) || origin.endsWith("localhost:8080");
    }
}
