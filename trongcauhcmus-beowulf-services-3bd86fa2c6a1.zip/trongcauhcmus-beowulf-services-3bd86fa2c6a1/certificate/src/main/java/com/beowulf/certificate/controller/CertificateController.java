package com.beowulf.certificate.controller;

import com.beowulf.certificate.services.AcademicCertService;
import com.beowulf.certificate.services.LandCertService;
import com.beowulf.model.response.cert.AcademicCertDetailResponse;
import com.beowulf.model.response.cert.LandCertDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "v1", produces = "application/json; charset=UTF-8")
public class CertificateController {

    @Autowired
    private LandCertService landCertService;

    @Autowired
    private AcademicCertService academicCertService;

    @RequestMapping(value = "land/tx_id/{tx_id}", method = RequestMethod.GET)
    public LandCertDetailResponse getLandCertDetailByTxId(@PathVariable("tx_id") String transactionID) {
        return landCertService.getLandCertDetailByTxId(transactionID);
    }

    @RequestMapping(value = "land/cert_id/{cert_id}", method = RequestMethod.GET)
    public LandCertDetailResponse getLandCertDetailByCertId(@PathVariable("cert_id") String certId) {
        return landCertService.getLandCertDetailByCertId(certId);
    }

    @RequestMapping(value = "academic/tx_id/{tx_id}", method = RequestMethod.GET)
    public AcademicCertDetailResponse getAcademicCertDetailByTxId(@PathVariable("tx_id") String transactionID) {
        return academicCertService.getAcademicCertDetailByTxId(transactionID);
    }

    @RequestMapping(value = "academic/serial_num/{serial_num}", method = RequestMethod.GET)
    public AcademicCertDetailResponse getAcademicCertDetailBySerialNum(@PathVariable("serial_num") String serialNum) {
        return academicCertService.getAcademicCertDetailBySerialNum(serialNum);
    }

    @RequestMapping(value = "academic/student_id/{student_id}", method = RequestMethod.GET)
    public List<AcademicCertDetailResponse> getListAcademicCertsDetailByStudentId(@PathVariable("student_id") String studentId) {
        return academicCertService.getListAcademicCertsDetailByStudentId(studentId);
    }

    @RequestMapping(value = "land/count", method = RequestMethod.GET)
    public long getTotalLandCertInData() {
        return landCertService.getTotalLandCert();
    }

    @RequestMapping(value = "academic/count", method = RequestMethod.GET)
    public long getTotalAcademicCertInData() {
        return academicCertService.getTotalAcademicCert();
    }

}
