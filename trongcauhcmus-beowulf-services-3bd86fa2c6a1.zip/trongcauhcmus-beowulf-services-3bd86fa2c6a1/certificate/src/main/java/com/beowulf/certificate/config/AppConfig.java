package com.beowulf.certificate.config;

import com.beowulf.certificate.crawler.CrawlCertificateData;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    private final ApplicationContext applicationContext;

    @Autowired
    public AppConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Bean
    public CrawlCertificateData beowulfCertCrawler() {
        try {
            System.out.println("Beowulf cert crawler");
            CrawlCertificateData beowulfCertCrawler = (CrawlCertificateData) this.applicationContext.getBean(
                    "crawlCertificateData");
            beowulfCertCrawler.init();
            beowulfCertCrawler.start();
            return beowulfCertCrawler;

        } catch (BeowulfResponseException | BeowulfCommunicationException e) {
            e.printStackTrace();
        }
        return null;
    }
}
