
package com.beowulf.certificate.services.impl;

import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.repository.AcademicCertificateRepository;
import com.beowulf.certificate.services.AcademicCertService;
import com.beowulf.constants.BeowulfConstant;
import com.beowulf.exception.ServiceException;
import com.beowulf.model.response.cert.AcademicCertDetailResponse;
import com.beowulf.utilities.ServiceExceptionUtils;
import com.beowulf.utilities.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AcademicCertServiceImpl implements AcademicCertService {

    private Logger logger = LoggerFactory.getLogger(AcademicCertService.class);

    @Autowired
    private AcademicCertificateRepository academicCertificateRepository;

    @Override
    public AcademicCertDetailResponse getAcademicCertDetailByTxId(String transactionID) throws ServiceException {
        try {
            if (StringUtils.isEmpty(transactionID) || transactionID.length() < BeowulfConstant.DEFAULT_TXID_LEN) {
                throw new IllegalArgumentException("Invalid Transaction Id");
            }
            logger.info("==> CERT: " +
                    "Request get Academic-Cert detail with transaction id: " + transactionID);
            BeowulfAcademicCertificate academicCertificate = academicCertificateRepository.findBeowulfAcademicCertificateByTransaction_id(transactionID);
            if (academicCertificate == null) {
                throw new NullPointerException();
            }
            return new AcademicCertDetailResponse(academicCertificate);
        } catch (IllegalArgumentException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (NullPointerException e) {
            throw ServiceExceptionUtils.certificateNotFound();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public AcademicCertDetailResponse getAcademicCertDetailBySerialNum(String serialNum) throws ServiceException {
        try {
            if (StringUtils.isEmpty(serialNum)) {
                throw new IllegalArgumentException("Invalid Serial-Num");
            }
            logger.info("==> CERT: " +
                    "Request get Academic-Cert detail with serial-num: " + serialNum);
            BeowulfAcademicCertificate academicCertificate = academicCertificateRepository.findAcademicCertificateBySerialNum(serialNum);
            if (academicCertificate == null) {
                throw new NullPointerException("Certificate not found");
            }
            return new AcademicCertDetailResponse(academicCertificate);
        } catch (IllegalArgumentException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (NullPointerException e) {
            throw ServiceExceptionUtils.certificateNotFound();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public List<AcademicCertDetailResponse> getListAcademicCertsDetailByStudentId(String studentId) throws ServiceException {
        try {
            if (StringUtils.isEmpty(studentId)) {
                throw new IllegalArgumentException("Invalid Student ID");
            }
            logger.info("==> CERT: " +
                    "Request get Academic-Cert detail with Student Id: " + studentId);
            List<BeowulfAcademicCertificate> academicCertificates = academicCertificateRepository.findAcademicCertificateByStudentId(studentId);
            if (academicCertificates == null || academicCertificates.isEmpty()) {
                throw new NullPointerException("Certificates not found");
            }
            List<AcademicCertDetailResponse> responses = new ArrayList<>();
            for (BeowulfAcademicCertificate certificate : academicCertificates) {
                responses.add(new AcademicCertDetailResponse(certificate));
            }
            return responses;
        } catch (IllegalArgumentException e) {
            throw ServiceExceptionUtils.invalidRequestParam(e.getMessage());
        } catch (NullPointerException e) {
            throw ServiceExceptionUtils.certificateNotFound();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }

    @Override
    public long getTotalAcademicCert() throws ServiceException {
        try {
            logger.info("==> CERT: " +
                    "Request total academic certificates");
            return academicCertificateRepository.count();
        } catch (Exception e) {
            e.printStackTrace();
            throw ServiceExceptionUtils.internalServerError();
        }
    }
}

