package com.beowulf.certificate.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.response.cert.AcademicCertDetailResponse;

import java.util.List;

public interface AcademicCertService {

    AcademicCertDetailResponse getAcademicCertDetailByTxId(String transactionID) throws ServiceException;

    AcademicCertDetailResponse getAcademicCertDetailBySerialNum(String serialNum) throws ServiceException;

    List<AcademicCertDetailResponse> getListAcademicCertsDetailByStudentId(String studentId) throws ServiceException;

    long getTotalAcademicCert() throws ServiceException;
}
