package com.beowulf.certificate.services;

import com.beowulf.exception.ServiceException;
import com.beowulf.model.response.cert.LandCertDetailResponse;

public interface LandCertService {

    LandCertDetailResponse getLandCertDetailByTxId(String transactionID) throws ServiceException;

    LandCertDetailResponse getLandCertDetailByCertId(String certId) throws ServiceException;

    long getTotalLandCert() throws ServiceException;

}
