package com.beowulf.certificate.crawler;

import com.beowulf.certificate.config.BeowulfCertificateServiceConfig;
import com.beowulf.certificate.document.BeowulfAcademicCertificate;
import com.beowulf.certificate.document.BeowulfLandCertificate;
import com.beowulf.certificate.document.CertAction;
import com.beowulf.certificate.document.certdata.AcademicCertificateData;
import com.beowulf.certificate.document.certdata.CertificateType;
import com.beowulf.certificate.document.certdata.LandCertificateData;
import com.beowulf.certificate.repository.AcademicCertificateRepository;
import com.beowulf.certificate.repository.CertActionRepository;
import com.beowulf.certificate.repository.CertNodeCrawlingInfoRepository;
import com.beowulf.certificate.repository.LandCertificateRepository;
import com.beowulf.constants.ActionConstant;
import com.beowulf.constants.CertConstant;
import com.beowulf.utilities.BeowulfCommunicate;
import com.beowulf.utilities.GsonSingleton;
import com.beowulfchain.beowulfj.BeowulfJ;
import com.beowulfchain.beowulfj.base.models.Block;
import com.beowulfchain.beowulfj.base.models.FutureExtensions;
import com.beowulfchain.beowulfj.chain.CompletedTransaction;
import com.beowulfchain.beowulfj.exceptions.BeowulfCommunicationException;
import com.beowulfchain.beowulfj.exceptions.BeowulfResponseException;
import com.beowulfchain.beowulfj.protocol.extensions.JsonExtension;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.mongodb.MongoSocketOpenException;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;


@Service
@Scope(value = "prototype")
public class CrawlCertificateData extends Thread {

    @Autowired
    private CertActionRepository actionRepository;

    @Autowired
    private CertNodeCrawlingInfoRepository nodeCrawlingInfoRepository;

    @Autowired
    private LandCertificateRepository landCertificateRepository;

    @Autowired
    private AcademicCertificateRepository academicCertificateRepository;

    private final Logger logger = LoggerFactory.getLogger(CrawlCertificateData.class);
    // Handle initial Beowulf node
    private BeowulfJ beowulfJ;
    private String nodeUrl;

    // Handle for crawling highest block
    private long currentBlock;
    private ObjectId currentAction;
    private long successfulCrawlBlock;

    public void init() throws BeowulfCommunicationException, BeowulfResponseException {
        this.nodeUrl = BeowulfCertificateServiceConfig.getInstance().getBeowulf_node();
        this.beowulfJ = BeowulfCommunicate.init(nodeUrl);
        long startBlock = BeowulfCertificateServiceConfig.getInstance().getBeowulf_startblock();
        this.currentBlock = nodeCrawlingInfoRepository.getLastCrawlingBlock(startBlock, this.nodeUrl);
        if (this.currentBlock < 1) {
            this.currentBlock = 1;
        }
    }

    public void setCurrentBlock(long currentBlock) {
        this.currentBlock = currentBlock;
    }

    @PreDestroy
    private void onDestroy() {
        try {
            this.logger.warn("==> CERT: " +
                    "[Crawler] - On destroy method update final crawl: " + this.successfulCrawlBlock);
            if (this.nodeCrawlingInfoRepository.updateLastCrawlOnDestroy(this.nodeUrl, this.successfulCrawlBlock)) {
                this.logger.warn("Update final crawl successfully: " + this.successfulCrawlBlock);
            }
        } catch (MongoSocketOpenException e) {
            this.logger.error("==> CERT: " +
                    "[Crawler] - On destroy method update final crawl FAIL because can not open connect to mongo");
        }
    }

    @Override
    public void run() {
        System.out.println(String.format("Start Beowulf Scrawling with block %s", this.currentBlock));
        long highestBlock = this.currentBlock;
        while (true) {
            try {
                highestBlock = this.beowulfJ.getDynamicGlobalProperties().getHeadBlockNumber();
            } catch (BeowulfCommunicationException e) {
                e.printStackTrace();
                this.logger.error("==> CERT: " +
                        "[Crawler] - Can not connect with beowulf node");
            } catch (BeowulfResponseException e) {
                e.printStackTrace();
                this.logger.error("==> CERT: " +
                        "[Crawler] - Beowulf node response exception");
            }
            while (this.currentBlock <= highestBlock) {
                try {
                    // Handle block
                    Block block = this.beowulfJ.getBlock(this.currentBlock);
                    handleBlock(block);
                    // Update crawl block
                    this.successfulCrawlBlock = this.currentBlock;
                    updateLastCrawl(this.successfulCrawlBlock);
                    this.currentBlock++;
                } catch (BeowulfCommunicationException | BeowulfResponseException e) {
                    this.logger.error("==> CERT: " +
                            "[Crawling Block] - Can not get data of Block {} from Beowulf Network", this.currentBlock);
                } catch (Exception e) {
                    this.logger.error("==> CERT: " +
                            "[Crawling Block] - Can not handle data of Block {} with Error: ", this.currentBlock);
                    e.printStackTrace();
                }
            }
            sleep();
        }
    }

    /**
     * Handling new data of Block for Explorer Service documents
     * and putting into DB if it is satisfied
     *
     * @param block The Block object of Beowulf Block-chain
     */
    private void handleBlock(Block block) {
        try {
            long start = System.currentTimeMillis();
            // Step 1: Create new Action for handle new block document into DB:
            String blockId = block.getBlockId().toString();

            CertAction handleBlockCertAction = new CertAction(
                    String.valueOf(blockId),
                    ActionConstant.CERT_HANDLE_ACTION,
                    ActionConstant.TTL_ACTION
            );
            handleBlockCertAction = this.actionRepository.save(handleBlockCertAction);
            // Get current action => remove action when handle failed
            this.currentAction = handleBlockCertAction.getId();

            // Step 2: Parse data of Transaction and handle Transaction has Certificate Extension data:
            for (CompletedTransaction transaction : block.getTransactions()) {
                for (FutureExtensions extension : transaction.getExtensions()) {
                    if (extension instanceof JsonExtension) {
                        String value = ((JsonExtension) extension).getValue().getData();
                        try {
                            JsonObject jsonExtensionValue = GsonSingleton.getInstance().fromJson(value, JsonObject.class);
                            if (jsonExtensionValue.has(CertConstant.TYPE_KEY)) {
                                String type = jsonExtensionValue.get(CertConstant.TYPE_KEY).getAsString();
                                parseCertificateData(transaction.getTransactionId().toString(), type, value);
                            }
                        } catch (JsonSyntaxException e) {
                            logger.info(String.format("extension is data in transactionId %s is not json", transaction.getTransactionId()));
                        }
                    }
                }
            }

            long end = System.currentTimeMillis();
            this.logger.info((String.format("[Crawler] - End scan block: %s == time execute: %sms",
                    this.currentBlock, end - start)));
        } catch (DuplicateKeyException e) {
            this.logger.info("==> CERT: " +
                    "[Crawling Block] - Has been handle by another bot");
        } catch (Exception e) {
            this.logger.error("==> CERT: " +
                    "[Crawling Block] - Can not handle data of Block {} with Error: ", this.currentBlock);
            e.printStackTrace();
        }
    }

    /**
     * Handling data extension has Event Type certificate
     * and putting into DB if it is satisfied
     *
     * @param transactionId  The Transaction Id of Transaction Beowulf Block-chain.
     * @param type           The Type event in extension value.
     * @param extensionValue The data of extension.
     */
    private void parseCertificateData(String transactionId, String type, String extensionValue) {
        try {
            switch (type) {
                case CertificateType.LAND_CERTIFICATE:
                    handleLandCertData(transactionId, extensionValue);
                    break;
                case CertificateType.ACADEMIC_CERTIFICATE:
                    handleAcademicCertData(transactionId, extensionValue);
                    break;
                default:
                    throw new IllegalStateException("Unexpected type: " + type);
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            this.logger.info("==> CERT: " +
                    "[Crawling Cert] - Invalid certificate - {}", e.getMessage());
        } catch (DuplicateKeyException e) {
            this.logger.info("==> CERT: " +
                    "[Crawling Cert] - Has been handle by another bot");
        } catch (Exception e) {
            this.logger.warn("==> CERT: " +
                    "[Crawling Cert] - Can not handle data of Certificate in Tx {} with Error: ", transactionId);
            e.printStackTrace();
            this.actionRepository.removeAction(this.currentAction);
        }
    }

    /**
     * Handling data extension has Event Type is Academic certificate
     * and putting into DB if it is satisfied
     *
     * @param transactionId  The Transaction Id of Transaction Beowulf Block-chain.
     * @param extensionValue The data of extension.
     */
    private void handleAcademicCertData(String transactionId, String extensionValue) throws IllegalArgumentException, DuplicateKeyException {
        AcademicCertificateData data = AcademicCertificateData.parseAcademicCert(extensionValue);
        BeowulfAcademicCertificate certificate = new BeowulfAcademicCertificate(transactionId);
        certificate.setData(data);
        this.academicCertificateRepository.save(certificate);
    }

    /**
     * Handling data extension has Event Type is Land certificate
     * and putting into DB if it is satisfied
     *
     * @param transactionId  The Transaction Id of Transaction Beowulf Block-chain.
     * @param extensionValue The data of extension.
     */
    private void handleLandCertData(String transactionId, String extensionValue) throws IllegalArgumentException, DuplicateKeyException {
        LandCertificateData data = LandCertificateData.parseLandCert(extensionValue);
        BeowulfLandCertificate existedLandCert = this.landCertificateRepository.findLandCertificateByCertId(data.getCert_id());

        if (existedLandCert != null) {
            existedLandCert.pushTx_histories(existedLandCert.getTransaction_id());
            existedLandCert.setTransaction_id(transactionId);
            existedLandCert.setData(data);
            boolean isSuccessfulUpdate = this.landCertificateRepository.updateCertificateByObjectId(existedLandCert.getId(), existedLandCert);
        } else {
            BeowulfLandCertificate certificate = new BeowulfLandCertificate(transactionId);
            certificate.setData(data);
            this.landCertificateRepository.save(certificate);
        }
    }

    /**
     * Updating last crawling block number of Block-chain when shutdown or
     * maintenance services.
     *
     * @param blockNumber last block number crawling
     */
    private void updateLastCrawl(long blockNumber) {
        try {
            this.nodeCrawlingInfoRepository.updateLastCrawl(this.nodeUrl, blockNumber);
        } catch (MongoSocketOpenException e) {
            this.logger.error("==> CERT: " +
                    "[Crawler] - Can not open connection to mongodb to update last sync");
        }
    }

    /**
     * Putting thread sleep.
     */
    private static void sleep() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
